
import { useAuth } from '@/components/providers/AuthProvider';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';

interface UseServiceInteractionProps {
    serviceId: string;
    isFavorited: boolean;
    isLiked: boolean;
    isMock?: boolean;
    onToggleMockFavorite?: (serviceId: string) => void;
    onToggleMockLike?: (serviceId: string) => void;
}

export const useServiceInteraction = ({
    serviceId,
    isFavorited,
    isLiked,
    isMock = false,
    onToggleMockFavorite,
    onToggleMockLike,
}: UseServiceInteractionProps) => {
    const { user } = useAuth();
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const navigate = useNavigate();

    const favoriteMutation = useMutation({
        mutationFn: async (isCurrentlyFavorited: boolean) => {
            if (!user) throw new Error("User not logged in");

            if (isCurrentlyFavorited) {
                const { error } = await supabase
                    .from('user_favorites')
                    .delete()
                    .match({ user_id: user.id, service_id: serviceId });
                if (error) throw error;
            } else {
                const { error } = await supabase
                    .from('user_favorites')
                    .insert({ user_id: user.id, service_id: serviceId });
                if (error) throw error;
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['user-favorites', user?.id] });
            queryClient.invalidateQueries({ queryKey: ['services-feed'] });
            queryClient.invalidateQueries({ queryKey: ['service-detail', serviceId] });
        },
        onError: (error: any) => {
            if (error.message !== "User not logged in") {
                toast({
                    variant: "destructive",
                    title: "Xatolik",
                    description: "Amalni bajarishda kutilmagan xatolik yuz berdi.",
                });
            }
        }
    });

    const likeMutation = useMutation({
        mutationFn: async (isCurrentlyLiked: boolean) => {
            if (!user) throw new Error("User not logged in");

            if (isCurrentlyLiked) {
                const { error } = await supabase
                    .from('service_likes')
                    .delete()
                    .match({ user_id: user.id, service_id: serviceId });
                if (error) throw error;
            } else {
                const { error } = await supabase
                    .from('service_likes')
                    .insert({ user_id: user.id, service_id: serviceId });
                if (error) throw error;
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['user-likes', user?.id] });
            queryClient.invalidateQueries({ queryKey: ['user-likes', user?.id, serviceId] });
            queryClient.invalidateQueries({ queryKey: ['services-feed'] });
            queryClient.invalidateQueries({ queryKey: ['service-detail', serviceId] });
        },
        onError: (error: any) => {
            if (error.message !== "User not logged in") {
                toast({
                    variant: "destructive",
                    title: "Xatolik",
                    description: "Amalni bajarishda kutilmagan xatolik yuz berdi.",
                });
            }
        }
    });

    const handleFavorite = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        if (isMock) {
            onToggleMockFavorite?.(serviceId);
            return;
        }

        if (!user) {
            toast({
                title: "Kirish shart",
                description: "Xizmatni sevimlilarga qo'shish uchun tizimga kiring.",
                action: <Button onClick={() => navigate('/login')}>Kirish</Button>
            });
            return;
        }
        favoriteMutation.mutate(isFavorited);
    };

    const handleLike = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        if (isMock) {
            onToggleMockLike?.(serviceId);
            return;
        }

        if (!user) {
            toast({
                title: "Kirish shart",
                description: "Layk bosish uchun tizimga kiring.",
                action: <Button onClick={() => navigate('/login')}>Kirish</Button>
            });
            return;
        }
        likeMutation.mutate(isLiked);
    };

    return {
        handleFavorite,
        handleLike,
        isFaving: favoriteMutation.isPending,
        isLiking: likeMutation.isPending,
    };
};
