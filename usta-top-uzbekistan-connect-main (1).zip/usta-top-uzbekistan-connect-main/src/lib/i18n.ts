
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import HttpApi from 'i18next-http-backend';

i18n
  .use(HttpApi) // Tarjimalarni backenddan yuklaydi (masalan, /public/locales)
  .use(LanguageDetector) // Foydalanuvchi tilini aniqlaydi
  .use(initReactI18next) // i18n instansini react-i18next ga uzatadi
  .init({
    supportedLngs: ['uz', 'ru', 'en'],
    fallbackLng: 'uz', // Agar til aniqlanmasa yoki tanlangan tilda tarjima bo'lmasa, standart til
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'], // Aniqlash tartibi
      caches: ['localStorage'], // Aniqlangan tilni localStorage da saqlash
    },
    backend: {
      loadPath: '/locales/{{lng}}/translation.json', // Tarjima fayllariga yo'l
    },
    react: {
      useSuspense: false, // Agar React Suspense ishlatishni xohlamasangiz, false qiling
    },
    // debug: import.meta.env.DEV, // Rivojlantirish rejimida debug loglarni yoqish
  });

export default i18n;
