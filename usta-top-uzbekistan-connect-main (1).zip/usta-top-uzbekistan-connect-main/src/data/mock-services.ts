
import { type ServicePost } from '@/types/service';

export const mockServices: ServicePost[] = [
  {
    id: 'mock-1-1',
    user_id: 'mock-user-1',
    title: "Italyan pastasi tayyorlash",
    description: "Professional oshpazdan italyan taomlarini, jumladan, pastaning har xil turlarini tayyorlashni o'rganing. Darslar yakka va guruh tartibida o'tkaziladi.",
    price: 250000,
    price_unit: "so'm / dars",
    category_slug: "taomlar",
    location_city: "Toshkent",
    location_district: "Yunusobod",
    image_urls: ['/lovable-uploads/942599b1-0a95-4093-b66b-d8600057337e.png'],
    created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Azizbek Anvarov",
      avatar_url: '/lovable-uploads/bab17af7-c65a-4867-b284-2e39d0ddade8.png'
    },
    comments: [{ count: 12 }],
    user_favorites: [{ count: 28 }],
    service_likes: [{ count: 45 }]
  },
  {
    id: 'mock-1-2',
    user_id: 'mock-user-1',
    title: "Oshpazlik sirlari",
    description: "Professional oshpazdan italyan taomlarini, jumladan, pastaning har xil turlarini tayyorlashni o'rganing. Darslar yakka va guruh tartibida o'tkaziladi.",
    price: 250000,
    price_unit: "so'm / dars",
    category_slug: "taomlar",
    location_city: "Toshkent",
    location_district: "Yunusobod",
    image_urls: ['/lovable-uploads/bab17af7-c65a-4867-b284-2e39d0ddade8.png'],
    created_at: new Date(Date.now() - 2.5 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Azizbek Anvarov",
      avatar_url: '/lovable-uploads/bab17af7-c65a-4867-b284-2e39d0ddade8.png'
    },
    comments: [{ count: 7 }],
    user_favorites: [{ count: 15 }],
    service_likes: [{ count: 32 }]
  },
  {
    id: 'mock-2-1',
    user_id: 'mock-user-2',
    title: "Moda dizayni: Liboslar eskizi",
    description: "O'zingizning orzuingizdagi liboslarni yarating! Eskiz chizishdan to mato tanlash va kiyimni tayyor holga keltirishgacha bo'lgan to'liq jarayonni o'rgatamiz.",
    price: 1500000,
    price_unit: "so'm / oy",
    category_slug: "dizayn",
    location_city: "Samarqand",
    location_district: "Markaz",
    image_urls: ['/lovable-uploads/db557ced-f0f6-4951-9d0e-0431085cc3ea.png'],
    created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Gulshoda Nizomova",
      avatar_url: '/lovable-uploads/db557ced-f0f6-4951-9d0e-0431085cc3ea.png'
    },
    comments: [{ count: 8 }],
    user_favorites: [{ count: 42 }],
    service_likes: [{ count: 68 }]
  },
  {
    id: 'mock-2-2',
    user_id: 'mock-user-2',
    title: "Kiyim tikish bo'yicha master-klass",
    description: "O'zingizning orzuingizdagi liboslarni yarating! Eskiz chizishdan to mato tanlash va kiyimni tayyor holga keltirishgacha bo'lgan to'liq jarayonni o'rgatamiz.",
    price: 1500000,
    price_unit: "so'm / oy",
    category_slug: "dizayn",
    location_city: "Samarqand",
    location_district: "Markaz",
    image_urls: ['/lovable-uploads/3317e99a-6135-4613-900e-73943368ab6f.png'],
    created_at: new Date(Date.now() - 3.2 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Gulshoda Nizomova",
      avatar_url: '/lovable-uploads/db557ced-f0f6-4951-9d0e-0431085cc3ea.png'
    },
    comments: [{ count: 5 }],
    user_favorites: [{ count: 21 }],
    service_likes: [{ count: 35 }]
  },
  {
    id: 'mock-2-3',
    user_id: 'mock-user-2',
    title: "Mato tanlash san'ati",
    description: "O'zingizning orzuingizdagi liboslarni yarating! Eskiz chizishdan to mato tanlash va kiyimni tayyor holga keltirishgacha bo'lgan to'liq jarayonni o'rgatamiz.",
    price: 1500000,
    price_unit: "so'm / oy",
    category_slug: "dizayn",
    location_city: "Samarqand",
    location_district: "Markaz",
    image_urls: ['/lovable-uploads/1b2f5040-237e-431d-90ad-2e3c25f71735.png'],
    created_at: new Date(Date.now() - 3.4 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Gulshoda Nizomova",
      avatar_url: '/lovable-uploads/db557ced-f0f6-4951-9d0e-0431085cc3ea.png'
    },
    comments: [{ count: 11 }],
    user_favorites: [{ count: 33 }],
    service_likes: [{ count: 50 }]
  },
  {
    id: 'mock-2-4',
    user_id: 'mock-user-2',
    title: "Andoza chizish",
    description: "O'zingizning orzuingizdagi liboslarni yarating! Eskiz chizishdan to mato tanlash va kiyimni tayyor holga keltirishgacha bo'lgan to'liq jarayonni o'rgatamiz.",
    price: 1500000,
    price_unit: "so'm / oy",
    category_slug: "dizayn",
    location_city: "Samarqand",
    location_district: "Markaz",
    image_urls: ['/lovable-uploads/a9b8198d-5309-4b1c-b628-168b12460797.png'],
    created_at: new Date(Date.now() - 3.6 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Gulshoda Nizomova",
      avatar_url: '/lovable-uploads/db557ced-f0f6-4951-9d0e-0431085cc3ea.png'
    },
    comments: [{ count: 3 }],
    user_favorites: [{ count: 9 }],
    service_likes: [{ count: 15 }]
  },
  {
    id: 'mock-3-1',
    user_id: 'mock-user-3',
    title: "Uy tozalash xizmati",
    description: "Bizning jamoamiz uyingiz va ofisingizni toza va saranjom holatga keltiradi. Sifatli vositalar va tajribali xodimlar xizmatingizda.",
    price: 300000,
    price_unit: "so'm / xizmat",
    category_slug: "tozalash",
    location_city: "Buxoro",
    location_district: "G'ijduvon",
    image_urls: ['/lovable-uploads/277ca993-e00f-42ed-8fc6-3f328e0d83b1.png'],
    created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Cleaning Pro",
      avatar_url: '/lovable-uploads/277ca993-e00f-42ed-8fc6-3f328e0d83b1.png'
    },
    comments: [{ count: 21 }],
    user_favorites: [{ count: 55 }],
    service_likes: [{ count: 89 }]
  },
  {
    id: 'mock-3-2',
    user_id: 'mock-user-3',
    title: "Ofislar uchun tozalash",
    description: "Bizning jamoamiz uyingiz va ofisingizni toza va saranjom holatga keltiradi. Sifatli vositalar va tajribali xodimlar xizmatingizda.",
    price: 450000,
    price_unit: "so'm / xizmat",
    category_slug: "tozalash",
    location_city: "Buxoro",
    location_district: "G'ijduvon",
    image_urls: ['/lovable-uploads/d3bbc6f9-7a8d-4b84-bab3-ae4622fc8dab.png'],
    created_at: new Date(Date.now() - 5.5 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Cleaning Pro",
      avatar_url: '/lovable-uploads/277ca993-e00f-42ed-8fc6-3f328e0d83b1.png'
    },
    comments: [{ count: 15 }],
    user_favorites: [{ count: 30 }],
    service_likes: [{ count: 48 }]
  },
  {
    id: 'mock-4-1',
    user_id: 'mock-user-4',
    title: "Issiqxona uchun agronom maslahati",
    description: "Issiqxonangizdan mo'l hosil olish uchun professional agronom maslahatlari. O'g'itlash, sug'orish va kasalliklarga qarshi kurashish bo'yicha yordam beramiz.",
    price: 500000,
    price_unit: "so'm / maslahat",
    category_slug: "qishloq-xojaligi",
    location_city: "Farg'ona",
    location_district: "Rishton",
    image_urls: ['/lovable-uploads/c0bfd21b-c8bd-4683-aa74-43d7303c65ec.png'],
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Zamira Agromarket",
      avatar_url: '/lovable-uploads/c0bfd21b-c8bd-4683-aa74-43d7303c65ec.png'
    },
    comments: [{ count: 5 }],
    user_favorites: [{ count: 18 }],
    service_likes: [{ count: 25 }]
  },
  {
    id: 'mock-5-1',
    user_id: 'mock-user-5',
    title: "Ayollar go'zallik saloni",
    description: "Har qanday turdagi soch turmaklari, makiyaj va boshqa go'zallik xizmatlari. Biz bilan o'zingizni malikadek his eting!",
    price: null,
    price_unit: "kelishiladi",
    category_slug: "gozallik",
    location_city: "Andijon",
    location_district: "Markaz",
    image_urls: ['/lovable-uploads/9e276e89-e3b0-4a18-a92f-eaa91bfb2869.png'],
    created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    updated_at: null,
    profiles: {
      full_name: "Salon 'Afsona'",
      avatar_url: null
    },
    comments: [{ count: 34 }],
    user_favorites: [{ count: 76 }],
    service_likes: [{ count: 102 }]
  },
];

export const getMockServiceById = (id: string): ServicePost | undefined => {
  return mockServices.find(service => service.id === id);
}
