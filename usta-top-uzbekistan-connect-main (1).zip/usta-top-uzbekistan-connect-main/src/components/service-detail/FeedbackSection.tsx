
import React from 'react';
import { useTranslation } from 'react-i18next';
import StarRating from '@/components/reviews/StarRating';
import ReviewForm from '@/components/reviews/ReviewForm';
import ReviewList from '@/components/reviews/ReviewList';
import CommentForm from '@/components/comments/CommentForm';
import CommentList from '@/components/comments/CommentList';
import { ServiceWithProfile } from '@/pages/ServiceDetailPage';
import { ReviewWithProfile } from '@/components/reviews/ReviewItem';

interface FeedbackSectionProps {
    service: ServiceWithProfile;
    reviewCount: number;
    averageRating: number;
    isMock: boolean;
    setReviews: React.Dispatch<React.SetStateAction<ReviewWithProfile[]>>;
}

const FeedbackSection: React.FC<FeedbackSectionProps> = ({ service, reviewCount, averageRating, isMock, setReviews }) => {
    const { t } = useTranslation();

    return (
        <>
            <div id="reviews" className="mt-12 border-t pt-8 scroll-mt-24">
                <h2 className="text-2xl font-bold mb-4">{t('reviews.title', "Fikr va mulohazalar")} ({reviewCount})</h2>
                {averageRating > 0 && (
                    <div className="flex items-center gap-2 mb-6">
                        <span className="text-2xl font-bold">{averageRating.toFixed(1)}</span>
                        <StarRating rating={averageRating} readOnly />
                    </div>
                )}
                <ReviewForm serviceId={service.id} serviceOwnerId={service.user_id} isMock={isMock} />
                <ReviewList serviceId={service.id} onReviewsLoaded={setReviews} />
            </div>

            <div id="comments" className="mt-12 border-t pt-8 scroll-mt-24">
                <h2 className="text-2xl font-bold mb-4">Izohlar ({service.comments[0]?.count || 0})</h2>
                <CommentForm serviceId={service.id} isMock={isMock} />
                {isMock ? (
                    <p className="text-muted-foreground mt-6 text-center">Namuna uchun yaratilgan xizmatlarga izohlar ko'rsatilmaydi.</p>
                ) : (
                    <CommentList serviceId={service.id} />
                )}
            </div>
        </>
    );
};

export default FeedbackSection;
