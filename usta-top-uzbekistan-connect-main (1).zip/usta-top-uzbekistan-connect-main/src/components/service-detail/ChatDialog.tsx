
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Loader2 } from 'lucide-react';
import ChatView from '@/components/profile/ChatView';
import { ConversationWithRecipient } from '@/components/profile/Messages';
import { UseMutationResult } from '@tanstack/react-query';

interface ChatDialogProps {
    isOpen: boolean;
    onOpenChange: (open: boolean) => void;
    serviceTitle: string;
    conversation: ConversationWithRecipient | null;
    conversationMutation: UseMutationResult<any, Error, any, unknown>;
}

const ChatDialog: React.FC<ChatDialogProps> = ({ isOpen, onOpenChange, serviceTitle, conversation, conversationMutation }) => {
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-3xl w-full h-[90vh] sm:h-[80vh] flex flex-col p-0">
                <DialogHeader className="p-4 border-b">
                    <DialogTitle>Suhbat: {serviceTitle}</DialogTitle>
                </DialogHeader>
                {conversationMutation.isPending || !conversation ? (
                    <div className="flex items-center justify-center h-full"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
                ) : (
                    <ChatView conversation={conversation} />
                )}
            </DialogContent>
        </Dialog>
    );
};

export default ChatDialog;
