
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { User, MessageCircle, Loader2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ServiceWithProfile } from '@/pages/ServiceDetailPage';
import { UseMutationResult } from '@tanstack/react-query';

interface ProviderCardProps {
    providerProfile: ServiceWithProfile['profiles'];
    isServiceOwner: boolean;
    handleContactMaster: () => void;
    conversationMutation: UseMutationResult<any, Error, any, unknown>;
}

const ProviderCard: React.FC<ProviderCardProps> = ({ providerProfile, isServiceOwner, handleContactMaster, conversationMutation }) => {
    const { t } = useTranslation();

    return (
        <div className="sticky top-24 p-4 border rounded-lg bg-card">
            <h3 className="font-semibold mb-4">Usta haqida</h3>
            {providerProfile ? (
                <Link to={`/specialist/${providerProfile.id}`} className="flex items-center gap-3 group">
                    <Avatar className="h-12 w-12">
                        <AvatarImage src={providerProfile.avatar_url || ''} />
                        <AvatarFallback>{providerProfile.full_name?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <p className="font-medium group-hover:text-primary">{providerProfile.full_name}</p>
                    </div>
                </Link>
            ) : (
                 <div className="flex items-center gap-2"><User className="h-4 w-4" /> Ma'lumot yo'q</div>
            )}
             {providerProfile && !isServiceOwner && (
                <div className="mt-6">
                    <Button size="lg" className="w-full" onClick={handleContactMaster} disabled={conversationMutation.isPending}>
                        {conversationMutation.isPending ? (
                            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        ) : (
                            <MessageCircle className="mr-2 h-5 w-5" />
                        )}
                        {t('contactMaster', "Usta bilan bog'lanish")}
                    </Button>
                </div>
            )}
        </div>
    );
};

export default ProviderCard;
