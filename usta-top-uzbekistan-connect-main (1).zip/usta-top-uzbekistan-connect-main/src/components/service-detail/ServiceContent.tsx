
import React from 'react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Button } from '@/components/ui/button';
import { ThumbsUp, Heart } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { cn } from '@/lib/utils';
import { ServiceWithProfile } from '@/pages/ServiceDetailPage';

interface ServiceContentProps {
    service: ServiceWithProfile;
    isLiked: boolean;
    isFavorited: boolean;
    isMock: boolean;
    handleLike: () => void;
    handleFavorite: () => void;
    likeMutation: { isPending: boolean };
    favoriteMutation: { isPending: boolean };
}

const ServiceContent: React.FC<ServiceContentProps> = ({
    service, isLiked, isFavorited, isMock, handleLike, handleFavorite, likeMutation, favoriteMutation
}) => {
    const { t } = useTranslation();

    return (
        <>
            {service.image_urls && service.image_urls.length > 0 ? (
                <Carousel className="w-full mb-6 -ml-2">
                    <CarouselContent>
                        {service.image_urls.map((url, index) => (
                            <CarouselItem key={index}>
                                <div className="p-2">
                                    <img src={url} alt={`Service image ${index + 1}`} className="w-full h-auto object-cover rounded-lg aspect-video" />
                                </div>
                            </CarouselItem>
                        ))}
                    </CarouselContent>
                    <CarouselPrevious className="ml-16" />
                    <CarouselNext className="mr-16" />
                </Carousel>
            ) : <div className='h-12'/>}
            
            <div className="flex items-center justify-between mt-4 mb-6">
              <div>
                {service.price && (
                    <p className="text-3xl font-bold text-primary">
                        {service.price.toLocaleString('uz-UZ')} {service.price_unit}
                    </p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Button onClick={handleLike} variant="outline" size="lg" className="flex items-center gap-2" disabled={!isMock && likeMutation.isPending}>
                    <ThumbsUp className={cn("w-6 h-6", isLiked ? "fill-primary text-primary" : "text-muted-foreground")} />
                    <span>{isLiked ? t('liked', "Yoqdi") : t('like', 'Yoqdi')}</span>
                </Button>
                <Button onClick={handleFavorite} variant="ghost" size="lg" className="flex items-center gap-2" disabled={!isMock && favoriteMutation.isPending}>
                    <Heart className={cn("w-6 h-6", isFavorited ? "fill-red-500 text-red-500" : "text-muted-foreground")} />
                    <span>{isFavorited ? "Saqlangan" : "Saqlash"}</span>
                </Button>
              </div>
            </div>

            <div className="prose dark:prose-invert max-w-none text-base">
                <p>{service.description}</p>
            </div>
        </>
    );
}

export default ServiceContent;
