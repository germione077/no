
import React from 'react';
import { Tag, MapPin, Calendar, Star, ThumbsUp, Heart } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { ServiceWithProfile } from '@/pages/ServiceDetailPage';
import { Category } from '@/config/categories';

interface ServiceHeaderProps {
    service: ServiceWithProfile;
    category: Category | undefined;
    reviewCount: number;
    averageRating: number;
    likeCount: number;
    favoriteCount: number;
}

const ServiceHeader: React.FC<ServiceHeaderProps> = ({ service, category, reviewCount, averageRating, likeCount, favoriteCount }) => {
    const { t } = useTranslation();

    return (
        <>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{service.title}</h1>
            <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground mb-6">
                {category && <div className="flex items-center gap-1.5"><Tag className="h-4 w-4" /> {category.title}</div>}
                {service.location_city && <div className="flex items-center gap-1.5"><MapPin className="h-4 w-4" /> {service.location_city}{service.location_district && `, ${service.location_district}`}</div>}
                <div className="flex items-center gap-1.5"><Calendar className="h-4 w-4" /> {new Date(service.created_at!).toLocaleDateString()}</div>
                {reviewCount > 0 && <div className="flex items-center gap-1.5"><Star className="h-4 w-4" /> {averageRating.toFixed(1)} ({reviewCount})</div>}
                <div className="flex items-center gap-1.5"><ThumbsUp className="h-4 w-4" /> {likeCount} {t('likes', 'ta yoqdi')}</div>
                <div className="flex items-center gap-1.5"><Heart className="h-4 w-4" /> {favoriteCount} {t('favoritesCount', 'sevimlilarda')}</div>
            </div>
        </>
    );
};

export default ServiceHeader;
