
import React from 'react';
import { useTranslation } from 'react-i18next';
import { ShieldCheck, Clock, Award } from 'lucide-react';

const features = [
  {
    icon: ShieldCheck,
    titleKey: 'whyChooseUsFeature1Title',
    titleDefault: 'Ishonchli ustalar',
    descriptionKey: 'whyChooseUsFeature1Desc',
    descriptionDefault: 'Platformadagi barcha ustalarimiz tekshiruvdan o\'tgan va o\'z ishining professionali.',
  },
  {
    icon: Clock,
    titleKey: 'whyChooseUsFeature2Title',
    titleDefault: 'Tez va qulay',
    descriptionKey: 'whyChooseUsFeature2Desc',
    descriptionDefault: 'O\'zingizga kerakli xizmatni bir necha daqiqada toping va vaqtingizni tejang.',
  },
  {
    icon: Award,
    titleKey: 'whyChooseUsFeature3Title',
    titleDefault: 'Sifat kafolati',
    descriptionKey: 'whyChooseUsFeature3Desc',
    descriptionDefault: 'Biz xizmatlar sifati yuqori bo\'lishini ta\'minlaymiz va mijozlarimiz fikrini qadrlaymiz.',
  },
];

const WhyChooseUsSection = () => {
  const { t } = useTranslation();

  return (
    <section className="py-16 md:py-24 bg-secondary/50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          {t('whyChooseUsTitle', 'Nega aynan HunarMarket.uz?')}
        </h2>
        <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
          {t('whyChooseUsSubtitle', 'Biz sizga eng yaxshi xizmatlarni topish uchun bir qancha afzalliklarni taklif etamiz.')}
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          {features.map((feature, index) => (
            <div key={index} className="p-6">
              <div className="flex justify-center mb-4">
                <div className="bg-primary/10 text-primary p-4 rounded-full">
                  <feature.icon className="h-10 w-10" />
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-2">{t(feature.titleKey, feature.titleDefault)}</h3>
              <p className="text-muted-foreground">{t(feature.descriptionKey, feature.descriptionDefault)}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUsSection;
