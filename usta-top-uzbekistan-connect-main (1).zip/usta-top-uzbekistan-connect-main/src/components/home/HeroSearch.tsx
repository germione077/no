
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { categoryDetailsMap, Specialist } from '@/pages/CategoryDetailPage';
import { getAllCategories, Category, SubCategory } from '@/config/categories';

type SearchResult =
  | { type: 'specialist'; data: Specialist }
  | { type: 'category'; data: Category }
  | { type: 'subcategory'; data: SubCategory };

const HeroSearch = () => {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const allSpecialists = useMemo(() =>
    Object.values(categoryDetailsMap).flatMap(category => category.specialists || []).filter(Boolean),
    []
  );

  const allCategories = useMemo(() => getAllCategories(t), [t]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value.toLowerCase();
    setSearchQuery(e.target.value);

    if (query.trim() === '') {
        setSearchResults([]);
        return;
    }

    const specialistResults: SearchResult[] = allSpecialists
        .filter(specialist => specialist.name.toLowerCase().includes(query))
        .map(specialist => ({ type: 'specialist', data: specialist }));

    const categoryAndSubCategoryResults: SearchResult[] = [];
    allCategories.forEach(category => {
        if (category.title.toLowerCase().includes(query) || category.description.toLowerCase().includes(query)) {
            categoryAndSubCategoryResults.push({ type: 'category', data: category });
        }
        category.subCategories.forEach(sub => {
            if (sub.title.toLowerCase().includes(query) || sub.description.toLowerCase().includes(query)) {
                categoryAndSubCategoryResults.push({ type: 'subcategory', data: sub });
            }
        });
    });

    const combinedResults = [...specialistResults, ...categoryAndSubCategoryResults];

    const uniqueResults = Array.from(new Map(combinedResults.map(item => {
      let key;
      if (item.type === 'specialist') {
        key = `spec_${item.data.id}`;
      } else {
        key = `${item.type}_${item.data.slug}`;
      }
      return [key, item];
    })).values());

    setSearchResults(uniqueResults);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
            setSearchResults([]);
        }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
        document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="max-w-xl mx-auto mb-10 relative" ref={searchContainerRef}>
      <div className="flex flex-col sm:flex-row gap-2">
        <Input
          type="text"
          placeholder={t('heroSearchPlaceholder', "Xizmat yoki ustani qidiring (masalan, 'elektrik Toshkent')")}
          className="flex-grow text-gray-900 bg-white/90 placeholder:text-muted-foreground"
          value={searchQuery}
          onChange={handleInputChange}
          autoComplete="off"
        />
        <Button asChild size="lg" className="bg-amber-500 hover:bg-amber-600 text-black">
          <Link to="/categories">
            <Search className="mr-2 h-5 w-5" /> {t('heroSearchButton', 'Qidirish')}
          </Link>
        </Button>
      </div>
      {searchResults.length > 0 && (
        <div className="absolute top-full mt-2 w-full bg-white rounded-md shadow-lg z-30 text-left">
          <ul className="py-1 max-h-60 overflow-y-auto">
            {searchResults.map(result => {
              const key = result.type === 'specialist'
                ? `spec_${result.data.id}`
                : `${result.type}_${(result.data as Category | SubCategory).slug}`;
              
              const closeDropdown = () => {
                setSearchQuery('');
                setSearchResults([]);
              };

              if (result.type === 'specialist') {
                return (
                  <li key={key}>
                    <Link
                      to={`/specialist/${result.data.id}`}
                      state={{ specialist: result.data }}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={closeDropdown}
                    >
                      {result.data.name} <span className="text-xs text-muted-foreground">({t('searchResultSpecialist')})</span>
                    </Link>
                  </li>
                );
              } else if (result.type === 'category') {
                return (
                  <li key={key}>
                    <Link
                      to={`/categories#${result.data.slug}`}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={closeDropdown}
                    >
                      {result.data.title} <span className="text-xs text-muted-foreground">({t('searchResultCategory')})</span>
                    </Link>
                  </li>
                );
              } else if (result.type === 'subcategory') {
                return (
                  <li key={key}>
                    <Link
                      to={`/categories/${result.data.slug}`}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      onClick={closeDropdown}
                    >
                      {result.data.title} <span className="text-xs text-muted-foreground">({t('searchResultSubCategory', 'Sub-category')})</span>
                    </Link>
                  </li>
                );
              }
              return null;
            })}
          </ul>
        </div>
      )}
    </div>
  );
};

export default HeroSearch;
