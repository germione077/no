
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Armchair, Tv, Wrench, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const tasks = [
  {
    icon: Armchair,
    titleKey: 'taskFurnitureAssembly',
    titleDefault: 'Mebel yig\'ish',
    link: '/categories/remont-qurilish',
  },
  {
    icon: Tv,
    titleKey: 'taskTvMounting',
    titleDefault: 'TV o\'rnatish',
    link: '/categories/remont-qurilish',
  },
  {
    icon: Wrench,
    titleKey: 'taskMinorRepairs',
    titleDefault: 'Kichik ta\'mirlash',
    link: '/categories/santexnik',
  },
  {
    icon: Sparkles,
    titleKey: 'taskCleaning',
    titleDefault: 'Tozalash ishlari',
    link: '/categories/uy-xizmatlari',
  },
];

const EverydayTasksSection = () => {
  const { t } = useTranslation();

  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          {t('everydayTasksTitle', 'Har kunlik hayotni osonlashtiring')}
        </h2>
        <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
          {t('everydayTasksSubtitle', 'Bizning ustalarimiz sizga turli xil uy yumushlarida yordam berishga tayyor.')}
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
          {tasks.map((task, index) => (
            <Link to={task.link} key={index} className="group text-center p-4 border rounded-lg shadow-sm hover:shadow-md transition-shadow hover:-translate-y-1 block">
              <div className="flex justify-center mb-4">
                <div className="bg-primary/10 text-primary p-4 rounded-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <task.icon className="h-8 w-8" />
                </div>
              </div>
              <h3 className="text-lg font-semibold">{t(task.titleKey, task.titleDefault)}</h3>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EverydayTasksSection;
