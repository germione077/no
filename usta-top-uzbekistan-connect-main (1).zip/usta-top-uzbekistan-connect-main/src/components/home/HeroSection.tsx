import React, { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  type CarouselApi,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import { Link } from 'react-router-dom';
import { useAuth } from '../providers/AuthProvider';
import HeroSearch from './HeroSearch';

const uploadedImages = [
  '/lovable-uploads/3f3ae273-0d13-45bc-944f-38b9942ac2a3.png', // Chef
  '/lovable-uploads/f9640e65-faeb-42a6-9b93-d5d7e7111e50.png', // Sewing machine
  '/lovable-uploads/58f5c425-b3db-488c-b1fc-26ff3b9c5db0.png', // Hairdresser
  '/lovable-uploads/05855394-b880-40a5-a37b-d4c2f6929900.png', // Plumber
];
// console.log("HeroSection: uploadedImages array:", uploadedImages); // Reduced initial logging

// Helper function to get image URL
const getImageUrl = (imagePath: string) => {
  // console.log("HeroSection: getImageUrl called with:", imagePath); // Reduced initial logging
  return imagePath;
};


const HeroSection = () => {
  const { t } = useTranslation();
  const { session } = useAuth();
  const autoplayPlugin = useRef(Autoplay({ delay: 5000, stopOnInteraction: true }));
  const [api, setApi] = React.useState<CarouselApi>()
  
  useEffect(() => {
    if (!api) {
      console.log("HeroSection Effect: API not yet available.");
      return;
    }
    console.log("HeroSection Effect: API is available.");

    const logCarouselState = (context: string) => {
      if (!api) return; // Guard against api being nullified
      console.log(`HeroSection (${context}): Selected Snap = ${api.selectedScrollSnap()}`);
      console.log(`HeroSection (${context}): Slides in View = ${JSON.stringify(api.slidesInView())}`);
      console.log(`HeroSection (${context}): Previous Snap = ${api.previousScrollSnap()}`);
      console.log(`HeroSection (${context}): Can Scroll Prev = ${api.canScrollPrev()}`);
      console.log(`HeroSection (${context}): Can Scroll Next = ${api.canScrollNext()}`);
      console.log(`HeroSection (${context}): Scroll Snap List = ${JSON.stringify(api.scrollSnapList().map(snap => snap.toFixed(2)))}`);
      console.log(`HeroSection (${context}): Number of slides in DOM = ${api.slideNodes().length}`);
      console.log(`HeroSection (${context}): Root node = ${api.rootNode().tagName}`);
      console.log(`HeroSection (${context}): Container node = ${api.containerNode().tagName}`);

    };

    logCarouselState("Initial API setup");

    const onSelect = () => logCarouselState("Event: select");
    const onSettle = () => logCarouselState("Event: settle (animation ended)");
    const onResize = () => {
      logCarouselState("Event: resize (before reInit)");
      api.reInit(); // Reinitialize on resize
      logCarouselState("Event: resize (after reInit)");
    };
    const onScroll = () => {
        // This might be too noisy, use if needed
        // console.log(`HeroSection (Event: scroll): Scroll progress = ${api.scrollProgress().toFixed(4)}`);
    };

    api.on("select", onSelect);
    api.on("settle", onSettle);
    api.on("resize", onResize);
    api.on("scroll", onScroll); // Listen to scroll for more detailed debugging if needed

    // Attempt a re-init once after mount, perhaps after a tick for DOM to settle
    const timer = setTimeout(() => {
      if (api && document.readyState === 'complete') {
        console.log("HeroSection Effect: Attempting delayed reInit on DOM complete.");
        api.reInit();
        logCarouselState("After delayed reInit");
      } else if (api) {
        console.log("HeroSection Effect: DOM not complete for delayed reInit, but attempting reInit anyway.");
        api.reInit(); // Try reInit even if not fully 'complete' but API exists
        logCarouselState("After speculative delayed reInit");
      }
    }, 150); // Increased delay slightly

    return () => {
      console.log("HeroSection Effect: Cleaning up API event listeners.");
      if (api) { // Check if api still exists before trying to call off
        api.off("select", onSelect);
        api.off("settle", onSettle);
        api.off("resize", onResize);
        api.off("scroll", onScroll);
      }
      clearTimeout(timer);
    };
  }, [api]); // Dependency array remains [api]

  return (
    <section className="relative py-20 md:py-32 overflow-hidden"> {/* Removed text-primary-foreground */}
      <Carousel
        setApi={setApi}
        className="absolute inset-0 w-full h-full"
        plugins={[autoplayPlugin.current]}
        opts={{
          loop: true,
        }}
      >
        <CarouselContent className="h-full"> 
          {uploadedImages.map((imagePath, index) => {
            const bgImageUrl = `url(${getImageUrl(imagePath)})`;
            return (
              <CarouselItem key={index} className="h-full">
                <div
                  className="w-full h-full bg-cover bg-center"
                  style={{ backgroundImage: bgImageUrl }}
                  aria-label={`Hero background image ${index + 1}`}
                />
              </CarouselItem>
            );
          })}
        </CarouselContent>
      </Carousel>

      <div className="absolute inset-0 w-full h-full bg-black/50 z-10"></div>

      <div className="container mx-auto px-4 text-center relative z-20">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-white"> {/* Added text-white */}
          {t('heroTitleLine1')} <br className="hidden md:block" /> {t('heroTitleLine2')}
        </h1>
        <p className="text-lg md:text-xl mb-10 max-w-2xl mx-auto text-white"> {/* Added text-white */}
          {t('heroSubtitle')}
        </p>
        
        <HeroSearch />

        <div className="space-x-4">
          <Button 
            asChild
            size="lg" 
            variant="secondary" 
            className="bg-white/20 hover:bg-white/30 text-white"
          >
            <Link to="/categories">
              {t('heroFindExpertButton', 'Ustani topish')}
            </Link>
          </Button>
          <Button 
            asChild
            size="lg" 
            variant="outline" 
            className="border-white/70 text-white hover:bg-white/10 hover:text-white"
          >
            <Link to={session ? "/profile" : "/register"}>
              {t('heroBecomeExpertButton', 'Usta bo\'lish')}
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
