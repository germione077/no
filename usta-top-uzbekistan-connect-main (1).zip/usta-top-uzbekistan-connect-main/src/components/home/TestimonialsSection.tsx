
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Anvar S.',
    locationKey: 'tashkentCity',
    locationDefault: 'Toshkent sh.',
    quoteKey: 'testimonialQuote1',
    quoteDefault: '"Ajoyib platforma! Santexnikni yarim soatda topdim va ishini juda tez va sifatli bajardi. Tavsiya qilaman!"',
    initials: 'AS',
  },
  {
    name: 'Sarvinoz K.',
    locationKey: 'samarkandCity',
    locationDefault: 'Samarqand sh.',
    quoteKey: 'testimonialQuote2',
    quoteDefault: '"Uy tozalash xizmatidan foydalandim. Xodimlar juda professional ekan. Uyim top-toza bo\'ldi, rahmat!"',
    initials: 'SK',
  },
  {
    name: 'Timur M.',
    locationKey: 'bukharaCity',
    locationDefault: 'Buxoro sh.',
    quoteKey: 'testimonialQuote3',
    quoteDefault: '"Mashinam buzilib qolgandi, shu sayt orqali yaxshi avtoustani topdim. Narxlari ham hamyonbop ekan."',
    initials: 'TM',
  },
];

const TestimonialsSection = () => {
  const { t } = useTranslation();

  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          {t('testimonialsTitle', 'Mijozlarimizning fikrlari')}
        </h2>
        <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
          {t('testimonialsSubtitle', 'HunarMarket.uz orqali o\'z ustasini topgan mamnun foydalanuvchilarning haqiqiy hikoyalari.')}
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="flex flex-col justify-between transform hover:-translate-y-2 transition-transform duration-300">
              <CardContent className="p-6 text-center">
                <Avatar className="mx-auto mb-4 h-16 w-16 text-xl">
                  <AvatarFallback>{testimonial.initials}</AvatarFallback>
                </Avatar>
                <div className="flex justify-center mb-2">
                    {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-amber-400 fill-amber-400" />
                    ))}
                </div>
                <blockquote className="text-muted-foreground mb-4 italic">
                  {t(testimonial.quoteKey, testimonial.quoteDefault)}
                </blockquote>
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{t(testimonial.locationKey, testimonial.locationDefault)}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
