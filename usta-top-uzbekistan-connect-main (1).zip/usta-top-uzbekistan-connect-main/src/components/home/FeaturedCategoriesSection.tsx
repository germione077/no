
import React from 'react';
import CategoryCard from '@/components/shared/CategoryCard';
import { getAllCategories } from '@/config/categories';
import { useTranslation } from 'react-i18next';

const FeaturedCategoriesSection = () => {
  const { t } = useTranslation();
  const featuredCategories = getAllCategories(t).slice(0, 4); 

  return (
    <section className="py-16 md:py-24 bg-secondary/50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          {t('featuredCategoriesTitle')}
        </h2>
        <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
          {t('featuredCategoriesSubtitle')}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {featuredCategories.map((category) => (
            <CategoryCard 
              key={category.slug}
              title={category.title}
              description={category.description}
              icon={category.icon}
              link={`/categories#${category.slug}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategoriesSection;
