
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/components/providers/AuthProvider';
import { Link } from 'react-router-dom';

const CtaSection = () => {
  const { t } = useTranslation();
  const { session } = useAuth();

  return (
    <section className="py-16 md:py-24 bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          {t('ctaTitle', 'O\'z xizmatlaringizni taklif qiling!')}
        </h2>
        <p className="text-lg md:text-xl mb-8 max-w-xl mx-auto">
          {t('ctaSubtitle', 'Agar siz malakali usta bo\'lsangiz, HunarMarket.uz platformasiga qo\'shiling va yangi mijozlarga ega bo\'ling.')}
        </p>
        <Button asChild className="bg-amber-500 hover:bg-amber-600 text-black font-semibold py-3 px-8 rounded-lg text-lg transition-colors">
          <Link to={session ? "/profile" : "/register"}>
            {t('ctaButton', 'Usta sifatida ro\'yxatdan o\'tish')}
          </Link>
        </Button>
      </div>
    </section>
  );
};

export default CtaSection;
