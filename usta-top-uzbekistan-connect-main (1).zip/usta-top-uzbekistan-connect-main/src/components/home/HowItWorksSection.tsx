
import React from 'react';
import { Search, UserCheck, MessageSquare } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const HowItWorksSection = () => {
  const { t } = useTranslation();

  const steps = [
    {
      icon: Search,
      title: t('howItWorksStep1Title', '1. Qidiring'),
      description: t('howItWorksStep1Desc', 'Kerakli xizmat turi yoki mutaxassisni qidiruv tizimimiz orqali toping.'),
    },
    {
      icon: UserCheck,
      title: t('howItWorksStep2Title', '2. Tanlang'),
      description: t('howItWorksStep2Desc', 'Ustalarning profillari, reytinglari va mijozlar fikrlarini o\'rganib chiqing.'),
    },
    {
      icon: MessageSquare,
      title: t('howItWorksStep3Title', '3. Bog\'laning'),
      description: t('howItWorksStep3Desc', 'Tanlangan usta bilan to\'g\'ridan-to\'g\'ri bog\'laning va xizmatga buyurtma bering.'),
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          {t('howItWorksTitle', 'Qanday ishlaydi?')}
        </h2>
        <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
          {t('howItWorksSubtitle', 'UstaTop orqali kerakli mutaxassisni topish juda oson. Quyidagi 3 oddiy qadamni bajaring:')}
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {steps.map((step, index) => (
            <div key={index} className="text-center p-6 border rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex justify-center mb-4">
                <div className="bg-primary/10 text-primary p-4 rounded-full">
                  <step.icon className="h-10 w-10" />
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
              <p className="text-muted-foreground text-sm">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
