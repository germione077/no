
import React from 'react';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
  NavigationMenuLink,
} from "@/components/ui/navigation-menu";
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { getAllCategories, Category } from '@/config/categories';
import { cn } from "@/lib/utils";

const ListItem = React.forwardRef<
  React.ElementRef<typeof Link>,
  React.ComponentPropsWithoutRef<typeof Link>
>(({ className, children, ...props }, ref) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <Link
          ref={ref}
          className={cn(
            "block select-none rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
            className
          )}
          {...props}
        >
          <div className="text-sm font-medium leading-none">{children}</div>
        </Link>
      </NavigationMenuLink>
    </li>
  );
});
ListItem.displayName = "ListItem";

interface CategoryColumnProps {
  category: Category;
}

const CategoryColumn: React.FC<CategoryColumnProps> = ({ category }) => (
  <div className="flex flex-col space-y-2">
    <div className="flex items-start space-x-2 px-3">
      <category.icon className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
      <h3 className="font-semibold text-base">{category.title}</h3>
    </div>
    <ul className="flex flex-col space-y-1">
      {category.subCategories.map((sub) => (
        <ListItem key={sub.slug} to={`/categories/${sub.slug}`} title={sub.title}>
          {sub.title}
        </ListItem>
      ))}
    </ul>
  </div>
);

interface CategoryNavigationDropdownProps {
  isActive?: boolean;
}

const CategoryNavigationDropdown = ({ isActive }: CategoryNavigationDropdownProps) => {
  const { t } = useTranslation();
  const categories = getAllCategories(t);

  return (
    <NavigationMenu>
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuTrigger className={cn({ "text-primary font-semibold": isActive })}>
            {t('navCategories')}
          </NavigationMenuTrigger>
          <NavigationMenuContent>
            <div className="w-full md:w-[800px] lg:w-[1000px] xl:w-[1200px] max-w-[95vw]">
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-x-8 gap-y-4 p-6">
                {categories.map((category) => (
                    <CategoryColumn key={category.slug} category={category} />
                ))}
                </div>
            </div>
          </NavigationMenuContent>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  );
};

export default CategoryNavigationDropdown;
