
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu } from 'lucide-react';
import { ModeToggle } from '@/components/shared/mode-toggle';
import { LanguageSwitcher } from '@/components/shared/language-switcher';
import { useTranslation } from 'react-i18next';
import CategoryNavigationDropdown from './CategoryNavigationDropdown';
import { useAuth } from '../providers/AuthProvider';
import UserNav from './UserNav';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const { t } = useTranslation();
  const { session, user, profile, loading } = useAuth();
  const location = useLocation();
  const { pathname } = location;

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="bg-background/80 backdrop-blur-sm sticky top-0 z-50 border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-primary">
          HunarMarket.uz
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-2">
          <Link to="/" className={cn("text-foreground hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium", { "text-primary font-semibold": pathname === '/' })}>{t('navHome')}</Link>
          <CategoryNavigationDropdown isActive={pathname.startsWith('/categories') || pathname.startsWith('/category')} />
          <Link to="/blog" className={cn("text-foreground hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium", { "text-primary font-semibold": pathname.startsWith('/blog') })}>{t('navBlog')}</Link>
          <div className="flex items-center space-x-1">
            <LanguageSwitcher />
            <ModeToggle />
            {loading ? null : session ? <UserNav /> : (
              <>
                <Button variant="outline" asChild>
                  <Link to="/login">{t('login')}</Link>
                </Button>
                <Button asChild>
                  <Link to="/register">{t('register')}</Link>
                </Button>
              </>
            )}
          </div>
        </nav>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center">
          <LanguageSwitcher />
          <ModeToggle />
          <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="ml-2">
            <Menu className="h-6 w-6" />
            <span className="sr-only">{t('mobileMenuOpen', 'Menyuni ochish')}</span>
          </Button>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t">
          <nav className="flex flex-col space-y-1 p-4">
            <Link to="/" className={cn("text-foreground hover:text-primary transition-colors block px-3 py-2 rounded-md text-base font-medium", { "text-primary font-semibold": pathname === '/' })} onClick={() => setIsMobileMenuOpen(false)}>{t('navHome')}</Link>
            <Link to="/categories" className={cn("text-foreground hover:text-primary transition-colors block px-3 py-2 rounded-md text-base font-medium", { "text-primary font-semibold": pathname.startsWith('/categories') || pathname.startsWith('/category') })} onClick={() => setIsMobileMenuOpen(false)}>{t('navCategories')}</Link>
            <Link to="/blog" className={cn("text-foreground hover:text-primary transition-colors block px-3 py-2 rounded-md text-base font-medium", { "text-primary font-semibold": pathname.startsWith('/blog') })} onClick={() => setIsMobileMenuOpen(false)}>{t('navBlog')}</Link>
            {loading ? null : session ? (
              <div className="border-t pt-4 mt-4 space-y-2">
                <Link to="/profile" onClick={() => setIsMobileMenuOpen(false)} className="flex items-center px-3 py-2 rounded-md hover:bg-accent">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={profile?.avatar_url || user?.user_metadata?.avatar_url || user?.user_metadata?.picture} alt={user?.email || ''} />
                      <AvatarFallback>{user?.email?.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="ml-3">
                      <p className="text-base font-medium leading-none">{profile?.full_name || user?.user_metadata?.full_name || user?.email}</p>
                      <p className="text-sm text-muted-foreground truncate">{user?.email}</p>
                    </div>
                </Link>
                <Button variant="ghost" className="w-full justify-start" onClick={handleLogout}>
                  {t('logout')}
                </Button>
              </div>
            ) : (
              <>
                <Button variant="outline" asChild className="w-full justify-start mt-2">
                  <Link to="/login" onClick={() => setIsMobileMenuOpen(false)}>{t('login')}</Link>
                </Button>
                <Button asChild className="w-full justify-start mt-1">
                  <Link to="/register" onClick={() => setIsMobileMenuOpen(false)}>{t('register')}</Link>
                </Button>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
