
import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const Footer = () => {
  const { t } = useTranslation();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-secondary text-secondary-foreground py-8 border-t">
      <div className="container mx-auto px-4 text-center">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold mb-2">HunarMarket.uz</h3>
            <p className="text-sm">
              {t('footerDescription', 'Eng yaxshi mahalliy mutaxassislarni topish uchun sizning ishonchli platformangiz.')}
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">{t('footerLinksTitle', 'Havolalar')}</h3>
            <ul className="space-y-1">
              <li><Link to="/about" className="hover:underline">{t('footerAboutUs', 'Biz haqimizda')}</Link></li>
              <li><Link to="/contact" className="hover:underline">{t('footerContact', 'Aloqa')}</Link></li>
              <li><Link to="/faq" className="hover:underline">{t('footerFAQ', 'FAQ')}</Link></li>
              <li><Link to="/terms" className="hover:underline">{t('footerTerms', 'Foydalanish shartlari')}</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">{t('footerSocialTitle', 'Ijtimoiy tarmoqlar')}</h3>
            <div className="flex justify-center space-x-4">
              <a href="#" className="hover:text-primary">{t('footerSocialFacebook', 'Facebook')}</a>
              <a href="#" className="hover:text-primary">{t('footerSocialInstagram', 'Instagram')}</a>
              <a href="#" className="hover:text-primary">{t('footerSocialTelegram', 'Telegram')}</a>
            </div>
          </div>
        </div>
        <p className="text-sm">{t('footerCopyright', '© {currentYear} HunarMarket.uz. Barcha huquqlar himoyalangan.', { currentYear })}</p>
      </div>
    </footer>
  );
};

export default Footer;
