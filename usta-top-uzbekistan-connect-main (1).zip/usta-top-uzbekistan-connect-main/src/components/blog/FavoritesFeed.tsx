
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { type ServicePost } from '@/types/service';
import ServiceCard from '@/components/blog/ServiceCard';
import { useAuth } from '@/components/providers/AuthProvider';

type FetchedService = ServicePost;

const fetchFavoriteServices = async (userId: string): Promise<FetchedService[]> => {
  const { data: favs, error: favsError } = await supabase
    .from('user_favorites')
    .select(`
      services (
        *,
        profiles (
          full_name,
          avatar_url
        ),
        comments (
          count
        ),
        user_favorites (
          count
        ),
        service_likes (
          count
        )
      )
    `)
    .eq('user_id', userId)
    .order('created_at', { foreignTable: 'services', ascending: false });
  
  if (favsError) {
    console.error("Error fetching favorite services:", favsError);
    throw new Error(favsError.message);
  }

  if (!favs) return [];

  return favs.map(f => f.services).filter(Boolean) as FetchedService[];
};

const FavoritesFeed = () => {
    const { t } = useTranslation();
    const { user } = useAuth();

    const { data: services, isLoading, isError, error } = useQuery<FetchedService[]>({
        queryKey: ['services-feed', 'favorites', user?.id],
        queryFn: () => fetchFavoriteServices(user!.id),
        enabled: !!user,
    });

    const { data: userFavorites } = useQuery({
        queryKey: ['user-favorites', user?.id],
        queryFn: async () => {
            if (!user) return [];
            const { data, error } = await supabase.from('user_favorites').select('service_id').eq('user_id', user.id);
            if (error) throw error;
            return data.map(f => f.service_id);
        },
        enabled: !!user,
    });

    const { data: userLikes } = useQuery({
        queryKey: ['user-likes', user?.id],
        queryFn: async () => {
            if (!user) return [];
            const { data, error } = await supabase.from('service_likes').select('service_id').eq('user_id', user.id);
            if (error) throw error;
            return data.map(l => l.service_id);
        },
        enabled: !!user,
    });

    if (isLoading) {
        return (
            <div className="max-w-xl mx-auto space-y-8">
                {Array.from({ length: 2 }).map((_, index) => (
                    <div key={index} className="bg-card sm:border sm:rounded-lg overflow-hidden">
                        <div className="flex items-center gap-3 p-4">
                            <Skeleton className="h-10 w-10 rounded-full" />
                            <Skeleton className="h-4 w-[150px]" />
                        </div>
                        <Skeleton className="w-full aspect-square" />
                        <div className="p-4 space-y-3">
                            <Skeleton className="h-5 w-1/4" />
                            <Skeleton className="h-4 w-3/4" />
                            <Skeleton className="h-4 w-1/2" />
                        </div>
                    </div>
                ))}
            </div>
        )
    }

    if (isError) {
        return (
            <div className="text-center text-destructive py-16">
                <p>{t('errorLoadingFavorites', 'Sevimlilarni yuklashda xatolik yuz berdi.')}</p>
                <p className="text-sm text-muted-foreground">{error.message}</p>
            </div>
        );
    }
    
    if (!services || services.length === 0) {
        return (
            <div className="text-center col-span-full py-16">
                <p className="text-lg text-muted-foreground">{t('noFavoriteServices', 'Sizda sevimlilarga qo\'shilgan xizmatlar mavjud emas.')}</p>
            </div>
        );
    }

    return (
        <div className="max-w-xl mx-auto space-y-8">
            {services.map((service) => (
                <ServiceCard 
                    key={service.id} 
                    service={service as ServicePost} 
                    isFavorited={userFavorites?.includes(service.id)}
                    isLiked={userLikes?.includes(service.id)}
                />
            ))}
        </div>
    );
}

export default FavoritesFeed;
