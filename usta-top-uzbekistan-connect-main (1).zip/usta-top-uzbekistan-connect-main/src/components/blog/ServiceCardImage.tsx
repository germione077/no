
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Camera, Heart } from 'lucide-react';
import { cn } from '@/lib/utils';
import { type ServicePost } from '@/types/service';

interface ServiceCardImageProps {
    service: ServicePost;
    isFavorited: boolean;
    handleFavorite: (e: React.MouseEvent) => void;
    isFaving: boolean;
}

const ServiceCardImage: React.FC<ServiceCardImageProps> = ({ service, isFavorited, handleFavorite, isFaving }) => {
    const [imageLoading, setImageLoading] = useState(true);
    const isMock = service.id.startsWith('mock-');

    return (
        <div className="relative">
            <Link to={`/service/${service.id}`} className="block aspect-square overflow-hidden bg-secondary">
                <CardContent className="p-0 h-full">
                    {service.image_urls && service.image_urls.length > 0 ? (
                        <>
                            {imageLoading && <Skeleton className="absolute inset-0 w-full h-full" />}
                            <img
                                src={service.image_urls[0]}
                                alt={service.title}
                                className={cn(
                                    "w-full h-full object-cover transition-opacity duration-300",
                                    imageLoading ? "opacity-0" : "opacity-100"
                                )}
                                onLoad={() => setImageLoading(false)}
                                onError={() => setImageLoading(false)}
                            />
                        </>
                    ) : (
                        <div className="w-full h-full flex items-center justify-center text-muted-foreground bg-muted">
                            <Camera className="w-12 h-12" />
                        </div>
                    )}
                </CardContent>
            </Link>
            <Button
                onClick={handleFavorite}
                disabled={!isMock && isFaving}
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 bg-black/30 hover:bg-black/60 text-white rounded-full h-10 w-10"
            >
                <Heart className={cn("w-5 h-5", isFavorited ? "fill-red-500 text-red-500" : "text-white")} />
            </Button>
        </div>
    );
};

export default ServiceCardImage;
