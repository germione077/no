
import React from 'react';
import { Card } from '@/components/ui/card';
import { type ServicePost } from '@/types/service';
import { useServiceInteraction } from '@/hooks/useServiceInteraction';
import ServiceCardHeader from './ServiceCardHeader';
import ServiceCardImage from './ServiceCardImage';
import ServiceCardActions from './ServiceCardActions';

interface ServiceCardProps {
    service: ServicePost;
    isFavorited?: boolean;
    isLiked?: boolean;
    onToggleMockFavorite?: (serviceId: string) => void;
    onToggleMockLike?: (serviceId: string) => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, isFavorited = false, isLiked = false, onToggleMockFavorite, onToggleMockLike }) => {
    const { handleFavorite, handleLike, isFaving, isLiking } = useServiceInteraction({
        serviceId: service.id,
        isFavorited,
        isLiked,
        isMock: service.id.startsWith('mock-'),
        onToggleMockFavorite,
        onToggleMockLike
    });

    return (
        <Card className="flex flex-col overflow-hidden shadow-sm transition-shadow duration-300 border-none rounded-none sm:rounded-lg sm:border">
            <ServiceCardHeader service={service} />
            <ServiceCardImage 
                service={service} 
                isFavorited={isFavorited}
                handleFavorite={handleFavorite} 
                isFaving={isFaving}
            />
            <ServiceCardActions
                service={service}
                isLiked={isLiked}
                handleLike={handleLike}
                isLiking={isLiking}
            />
        </Card>
    );
};

export default ServiceCard;
