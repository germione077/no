
import React from 'react';
import { Link } from 'react-router-dom';
import { CardHeader } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { type ServicePost } from '@/types/service';

interface ServiceCardHeaderProps {
    service: ServicePost;
}

const ServiceCardHeader: React.FC<ServiceCardHeaderProps> = ({ service }) => {
    return (
        <CardHeader className="flex flex-row items-center gap-3 p-4 bg-card">
            <Link to={`/specialist/${service.user_id}`} className="flex items-center gap-3 group">
                <Avatar className="h-10 w-10">
                    <AvatarImage src={service.profiles?.avatar_url || undefined} alt={service.profiles?.full_name || 'mutaxassis'} />
                    <AvatarFallback>{service.profiles?.full_name?.charAt(0).toUpperCase() || 'U'}</AvatarFallback>
                </Avatar>
                <div>
                    <p className="font-semibold group-hover:text-primary transition-colors">{service.profiles?.full_name}</p>
                </div>
            </Link>
        </CardHeader>
    );
};

export default ServiceCardHeader;
