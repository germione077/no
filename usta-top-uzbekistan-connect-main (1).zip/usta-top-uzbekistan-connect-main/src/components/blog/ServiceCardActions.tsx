
import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, ThumbsUp } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { type ServicePost } from '@/types/service';
import { cn } from '@/lib/utils';

interface ServiceCardActionsProps {
    service: ServicePost;
    isLiked: boolean;
    handleLike: (e: React.MouseEvent) => void;
    isLiking: boolean;
}

const ServiceCardActions: React.FC<ServiceCardActionsProps> = ({ service, isLiked, handleLike, isLiking }) => {
    const { t } = useTranslation();
    const isMock = service.id.startsWith('mock-');
    const likeCount = service.service_likes[0]?.count || 0;
    const favoriteCount = service.user_favorites[0]?.count || 0;
    const commentCount = service.comments[0]?.count || 0;

    return (
        <div className="p-4 flex-grow flex flex-col bg-card">
            <div className="flex items-center space-x-4 mb-3">
                <button onClick={handleLike} disabled={!isMock && isLiking} className="flex items-center text-muted-foreground hover:text-primary transition-colors">
                    <ThumbsUp className={cn("w-6 h-6", isLiked ? "fill-primary text-primary" : "text-foreground")} />
                </button>
                <Link to={`/service/${service.id}#comments`} className="flex items-center text-muted-foreground hover:text-primary transition-colors">
                    <MessageSquare className="w-6 h-6" />
                </Link>
            </div>

            {likeCount > 0 && <p className="text-sm font-semibold mb-1">{t('likes', { count: likeCount })}</p>}
            {favoriteCount > 0 && <p className="text-sm text-muted-foreground mb-2">{t('favoritesCount', { count: favoriteCount })}</p>}

            <div className="flex-grow text-sm">
                <p>
                    <Link to={`/specialist/${service.user_id}`} className="font-semibold hover:text-primary transition-colors mr-2">{service.profiles?.full_name}</Link>
                    <span>{service.description}</span>
                </p>
            </div>

            <div className="mt-2">
                <Link to={`/service/${service.id}#comments`} className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    <span>{t('viewAllComments', { count: commentCount })}</span>
                </Link>
            </div>
        </div>
    );
};

export default ServiceCardActions;
