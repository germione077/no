
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { mockServices } from '@/data/mock-services';
import { type ServicePost } from '@/types/service';
import ServiceCard from '@/components/blog/ServiceCard';
import { useAuth } from '@/components/providers/AuthProvider';

type FetchedService = ServicePost;

const fetchServices = async (): Promise<FetchedService[]> => {
  const { data, error } = await supabase
    .from('services')
    .select(`
      *,
      profiles!services_user_id_fkey (
        full_name,
        avatar_url
      ),
      comments (
        count
      ),
      user_favorites (
        count
      ),
      service_likes (
        count
      )
    `)
    .order('created_at', { ascending: false })
    .limit(20);

  if (error) {
    console.error("Error fetching services:", error);
    throw new Error(error.message);
  }

  return (data as any) || [];
};

const NewPostsFeed = () => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [mockFavorites, setMockFavorites] = React.useState<string[]>([]);
  const [mockLikes, setMockLikes] = React.useState<string[]>([]);

  const { data: services, isLoading, isError, error } = useQuery<FetchedService[]>({
    queryKey: ['services-feed', 'new'],
    queryFn: fetchServices,
  });

  const { data: userFavorites } = useQuery({
    queryKey: ['user-favorites', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('user_favorites')
        .select('service_id')
        .eq('user_id', user.id);
      if (error) throw error;
      return data.map(f => f.service_id);
    },
    enabled: !!user,
  });

  const { data: userLikes } = useQuery({
    queryKey: ['user-likes', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('service_likes')
        .select('service_id')
        .eq('user_id', user.id);
      if (error) throw error;
      return data.map(f => f.service_id);
    },
    enabled: !!user,
  });

  const handleToggleMockFavorite = (serviceId: string) => {
    setMockFavorites(prev =>
      prev.includes(serviceId)
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  const handleToggleMockLike = (serviceId: string) => {
    setMockLikes(prev =>
      prev.includes(serviceId)
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  const displayedServices: ServicePost[] = React.useMemo(() => {
    if (isLoading || isError) return [];
    const dbServices = services || [];

    const adjustedMockServices = mockServices.map(mockService => {
      const isFavorited = mockFavorites.includes(mockService.id);
      const isLiked = mockLikes.includes(mockService.id);

      const originalFavoriteCount = mockService.user_favorites[0]?.count || 0;
      const originalLikeCount = mockService.service_likes[0]?.count || 0;

      const newFavoriteCount = isFavorited ? originalFavoriteCount + 1 : originalFavoriteCount;
      const newLikeCount = isLiked ? originalLikeCount + 1 : originalLikeCount;
      
      return {
          ...mockService,
          user_favorites: [{ count: newFavoriteCount }],
          service_likes: [{ count: newLikeCount }],
      };
    });

    const allServices = [...adjustedMockServices, ...dbServices];
    allServices.sort((a, b) => new Date(b.created_at!).getTime() - new Date(a.created_at!).getTime());
    return allServices as ServicePost[];
  }, [services, isLoading, isError, mockFavorites, mockLikes]);
  
  if (isLoading) {
    return (
      <div className="max-w-xl mx-auto space-y-8">
        {Array.from({ length: 3 }).map((_, index) => (
          <div key={index} className="bg-card sm:border sm:rounded-lg overflow-hidden">
            <div className="flex items-center gap-3 p-4">
              <Skeleton className="h-10 w-10 rounded-full" />
              <Skeleton className="h-4 w-[150px]" />
            </div>
            <Skeleton className="w-full aspect-square" />
            <div className="p-4 space-y-3">
              <Skeleton className="h-5 w-1/4" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (isError) {
    return (
      <div className="text-center text-destructive py-16">
        <p>{t('errorLoadingServices', 'Xizmatlarni yuklashda xatolik yuz berdi.')}</p>
        <p className="text-sm text-muted-foreground">{error.message}</p>
      </div>
    );
  }

  if (displayedServices.length === 0) {
    return (
      <div className="text-center col-span-full py-16">
        <p className="text-lg text-muted-foreground">{t('noServicesFound', 'Hozircha hech qanday xizmatlar topilmadi.')}</p>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto space-y-8">
      {displayedServices.map((service) => {
        const isMockService = service.id.startsWith('mock-');
        return (
          <ServiceCard 
            key={service.id} 
            service={service} 
            isFavorited={isMockService ? mockFavorites.includes(service.id) : userFavorites?.includes(service.id)}
            isLiked={isMockService ? mockLikes.includes(service.id) : userLikes?.includes(service.id)}
            onToggleMockFavorite={isMockService ? handleToggleMockFavorite : undefined}
            onToggleMockLike={isMockService ? handleToggleMockLike : undefined}
          />
        );
      })}
    </div>
  );
};

export default NewPostsFeed;
