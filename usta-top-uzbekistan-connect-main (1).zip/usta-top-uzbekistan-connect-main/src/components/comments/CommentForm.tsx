
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/providers/AuthProvider';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';

const formSchema = z.object({
  content: z.string().min(1, "Izoh bo'sh bo'lishi mumkin emas.").max(1000, "Izoh juda uzun."),
});

interface CommentFormProps {
  serviceId: string;
  isMock?: boolean;
}

const CommentForm: React.FC<CommentFormProps> = ({ serviceId, isMock = false }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { content: '' },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (isMock) {
        toast({
            title: "Namuna Xizmati",
            description: "Bu namuna xizmati bo'lgani uchun izoh qo'shib bo'lmaydi.",
        });
        form.reset();
        return;
    }

    if (!user) {
      toast({ variant: 'destructive', title: 'Xatolik', description: "Izoh qoldirish uchun tizimga kiring." });
      return;
    }
    setLoading(true);

    const { error } = await supabase.from('comments').insert({
      service_id: serviceId,
      user_id: user.id,
      content: values.content,
    });

    setLoading(false);

    if (error) {
      toast({ variant: 'destructive', title: "Xatolik", description: error.message });
    } else {
      toast({ title: "Muvaffaqiyatli", description: "Izohingiz qo'shildi." });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['comments', serviceId] });
      queryClient.invalidateQueries({ queryKey: ['service-detail', serviceId] });
    }
  };

  if (!user) {
    return (
      <div className="mt-6 text-center">
        <p>Izoh qoldirish uchun, iltimos, <Link to="/login" className="text-primary hover:underline">tizimga kiring</Link> yoki <Link to="/register" className="text-primary hover:underline">ro'yxatdan o'ting</Link>.</p>
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="mt-6 space-y-4">
        <FormField
          control={form.control}
          name="content"
          render={({ field }) => (
            <FormItem>
              <FormLabel>O'z fikringizni bildiring</FormLabel>
              <FormControl>
                <Textarea placeholder="Shu xizmat haqida nima deb o'ylaysiz..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" disabled={loading}>{loading ? 'Yuborilmoqda...' : 'Yuborish'}</Button>
      </form>
    </Form>
  );
};

export default CommentForm;
