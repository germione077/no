
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { format } from 'date-fns';

interface CommentListProps {
  serviceId: string;
}

type CommentWithProfile = {
    id: string;
    created_at: string;
    content: string;
    profile: {
        full_name: string | null;
        avatar_url: string | null;
    } | null;
};

const fetchComments = async (serviceId: string): Promise<CommentWithProfile[]> => {
  const { data, error } = await supabase
    .from('comments')
    .select('id, created_at, content, profile:profiles(full_name, avatar_url)')
    .eq('service_id', serviceId)
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return data as CommentWithProfile[];
};

const CommentList: React.FC<CommentListProps> = ({ serviceId }) => {
  const { data: comments, isLoading, error } = useQuery({
    queryKey: ['comments', serviceId],
    queryFn: () => fetchComments(serviceId),
  });

  if (isLoading) {
    return (
      <div className="space-y-4 mt-6">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="flex items-start space-x-4">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-48" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return <p className="text-destructive mt-6">Izohlarni yuklashda xatolik yuz berdi.</p>;
  }
  
  if (!comments || comments.length === 0) {
    return <p className="text-muted-foreground mt-6">Hali hech kim izoh qoldirmadi. Birinchi bo'ling!</p>;
  }

  return (
    <div className="space-y-6 mt-8">
      {comments.map((comment) => {
        const profile = comment.profile;
        return (
            <div key={comment.id} className="flex items-start space-x-4">
              <Avatar>
                <AvatarImage src={profile?.avatar_url || ''} alt={profile?.full_name || 'Foydalanuvchi'} />
                <AvatarFallback>{profile?.full_name?.charAt(0) || 'F'}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="font-semibold">{profile?.full_name || 'Anonim'}</p>
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(comment.created_at), 'dd.MM.yyyy')}
                  </p>
                </div>
                <p className="text-sm mt-1 whitespace-pre-wrap">{comment.content}</p>
              </div>
            </div>
        );
      })}
    </div>
  );
};

export default CommentList;
