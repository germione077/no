
import { supabase } from '@/integrations/supabase/client';
import { Session, User } from '@supabase/supabase-js';
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import type { Database } from '@/integrations/supabase/types';

export type Profile = Database['public']['Tables']['profiles']['Row'];

interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  refetchProfile: () => void;
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  user: null,
  profile: null,
  loading: true,
  refetchProfile: () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  const fetchProfile = useCallback(async (user: User | null) => {
    console.log('AuthProvider: fetchProfile called with user:', user?.id);
    if (!user) {
      setProfile(null);
      console.log('AuthProvider: No user, setting profile to null.');
      return;
    }
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
      
      console.log('AuthProvider: Profile fetch response', { data, error });

      if (data) {
        setProfile(data);
      } else if (error) {
        console.log(`AuthProvider: Profile fetch error code: ${error?.code}`);
        // if profile doesn't exist (PGRST116), create it
        if (error.code === 'PGRST116') {
          console.log('AuthProvider: No profile found, creating one.');
          const { data: newProfile, error: insertError } = await supabase
            .from('profiles')
            .insert({
              id: user.id,
              full_name: user.user_metadata?.full_name || user.email,
              avatar_url: user.user_metadata?.avatar_url || user.user_metadata?.picture,
            })
            .select()
            .single();
          
          if (insertError) {
            console.error('AuthProvider: Error creating profile:', insertError);
            setProfile(null);
          } else {
            console.log('AuthProvider: Profile created successfully.', newProfile);
            setProfile(newProfile);
          }
        } else {
          console.error('AuthProvider: Error fetching profile:', error);
          setProfile(null);
        }
      }
    } catch (e) {
      console.error('AuthProvider: Exception fetching profile:', e);
      setProfile(null);
    }
  }, []);

  const refetchProfile = useCallback(() => {
     if(user) fetchProfile(user);
  }, [user, fetchProfile]);

  useEffect(() => {
    setLoading(true);
    console.log("AuthProvider: Setting up onAuthStateChange listener.");
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      console.log("AuthProvider: onAuthStateChange fired.", { _event, session });
      setSession(session);
      const currentUser = session?.user ?? null;
      setUser(currentUser);

      // Defer profile fetching to prevent potential deadlocks with Supabase listeners.
      setTimeout(() => {
        fetchProfile(currentUser).finally(() => {
          console.log("AuthProvider: Loading finished.");
          setLoading(false);
        });
      }, 0);
    });

    return () => {
      console.log("AuthProvider: Cleaning up onAuthStateChange listener.");
      authListener.subscription.unsubscribe();
    };
  }, [fetchProfile]);
  
  useEffect(() => {
    const isExcludedPath = ['/complete-profile', '/login', '/register'].includes(location.pathname);
    if (!loading && session && profile && !profile.profile_complete && !isExcludedPath) {
      navigate('/complete-profile');
    }
  }, [loading, session, profile, navigate, location.pathname]);


  const value = {
    session,
    user,
    profile,
    loading,
    refetchProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
