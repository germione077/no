
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import StarRating from './StarRating';
import { type Tables } from '@/integrations/supabase/types';

export type ReviewWithProfile = Tables<'service_reviews'> & {
    profile: Pick<Tables<'profiles'>, 'full_name' | 'avatar_url'> | null;
};

interface ReviewItemProps {
    review: ReviewWithProfile;
}

const ReviewItem: React.FC<ReviewItemProps> = ({ review }) => {
    return (
        <div className="flex gap-4 py-4">
            <Avatar>
                <AvatarImage src={review.profile?.avatar_url || undefined} alt={review.profile?.full_name || ''} />
                <AvatarFallback>{review.profile?.full_name?.charAt(0).toUpperCase() || 'U'}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
                <div className="flex items-center justify-between">
                    <p className="font-semibold">{review.profile?.full_name}</p>
                    <span className="text-xs text-muted-foreground">{new Date(review.created_at).toLocaleDateString()}</span>
                </div>
                <StarRating rating={review.rating} readOnly size={16} className="my-1" />
                <p className="text-sm text-muted-foreground">{review.content}</p>
            </div>
        </div>
    );
};

export default ReviewItem;
