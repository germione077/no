
import React, { useState } from 'react';
import { useAuth } from '@/components/providers/AuthProvider';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import StarRating from './StarRating';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useTranslation } from 'react-i18next';
import { Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface ReviewFormProps {
  serviceId: string;
  serviceOwnerId: string;
  isMock: boolean;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ serviceId, serviceOwnerId, isMock }) => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [rating, setRating] = useState(0);
  const [content, setContent] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: existingReview, isLoading: isLoadingExistingReview } = useQuery({
      queryKey: ['existing-review', serviceId, user?.id],
      queryFn: async () => {
          if (!user) return null;
          const { data, error } = await supabase
              .from('service_reviews')
              .select('id')
              .eq('service_id', serviceId)
              .eq('user_id', user.id)
              .maybeSingle();
          if (error) throw error;
          return data;
      },
      enabled: !!user,
  });

  const reviewMutation = useMutation({
    mutationFn: async ({ rating, content }: { rating: number; content: string }) => {
      if (!user) throw new Error("User not logged in");
      const { error } = await supabase.from('service_reviews').insert({
        service_id: serviceId,
        user_id: user.id,
        rating,
        content,
      });
      if (error) {
        if (error.code === '23505') { // unique constraint violation
            throw new Error(t('reviews.alreadyReviewedError', "Siz bu xizmatga allaqachon fikr bildirgansiz."));
        }
        throw error;
      }
    },
    onSuccess: () => {
      toast({ title: t('reviews.submitSuccessTitle', "Fikr muvaffaqiyatli yuborildi!"), description: t('reviews.submitSuccessDesc', "Fikringiz uchun rahmat.") });
      queryClient.invalidateQueries({ queryKey: ['reviews', serviceId] });
      queryClient.invalidateQueries({ queryKey: ['existing-review', serviceId, user?.id] });
      queryClient.invalidateQueries({ queryKey: ['service-detail', serviceId] });
      setRating(0);
      setContent('');
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: t('reviews.submitErrorTitle', "Xatolik"),
        description: error.message || t('reviews.submitErrorDesc', "Fikrni yuborishda xatolik yuz berdi."),
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) {
      toast({ variant: "destructive", title: t('reviews.ratingRequiredTitle', "Reyting talab qilinadi"), description: t('reviews.ratingRequiredDesc', "Iltimos, xizmatga baho bering.") });
      return;
    }
    reviewMutation.mutate({ rating, content });
  };

  if (isMock) {
    return (
        <p className="text-muted-foreground mt-6 text-center">{t('reviews.mockNoReviews', "Namuna uchun yaratilgan xizmatlarga fikr bildirish mumkin emas.")}</p>
    );
  }

  if (!user) {
    return (
        <div className="text-center p-4 border rounded-lg bg-accent/50">
            <p className="mb-2">{t('reviews.loginToReview', "Fikr qoldirish uchun tizimga kiring.")}</p>
            <Button onClick={() => navigate('/login')}>{t('login', 'Kirish')}</Button>
        </div>
    );
  }

  if (user.id === serviceOwnerId) {
    return null; // Don't show form to service owner
  }
  
  if (isLoadingExistingReview) {
      return <div className="flex justify-center py-4"><Loader2 className="animate-spin" /></div>;
  }
  
  if (existingReview) {
      return <p className="text-muted-foreground p-4 text-center bg-accent/50 rounded-lg">{t('reviews.alreadyReviewed', "Siz bu xizmatga fikr bildirgansiz.")}</p>
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 my-6 p-4 border rounded-lg">
      <h3 className="text-lg font-semibold">{t('reviews.leaveReviewTitle', "Fikr qoldirish")}</h3>
      <div>
        <label className="block text-sm font-medium text-muted-foreground mb-1">{t('reviews.yourRating', "Sizning bahoyingiz")}</label>
        <StarRating rating={rating} onRatingChange={setRating} />
      </div>
      <div>
        <label htmlFor="review-content" className="block text-sm font-medium text-muted-foreground mb-1">{t('reviews.yourComment', "Izohingiz (ixtiyoriy)")}</label>
        <Textarea
          id="review-content"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder={t('reviews.commentPlaceholder', "Xizmat haqida o'z fikrlaringizni yozing...")}
        />
      </div>
      <Button type="submit" disabled={reviewMutation.isPending}>
        {reviewMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        {t('reviews.submitButton', "Yuborish")}
      </Button>
    </form>
  );
};

export default ReviewForm;
