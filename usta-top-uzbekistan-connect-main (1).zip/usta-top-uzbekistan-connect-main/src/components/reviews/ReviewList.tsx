
import React, { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import ReviewItem, { type ReviewWithProfile } from './ReviewItem';
import { Skeleton } from '@/components/ui/skeleton';
import { useTranslation } from 'react-i18next';

interface ReviewListProps {
    serviceId: string;
    onReviewsLoaded?: (reviews: ReviewWithProfile[]) => void;
}

const ReviewList: React.FC<ReviewListProps> = ({ serviceId, onReviewsLoaded }) => {
    const { t } = useTranslation();
    const { data: reviews, isLoading, error } = useQuery({
        queryKey: ['reviews', serviceId],
        queryFn: async (): Promise<ReviewWithProfile[]> => {
            const { data: reviewsData, error } = await supabase
                .from('service_reviews')
                .select('*')
                .eq('service_id', serviceId)
                .order('created_at', { ascending: false });

            if (error) throw error;
            if (!reviewsData || reviewsData.length === 0) return [];

            const userIds = [...new Set(reviewsData.map(r => r.user_id))];
            
            const { data: profilesData, error: profilesError } = await supabase
                .from('profiles')
                .select('id, full_name, avatar_url')
                .in('id', userIds);
            
            if (profilesError) throw profilesError;

            const profilesMap = new Map(profilesData.map(p => [p.id, p]));

            return reviewsData.map(review => ({
                ...review,
                profile: profilesMap.get(review.user_id) || null
            }));
        },
        enabled: !!serviceId,
    });

    useEffect(() => {
        if (reviews && onReviewsLoaded) {
            onReviewsLoaded(reviews);
        }
    }, [reviews, onReviewsLoaded]);

    if (isLoading) {
        return (
            <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                    <div key={i} className="flex gap-4 py-4">
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div className="flex-1 space-y-2">
                            <Skeleton className="h-4 w-1/2" />
                            <Skeleton className="h-4 w-1/4" />
                            <Skeleton className="h-4 w-full" />
                        </div>
                    </div>
                ))}
            </div>
        );
    }

    if (error) {
        return <p className="text-red-500">{t('reviews.loadError', "Fikrlarni yuklashda xatolik.")}</p>;
    }
    
    if (!reviews || reviews.length === 0) {
        return <p className="text-muted-foreground mt-6 text-center">{t('reviews.noReviews', "Hali fikrlar mavjud emas.")}</p>;
    }

    return (
        <div className="divide-y">
            {reviews.map(review => (
                <ReviewItem key={review.id} review={review} />
            ))}
        </div>
    );
};

export default ReviewList;
