
import React from 'react';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StarRatingProps {
  rating: number;
  onRatingChange?: (rating: number) => void;
  readOnly?: boolean;
  size?: number;
  className?: string;
}

const StarRating: React.FC<StarRatingProps> = ({ rating, onRatingChange, readOnly = false, size = 20, className }) => {
  const [hoverRating, setHoverRating] = React.useState(0);

  return (
    <div className={cn("flex items-center", className)}>
      {[...Array(5)].map((_, index) => {
        const starValue = index + 1;
        const isFilled = starValue <= (hoverRating || rating);

        return (
          <Star
            key={starValue}
            size={size}
            className={cn(
              "transition-colors",
              isFilled ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300',
              !readOnly && 'cursor-pointer'
            )}
            onClick={() => !readOnly && onRatingChange?.(starValue)}
            onMouseEnter={() => !readOnly && setHoverRating(starValue)}
            onMouseLeave={() => !readOnly && setHoverRating(0)}
          />
        );
      })}
    </div>
  );
};

export default StarRating;
