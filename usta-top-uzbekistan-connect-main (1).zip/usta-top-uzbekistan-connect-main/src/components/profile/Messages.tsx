
import React, { useState } from 'react';
import ConversationList from './ConversationList';
import ChatView from './ChatView';
import { Tables } from '@/integrations/supabase/types';
import NewChatDialog from './NewChatDialog';
import { Textarea } from '@/components/ui/textarea';

export type ConversationWithRecipient = Tables<'conversations'> & {
    recipient: Pick<Tables<'profiles'>, 'id' | 'full_name' | 'avatar_url'>;
};

// Fake chat data for testing
const FAKE_CONVERSATION: ConversationWithRecipient = {
    id: 'fake-conversation-id',
    participant_one_id: 'fake-user-1',
    participant_two_id: 'fake-user-2',
    service_id: null,
    created_at: new Date().toISOString(),
    last_message_at: new Date().toISOString(),
    recipient: {
        id: 'fake-recipient-id',
        full_name: 'Test Foydalanuvchi',
        avatar_url: null
    }
};

const Messages: React.FC = () => {
    const [selectedConversation, setSelectedConversation] = useState<ConversationWithRecipient | null>(null);
    const [showFakeChat, setShowFakeChat] = useState(false);

    const handleConversationSelected = (conversation: ConversationWithRecipient) => {
        setSelectedConversation(conversation);
    };

    const handleFakeChatClick = () => {
        setShowFakeChat(true);
        setSelectedConversation(FAKE_CONVERSATION);
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Xabarlar</h2>
                <div className="flex gap-2">
                    <button 
                        onClick={handleFakeChatClick}
                        className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
                    >
                        Test Chat
                    </button>
                    <NewChatDialog onConversationCreated={handleConversationSelected} />
                </div>
            </div>
            <div className="flex border rounded-lg h-[calc(100vh-12rem)]">
                <div className="w-full md:w-1/3 border-r">
                    {showFakeChat && (
                        <div className="p-2">
                            <button 
                                onClick={() => handleConversationSelected(FAKE_CONVERSATION)}
                                className="w-full text-left p-3 flex items-center gap-3 hover:bg-muted/50 transition-colors bg-muted rounded-md"
                            >
                                <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                                    <span className="text-sm font-semibold">T</span>
                                </div>
                                <div className="flex-grow overflow-hidden">
                                    <div className="flex justify-between items-center">
                                        <p className="font-semibold truncate">Test Foydalanuvchi</p>
                                        <p className="text-xs text-muted-foreground flex-shrink-0">Hozir</p>
                                    </div>
                                    <p className="text-sm text-muted-foreground truncate">Test suhbati</p>
                                </div>
                            </button>
                        </div>
                    )}
                    <ConversationList onSelectConversation={handleConversationSelected} selectedConversationId={selectedConversation?.id} />
                </div>
                <div className="w-2/3 flex-col hidden md:flex">
                    {selectedConversation ? (
                        selectedConversation.id === 'fake-conversation-id' ? (
                            <FakeChatView conversation={selectedConversation} />
                        ) : (
                            <ChatView conversation={selectedConversation} />
                        )
                    ) : (
                        <div className="flex items-center justify-center h-full">
                            <p className="text-muted-foreground">Suhbatni tanlang</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

// Simple fake chat component for testing
const FakeChatView: React.FC<{ conversation: ConversationWithRecipient }> = ({ conversation }) => {
    const [messages, setMessages] = useState([
        { id: '1', content: 'Salom! Sizning xizmatlaringiz haqida ma\'lumot olsam bo\'ladimi?', sender: 'recipient', time: '10:30' },
        { id: '2', content: 'Assalomu alaykum! Albatta, qanday xizmat kerak?', sender: 'me', time: '10:32' },
        { id: '3', content: 'Men veb-sayt yaratish xizmatiga qiziqaman', sender: 'recipient', time: '10:33' }
    ]);
    const [newMessage, setNewMessage] = useState('');

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim()) {
            const message = {
                id: Date.now().toString(),
                content: newMessage,
                sender: 'me',
                time: new Date().toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' })
            };
            setMessages([...messages, message]);
            setNewMessage('');
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage(e as any);
        }
    };

    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b flex items-center gap-4">
                <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                    <span className="text-sm font-semibold">T</span>
                </div>
                <h3 className="font-semibold">{conversation.recipient.full_name}</h3>
                <span className="text-xs bg-green-100 text-green-600 px-2 py-1 rounded-full">Test Chat</span>
            </div>
            <div className="flex-grow p-4 overflow-y-auto bg-muted/20">
                {messages.map(msg => (
                    <div key={msg.id} className={`flex gap-3 my-4 ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                        {msg.sender !== 'me' && (
                            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                                <span className="text-xs font-semibold">T</span>
                            </div>
                        )}
                        <div className={`rounded-lg p-3 max-w-xs lg:max-w-md shadow-sm ${msg.sender === 'me' ? 'bg-primary text-primary-foreground' : 'bg-background'}`}>
                            <p className="text-sm">{msg.content}</p>
                            <p className="text-xs opacity-70 mt-1 text-right">{msg.time}</p>
                        </div>
                    </div>
                ))}
            </div>
            <div className="p-4 border-t bg-background">
                <form onSubmit={handleSendMessage} className="flex gap-2 items-end">
                    <Textarea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyDown={handleKeyPress}
                        placeholder="Xabar yozing... (Enter - yuborish, Shift+Enter - yangi qator)"
                        className="flex-1 min-h-[80px] max-h-32 resize-none"
                        rows={3}
                    />
                    <button 
                        type="submit" 
                        disabled={!newMessage.trim()}
                        className="px-6 py-3 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed h-fit"
                    >
                        Yuborish
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Messages;
