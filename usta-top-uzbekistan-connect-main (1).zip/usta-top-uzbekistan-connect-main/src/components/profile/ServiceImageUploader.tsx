
import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '../providers/AuthProvider';
import { useToast } from '../ui/use-toast';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Loader2, Trash2, Upload } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface ServiceImageUploaderProps {
  imageUrls: string[];
  onImageUrlsChange: (urls: string[]) => void;
}

const ServiceImageUploader: React.FC<ServiceImageUploaderProps> = ({ imageUrls, onImageUrlsChange }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files || event.target.files.length === 0 || !user) {
      return;
    }

    const file = event.target.files[0];
    const fileExt = file.name.split('.').pop();
    const fileName = `${uuidv4()}.${fileExt}`;
    const filePath = `${user.id}/${fileName}`;

    setUploading(true);
    const { error } = await supabase.storage
      .from('service-images')
      .upload(filePath, file);

    setUploading(false);

    if (error) {
      toast({ variant: 'destructive', title: "Xatolik", description: "Rasm yuklashda xatolik: " + error.message });
      return;
    }

    const { data: { publicUrl } } = supabase.storage
      .from('service-images')
      .getPublicUrl(filePath);

    if (publicUrl) {
      onImageUrlsChange([...imageUrls, publicUrl]);
      toast({ title: "Muvaffaqiyatli", description: "Rasm yuklandi." });
    }
  };

  const handleImageDelete = async (imageUrl: string) => {
    try {
      const url = new URL(imageUrl);
      const path = url.pathname;
      const filePath = path.substring(path.indexOf('/service-images/') + '/service-images/'.length);

      if (!filePath) {
        throw new Error("Noto'g'ri rasm URL manzili");
      }

      const { error } = await supabase.storage
        .from('service-images')
        .remove([filePath]);

      if (error) {
        throw error;
      } else {
        onImageUrlsChange(imageUrls.filter(url => url !== imageUrl));
        toast({ title: "Muvaffaqiyatli", description: "Rasm o'chirildi." });
      }
    } catch (error: any) {
      toast({ variant: 'destructive', title: "Xatolik", description: "Rasmni o'chirishda xatolik: " + error.message });
    }
  };

  return (
    <div className="space-y-4">
      <Label>Xizmat rasmlari</Label>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {imageUrls.map((url) => (
          <div key={url} className="relative group aspect-square">
            <img src={url} alt="Xizmat rasmi" className="rounded-md object-cover w-full h-full" />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all flex items-center justify-center">
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="opacity-0 group-hover:opacity-100"
                onClick={() => handleImageDelete(url)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
        <div className="flex items-center justify-center border-2 border-dashed rounded-md w-full aspect-square">
            <Label htmlFor="image-upload" className="cursor-pointer flex flex-col items-center justify-center space-y-2 text-center p-2">
                {uploading ? (
                    <Loader2 className="h-8 w-8 animate-spin" />
                ) : (
                    <Upload className="h-8 w-8 text-muted-foreground" />
                )}
                <span className="text-sm text-muted-foreground">Rasm yuklash</span>
            </Label>
            <Input id="image-upload" type="file" className="hidden" onChange={handleImageUpload} disabled={uploading} accept="image/png, image/jpeg, image/webp" />
        </div>
      </div>
      <p className="text-sm text-muted-foreground">
        JPG, PNG yoki WEBP formatidagi rasmlarni yuklashingiz mumkin.
      </p>
    </div>
  );
};

export default ServiceImageUploader;
