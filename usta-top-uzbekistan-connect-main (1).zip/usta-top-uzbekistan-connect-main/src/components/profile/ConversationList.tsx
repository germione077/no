
import React, { useEffect } from 'react';
import { useAuth } from '@/components/providers/AuthProvider';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { ConversationWithRecipient } from './Messages';
import { formatDistanceToNow } from 'date-fns';
import { uz } from 'date-fns/locale';

const fetchConversations = async (userId: string): Promise<ConversationWithRecipient[]> => {
    const { data, error } = await supabase
        .from('conversations')
        .select(`
            *,
            participant_one:profiles!participant_one_id(id, full_name, avatar_url),
            participant_two:profiles!participant_two_id(id, full_name, avatar_url)
        `)
        .or(`participant_one_id.eq.${userId},participant_two_id.eq.${userId}`)
        .order('last_message_at', { ascending: false });

    if (error) throw new Error(error.message);

    if (!data) return [];

    const conversationsWithRecipient = data
        .map(conv => {
            const recipientProfile = conv.participant_one_id === userId
                ? conv.participant_two
                : conv.participant_one;

            if (!recipientProfile) {
                return null;
            }

            const { participant_one, participant_two, ...rest } = conv;

            return {
                ...rest,
                recipient: recipientProfile,
            };
        })
        .filter((c): c is ConversationWithRecipient => c !== null);

    return conversationsWithRecipient;
};


interface ConversationListProps {
    onSelectConversation: (conversation: ConversationWithRecipient) => void;
    selectedConversationId?: string | null;
}

const ConversationList: React.FC<ConversationListProps> = ({ onSelectConversation, selectedConversationId }) => {
    const { user } = useAuth();
    const queryClient = useQueryClient();

    const { data: conversations, isLoading, error } = useQuery({
        queryKey: ['conversations', user?.id],
        queryFn: () => fetchConversations(user!.id),
        enabled: !!user,
    });

    useEffect(() => {
        if (!user) return;
        const channel = supabase
            .channel(`conversations:${user.id}`)
            .on(
                'postgres_changes',
                { event: '*', schema: 'public', table: 'conversations' },
                () => {
                    queryClient.invalidateQueries({ queryKey: ['conversations', user.id] });
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, [user, queryClient]);


    if (isLoading) {
        return (
            <div className="p-2 space-y-2">
                {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
            </div>
        );
    }

    if (error) {
        return <p className="p-4 text-destructive text-sm">Suhbatlarni yuklashda xatolik.</p>;
    }
    
    if (!conversations || conversations.length === 0) {
        return <p className="p-4 text-center text-muted-foreground text-sm">Suhbatlar topilmadi.</p>;
    }

    return (
        <div className="h-full overflow-y-auto">
            {conversations.map(conv => (
                <button
                    key={conv.id}
                    onClick={() => onSelectConversation(conv)}
                    className={cn(
                        "w-full text-left p-3 flex items-center gap-3 hover:bg-muted/50 transition-colors",
                        selectedConversationId === conv.id && "bg-muted"
                    )}
                >
                    <Avatar>
                        <AvatarImage src={conv.recipient.avatar_url || undefined} alt={conv.recipient.full_name || 'Avatar'} />
                        <AvatarFallback>{conv.recipient.full_name?.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-grow overflow-hidden">
                        <div className="flex justify-between items-center">
                            <p className="font-semibold truncate">{conv.recipient.full_name}</p>
                            {conv.last_message_at && (
                                <p className="text-xs text-muted-foreground flex-shrink-0">
                                    {formatDistanceToNow(new Date(conv.last_message_at), { addSuffix: true, locale: uz })}
                                </p>
                            )}
                        </div>
                    </div>
                </button>
            ))}
        </div>
    );
};

export default ConversationList;
