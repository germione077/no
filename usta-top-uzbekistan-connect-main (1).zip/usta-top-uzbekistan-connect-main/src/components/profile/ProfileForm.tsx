
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth, Profile } from '../providers/AuthProvider';
import { useTranslation } from 'react-i18next';
import { getAllCategories } from '@/config/categories';

const getFormSchema = (t: (key: string) => string) => z.object({
  full_name: z.string().min(2, t('profileFormFullNameMinError')).optional(),
  username: z.string()
    .min(3, t('profileFormUsernameMinError'))
    .max(20, t('profileFormUsernameMaxError'))
    .regex(/^[a-z0-9_]+$/, t('profileFormUsernameRegexError'))
    .optional()
    .or(z.literal('')),
  phone_number: z.string().optional(),
  location_city: z.string().optional(),
  location_district: z.string().optional(),
  specialty: z.string().optional(),
  experience_years: z.coerce.number().min(0, t('profileFormExperienceMinError')).optional(),
  price_per_service: z.coerce.number().min(0, t('profileFormPriceMinError')).optional(),
});

interface ProfileFormProps {
  profile: Profile;
}

const ProfileForm: React.FC<ProfileFormProps> = ({ profile }) => {
  const { user, refetchProfile } = useAuth();
  const { toast } = useToast();
  const { t } = useTranslation();

  const formSchema = getFormSchema(t);
  
  const categories = getAllCategories(t);
  const allSubCategories = React.useMemo(() => categories.flatMap(category => 
    category.subCategories.map(sub => ({ ...sub, mainCategory: category.title }))
  ), [categories]);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      full_name: profile.full_name || '',
      username: profile.username || '',
      phone_number: profile.phone_number || '',
      location_city: profile.location_city || '',
      location_district: profile.location_district || '',
      specialty: profile.specialty || '',
      experience_years: profile.experience_years ?? undefined,
      price_per_service: profile.price_per_service ?? undefined,
    },
  });

  React.useEffect(() => {
    if (profile) {
      form.reset({
        full_name: profile.full_name || '',
        username: profile.username || '',
        phone_number: profile.phone_number || '',
        location_city: profile.location_city || '',
        location_district: profile.location_district || '',
        specialty: profile.specialty || '',
        experience_years: profile.experience_years ?? undefined,
        price_per_service: profile.price_per_service ?? undefined,
      });
    }
  }, [profile, form]);

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!user) return;

    if (values.username && values.username !== profile.username) {
        const { data: existingUser, error: checkError } = await supabase
            .from('profiles')
            .select('id')
            .eq('username', values.username)
            .neq('id', user.id)
            .maybeSingle();

        if (checkError) {
            toast({ variant: 'destructive', title: t('errorTitle'), description: t('profileFormUsernameCheckError') });
            return;
        }

        if (existingUser) {
            form.setError('username', {
                type: 'manual',
                message: t('profileFormUsernameTakenError'),
            });
            return;
        }
    }

    const { error } = await supabase
      .from('profiles')
      .update({
        ...values,
        username: values.username || null, // Ensure empty string becomes null
        updated_at: new Date().toISOString(),
      })
      .eq('id', user.id);

    if (error) {
      toast({ variant: 'destructive', title: t('errorTitle'), description: t('profileFormUpdateError') });
    } else {
      toast({ title: t('successTitle'), description: t('profileFormUpdateSuccess') });
      await refetchProfile();
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="full_name" render={({ field }) => (
          <FormItem>
            <FormLabel>{t('profileFormFullNameLabel')}</FormLabel>
            <FormControl><Input placeholder={t('profileFormFullNamePlaceholder')} {...field} value={field.value ?? ''} /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="username" render={({ field }) => (
            <FormItem>
                <FormLabel>{t('profileFormUsernameLabel')}</FormLabel>
                <FormControl><Input placeholder={t('profileFormUsernamePlaceholder')} {...field} value={field.value ?? ''} /></FormControl>
                <FormDescription>{t('profileFormUsernameDescription')}</FormDescription>
                <FormMessage />
            </FormItem>
        )} />
        <FormField control={form.control} name="phone_number" render={({ field }) => (
          <FormItem>
            <FormLabel>{t('profileFormPhoneNumberLabel')}</FormLabel>
            <FormControl><Input placeholder={t('profileFormPhoneNumberPlaceholder')} {...field} value={field.value ?? ''} /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField control={form.control} name="location_city" render={({ field }) => (
                <FormItem>
                    <FormLabel>{t('profileFormCityLabel')}</FormLabel>
                    <FormControl><Input placeholder={t('profileFormCityPlaceholder')} {...field} value={field.value ?? ''} /></FormControl>
                    <FormMessage />
                </FormItem>
            )} />
            <FormField control={form.control} name="location_district" render={({ field }) => (
                <FormItem>
                    <FormLabel>{t('profileFormDistrictLabel')}</FormLabel>
                    <FormControl><Input placeholder={t('profileFormDistrictPlaceholder')} {...field} value={field.value ?? ''} /></FormControl>
                    <FormMessage />
                </FormItem>
            )} />
        </div>

        {profile.role === 'provider' && (
          <>
            <FormField
              control={form.control}
              name="specialty"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('profileFormSpecialtyLabel')}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder={t('profileFormSpecialtyPlaceholder')} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <React.Fragment key={category.slug}>
                          <FormLabel className="px-2 py-1.5 text-sm font-semibold">{category.title}</FormLabel>
                          {category.subCategories.map((subCategory) => (
                            <SelectItem key={subCategory.slug} value={subCategory.slug}>
                              {subCategory.title}
                            </SelectItem>
                          ))}
                        </React.Fragment>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="experience_years" render={({ field }) => (
                    <FormItem>
                        <FormLabel>{t('profileFormExperienceLabel')}</FormLabel>
                        <FormControl><Input type="number" {...field} value={field.value ?? ''} /></FormControl>
                        <FormMessage />
                    </FormItem>
                )} />
                <FormField control={form.control} name="price_per_service" render={({ field }) => (
                    <FormItem>
                        <FormLabel>{t('profileFormPriceLabel')}</FormLabel>
                        <FormControl><Input type="number" {...field} value={field.value ?? ''} /></FormControl>
                        <FormMessage />
                    </FormItem>
                )} />
            </div>
          </>
        )}

        <div className="flex justify-end gap-4 pt-4">
            <Button type="button" variant="outline" onClick={() => form.reset()} disabled={form.formState.isSubmitting || !form.formState.isDirty}>
              {t('cancel')}
            </Button>
            <Button type="submit" disabled={form.formState.isSubmitting || !form.formState.isDirty}>
              {form.formState.isSubmitting ? t('profileFormSaving') : t('profileFormSaveChanges')}
            </Button>
        </div>
      </form>
    </Form>
  );
};

export default ProfileForm;
