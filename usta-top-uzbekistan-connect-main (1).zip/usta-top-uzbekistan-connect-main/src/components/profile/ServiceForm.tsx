import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '../providers/AuthProvider';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { Tables, TablesInsert } from '@/integrations/supabase/types';
import { getAllCategories } from '@/config/categories';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useTranslation } from 'react-i18next';
import ServiceImageUploader from './ServiceImageUploader';

type Service = Tables<'services'>;

const formSchema = z.object({
    title: z.string().min(5, "Sarlavha kamida 5 belgidan iborat bo'lishi kerak."),
    description: z.string().optional(),
    price: z.coerce.number({invalid_type_error: "Iltimos, son kiriting"}).positive("Narx musbat son bo'lishi kerak.").optional().nullable(),
    price_unit: z.string().optional().nullable(),
    category_slug: z.string().min(1, "Kategoriya tanlanishi shart."),
    image_urls: z.array(z.string()).optional(),
});

interface ServiceFormProps {
    serviceToEdit?: Service | null;
}

const ServiceForm: React.FC<ServiceFormProps> = ({ serviceToEdit }) => {
    const { user, profile } = useAuth();
    const { toast } = useToast();
    const navigate = useNavigate();
    const queryClient = useQueryClient();
    const [loading, setLoading] = useState(false);
    const { t } = useTranslation();
    const categories = getAllCategories(t);

    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            title: serviceToEdit?.title || '',
            description: serviceToEdit?.description || '',
            price: serviceToEdit?.price || null,
            price_unit: serviceToEdit?.price_unit || null,
            category_slug: serviceToEdit?.category_slug || '',
            image_urls: serviceToEdit?.image_urls || [],
        },
    });

    const onSubmit = async (values: z.infer<typeof formSchema>) => {
        if (!user) return;
        setLoading(true);

        const serviceData = {
            ...values,
            user_id: user.id,
            location_city: profile?.location_city, // Automatically add user's location
            location_district: profile?.location_district,
        };
        
        let error;
        if (serviceToEdit) {
            const { error: updateError } = await supabase
                .from('services')
                .update(serviceData)
                .eq('id', serviceToEdit.id);
            error = updateError;
        } else {
            const { error: insertError } = await supabase
                .from('services')
                .insert(serviceData as TablesInsert<'services'>);
            error = insertError;
        }

        setLoading(false);

        if (error) {
            toast({ variant: 'destructive', title: "Xatolik", description: error.message });
        } else {
            toast({ title: "Muvaffaqiyatli", description: "Xizmat muvaffaqiyatli saqlandi." });
            queryClient.invalidateQueries({ queryKey: ['my-services', user.id] });
            navigate('/profile');
        }
    };

    return (
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Xizmat sarlavhasi</FormLabel>
                            <FormControl>
                                <Input placeholder="Masalan, Santexnika ishlari" {...field} />
                            </FormControl>
                            <FormDescription>Xizmatingiz uchun qisqa va tushunarli sarlavha kiriting.</FormDescription>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                
                <FormField
                  control={form.control}
                  name="category_slug"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Kategoriya</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Kategoriyani tanlang" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories.map(cat => (
                            <SelectItem key={cat.slug} value={cat.slug}>{cat.title}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Batafsil ma'lumot</FormLabel>
                            <FormControl>
                                <Textarea rows={5} placeholder="Xizmatingiz, tajribangiz va ish uslubingiz haqida batafsil yozing..." {...field} />
                            </FormControl>
                            <FormMessage />
                        </FormItem>
                    )}
                />

                <FormField
                  control={form.control}
                  name="image_urls"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <ServiceImageUploader
                          imageUrls={field.value || []}
                          onImageUrlsChange={field.onChange}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <FormField
                        control={form.control}
                        name="price"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>Narxi (ixtiyoriy)</FormLabel>
                                <FormControl>
                                    <Input type="number" placeholder="100000" {...field} value={field.value ?? ''} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={form.control}
                        name="price_unit"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>O'lchov birligi (ixtiyoriy)</FormLabel>
                                <FormControl>
                                    <Input placeholder="so'm, so'm/soat, dona" {...field} value={field.value ?? ''} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                </div>

                <Button type="submit" disabled={loading}>{loading ? "Saqlanmoqda..." : "Saqlash"}</Button>
            </form>
        </Form>
    );
};

export default ServiceForm;
