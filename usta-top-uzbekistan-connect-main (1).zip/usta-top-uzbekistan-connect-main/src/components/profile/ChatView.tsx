
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/components/providers/AuthProvider';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send, Loader2 } from 'lucide-react';
import { Tables } from '@/integrations/supabase/types';
import { ConversationWithRecipient } from './Messages';
import { format } from 'date-fns';
import { Skeleton } from '../ui/skeleton';

type Message = Tables<'messages'> & { sender_profile: Pick<Tables<'profiles'>, 'id' | 'full_name' | 'avatar_url'> };

const fetchMessages = async (conversationId: string): Promise<Message[]> => {
    const { data, error } = await supabase
        .from('messages')
        .select(`*, sender_profile:sender_id(id, full_name, avatar_url)`)
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });
    
    if (error) throw new Error(error.message);
    return data as Message[];
};

interface ChatViewProps {
    conversation: ConversationWithRecipient;
}

const ChatView: React.FC<ChatViewProps> = ({ conversation }) => {
    const { user } = useAuth();
    const queryClient = useQueryClient();
    const [newMessage, setNewMessage] = useState('');
    const messagesEndRef = useRef<null | HTMLDivElement>(null);

    const { data: messages, isLoading } = useQuery({
        queryKey: ['messages', conversation.id],
        queryFn: () => fetchMessages(conversation.id),
        staleTime: 1000 * 5, // 5 seconds
        enabled: !!conversation.id,
    });
    
    const mutation = useMutation({
        mutationFn: async (content: string) => {
            if (!user) throw new Error("User not authenticated");
            const { error } = await supabase.from('messages').insert({
                conversation_id: conversation.id,
                sender_id: user.id,
                content,
            });
            if (error) throw error;
        },
        onSuccess: () => {
            setNewMessage('');
        },
    });

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }

    useEffect(scrollToBottom, [messages]);
    
    useEffect(() => {
        const channel = supabase
            .channel(`chat:${conversation.id}`)
            .on(
                'postgres_changes',
                { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversation.id}` },
                (payload) => {
                    queryClient.setQueryData(['messages', conversation.id], (oldData: Message[] | undefined) => {
                        const newMsg = { ...payload.new, sender_profile: { id: payload.new.sender_id }}; // Temp profile
                        return oldData ? [...oldData, newMsg as Message] : [newMsg as Message];
                    });
                    queryClient.invalidateQueries({ queryKey: ['conversations', user?.id] });
                }
            )
            .subscribe();

        return () => {
            supabase.removeChannel(channel);
        };
    }, [conversation.id, queryClient, user?.id]);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim()) {
            mutation.mutate(newMessage.trim());
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage(e as any);
        }
    };

    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b flex items-center gap-4">
                <Avatar>
                    <AvatarImage src={conversation.recipient.avatar_url || undefined} alt={conversation.recipient.full_name || 'Avatar'} />
                    <AvatarFallback>{conversation.recipient.full_name?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <h3 className="font-semibold">{conversation.recipient.full_name}</h3>
            </div>
            <div className="flex-grow p-4 overflow-y-auto bg-muted/20">
                {isLoading && (
                    <div className="space-y-4">
                        <Skeleton className="h-12 w-2/3" />
                        <Skeleton className="h-12 w-1/2 ml-auto" />
                        <Skeleton className="h-16 w-3/4" />
                    </div>
                )}
                {messages?.map(msg => (
                    <div key={msg.id} className={`flex gap-3 my-4 ${msg.sender_id === user?.id ? 'justify-end' : 'justify-start'}`}>
                        {msg.sender_id !== user?.id && (
                            <Avatar className="h-8 w-8">
                                <AvatarImage src={msg.sender_profile?.avatar_url || undefined} />
                                <AvatarFallback>{msg.sender_profile?.full_name?.charAt(0).toUpperCase()}</AvatarFallback>
                            </Avatar>
                        )}
                        <div className={`rounded-lg p-3 max-w-xs lg:max-w-md shadow-sm ${msg.sender_id === user?.id ? 'bg-primary text-primary-foreground' : 'bg-background'}`}>
                            <p className="text-sm">{msg.content}</p>
                            <p className="text-xs opacity-70 mt-1 text-right">{format(new Date(msg.created_at), 'HH:mm')}</p>
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>
            <div className="p-4 border-t bg-background">
                <form onSubmit={handleSendMessage} className="flex gap-2 items-end">
                    <Textarea
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyDown={handleKeyPress}
                        placeholder="Xabar yozing... (Enter - yuborish, Shift+Enter - yangi qator)"
                        className="flex-1 min-h-[80px] max-h-32 resize-none"
                        rows={3}
                        disabled={mutation.isPending}
                    />
                    <Button 
                        type="submit" 
                        size="default"
                        disabled={mutation.isPending || !newMessage.trim()}
                        className="h-fit px-6 py-3"
                    >
                        {mutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    </Button>
                </form>
            </div>
        </div>
    );
};

export default ChatView;
