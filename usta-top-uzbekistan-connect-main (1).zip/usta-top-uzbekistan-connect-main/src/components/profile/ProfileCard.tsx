
import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { Profile } from '../providers/AuthProvider';
import ProfileForm from './ProfileForm';
import RoleSwitcher from './RoleSwitcher';
import { Button } from '@/components/ui/button';
import { LogOut, User, Lock, Briefcase } from 'lucide-react';
import AvatarUploader from './AvatarUploader';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import PasswordChangeForm from './PasswordChangeForm';
import MyServicesList from './MyServicesList';
import { useTranslation } from 'react-i18next';

interface ProfileCardProps {
    profile: Profile;
}

const ProfileCard: React.FC<ProfileCardProps> = ({ profile }) => {
    const navigate = useNavigate();
    const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
    const [activeView, setActiveView] = useState<'profile' | 'services'>(
        profile.role === 'provider' ? 'services' : 'profile'
    );
    const { t } = useTranslation();

    const handleLogout = async () => {
        await supabase.auth.signOut();
        navigate('/login');
    };
    
    return (
        <div className="bg-card rounded-xl shadow-lg p-6 md:p-8 flex flex-col md:flex-row w-full max-w-6xl gap-8">
            {/* Left Column */}
            <div className="flex-shrink-0 md:w-64 space-y-6 flex flex-col items-center md:items-stretch">
                <AvatarUploader profile={profile} />
                <nav className="flex flex-col space-y-2 pt-6">
                    <Button variant="ghost" className={`justify-start ${activeView === 'profile' ? 'bg-muted' : ''}`} onClick={() => setActiveView('profile')}>
                        <User className="mr-2" />
                        {t('profileNavPersonalInfo')}
                    </Button>
                    {profile.role === 'provider' && (
                        <Button variant="ghost" className={`justify-start ${activeView === 'services' ? 'bg-muted' : ''}`} onClick={() => setActiveView('services')}>
                            <Briefcase className="mr-2" />
                            {t('profileNavMyServices')}
                        </Button>
                    )}
                    <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
                        <DialogTrigger asChild>
                            <Button variant="ghost" className="justify-start">
                                <Lock className="mr-2" />
                                {t('profileNavChangePassword')}
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[425px]">
                            <DialogHeader>
                                <DialogTitle>{t('changePasswordDialogTitle')}</DialogTitle>
                                <DialogDescription>
                                    {t('changePasswordDialogDescription')}
                                </DialogDescription>
                            </DialogHeader>
                            <PasswordChangeForm onSuccess={() => setIsPasswordDialogOpen(false)} />
                        </DialogContent>
                    </Dialog>
                    <Button variant="ghost" className="justify-start text-destructive hover:text-destructive" onClick={handleLogout}>
                        <LogOut className="mr-2" />
                        {t('logout')}
                    </Button>
                </nav>
            </div>

            {/* Right Column */}
            <div className="flex-grow">
                {activeView === 'profile' && (
                    <>
                        <h2 className="text-2xl font-bold mb-6">{t('personalInfoTitle')}</h2>
                        <ProfileForm profile={profile} />
                        <div className="mt-8">
                          <RoleSwitcher profile={profile} />
                        </div>
                    </>
                )}
                {activeView === 'services' && profile.role === 'provider' && <MyServicesList />}
            </div>
        </div>
    );
};

export default ProfileCard;
