
import React, { useState } from 'react';
import { useAuth } from '@/components/providers/AuthProvider';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '../ui/use-toast';
import { Tables } from '@/integrations/supabase/types';
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useTranslation } from 'react-i18next';

type Service = Tables<'services'>;

const fetchMyServices = async (userId: string): Promise<Service[]> => {
    const { data, error } = await supabase
        .from('services')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

    if (error) {
        throw new Error(error.message);
    }
    return data;
};

const MyServicesList: React.FC = () => {
    const { user } = useAuth();
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [serviceToDelete, setServiceToDelete] = useState<string | null>(null);
    const { t } = useTranslation();

    const { data: services, isLoading, error } = useQuery({
        queryKey: ['my-services', user?.id],
        queryFn: () => fetchMyServices(user!.id),
        enabled: !!user,
    });

    const handleDeleteClick = (serviceId: string) => {
        setServiceToDelete(serviceId);
        setIsDeleteDialogOpen(true);
    };

    const confirmDelete = async () => {
        if (!serviceToDelete) return;

        const { error } = await supabase.from('services').delete().eq('id', serviceToDelete);
        if (error) {
            toast({ variant: 'destructive', title: t('errorTitle'), description: t('deleteServiceError') });
        } else {
            toast({ title: t('successTitle'), description: t('deleteServiceSuccess') });
            queryClient.invalidateQueries({ queryKey: ['my-services', user?.id] });
        }
        setServiceToDelete(null);
        setIsDeleteDialogOpen(false);
    };

    if (isLoading) {
        return (
            <div>
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold">{t('myServicesTitle')}</h2>
                    <Skeleton className="h-10 w-48" />
                </div>
                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {[...Array(2)].map((_, i) => (
                        <Card key={i}>
                            <CardHeader>
                                <Skeleton className="h-6 w-3/4 mb-2" />
                                <Skeleton className="h-4 w-1/2" />
                            </CardHeader>
                            <CardContent>
                                <Skeleton className="h-10 w-full" />
                            </CardContent>
                            <CardFooter className="flex justify-end gap-2">
                                <Skeleton className="h-9 w-24" />
                                <Skeleton className="h-9 w-24" />
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            </div>
        );
    }

    

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">{t('myServicesTitle')}</h2>
                <Button asChild>
                    <Link to="/profile/services/new">
                        <PlusCircle className="mr-2 h-4 w-4" /> {t('addNewService')}
                    </Link>
                </Button>
            </div>

            {services && services.length > 0 ? (
                <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {services.map(service => (
                        <Card key={service.id}>
                            <CardHeader>
                                <CardTitle>{service.title}</CardTitle>
                                {service.price && <CardDescription>{service.price} {service.price_unit}</CardDescription>}
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-muted-foreground line-clamp-3">{service.description}</p>
                            </CardContent>
                            <CardFooter className="flex justify-end gap-2">
                                <Button variant="outline" size="sm" asChild>
                                    <Link to={`/profile/services/${service.id}/edit`}>
                                        <Edit className="mr-2 h-4 w-4" /> {t('edit')}
                                    </Link>
                                </Button>
                                <Button variant="destructive" size="sm" onClick={() => handleDeleteClick(service.id)}>
                                    <Trash2 className="mr-2 h-4 w-4" /> {t('delete')}
                                </Button>
                            </CardFooter>
                        </Card>
                    ))}
                </div>
            ) : (
                <div className="text-center py-12 border-2 border-dashed rounded-lg">
                    <h3 className="text-lg font-medium">{t('noServicesYet')}</h3>
                    <p className="text-sm text-muted-foreground mt-1 mb-4">{t('addFirstServicePrompt')}</p>
                    <Button asChild>
                        <Link to="/profile/services/new">
                            <PlusCircle className="mr-2 h-4 w-4" /> {t('addNewService')}
                        </Link>
                    </Button>
                </div>
            )}
            <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>{t('confirmDeleteTitle')}</AlertDialogTitle>
                        <AlertDialogDescription>
                            {t('confirmDeleteDescription')}
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel onClick={() => setServiceToDelete(null)}>{t('cancel')}</AlertDialogCancel>
                        <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                            {t('delete')}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
};

export default MyServicesList;
