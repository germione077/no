
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/providers/AuthProvider';
import { Loader2, Plus, Search } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Tables } from '@/integrations/supabase/types';
import { ConversationWithRecipient } from './Messages';
import { useToast } from '../ui/use-toast';

type Profile = Pick<Tables<'profiles'>, 'id' | 'full_name' | 'avatar_url' | 'username'>;

const searchUsers = async (searchTerm: string, currentUserId: string): Promise<Profile[]> => {
    if (!searchTerm) return [];
    
    const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, avatar_url, username')
        .ilike('username', `%${searchTerm}%`)
        .neq('id', currentUserId)
        .limit(10);

    if (error) throw new Error(error.message);
    return data || [];
};


interface NewChatDialogProps {
    onConversationCreated: (conversation: ConversationWithRecipient) => void;
}


const NewChatDialog: React.FC<NewChatDialogProps> = ({ onConversationCreated }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
    const { user } = useAuth();
    const queryClient = useQueryClient();
    const { toast } = useToast();

    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedSearchTerm(searchTerm);
        }, 500);

        return () => {
            clearTimeout(handler);
        };
    }, [searchTerm]);
    
    const { data: users, isLoading: isSearching } = useQuery({
        queryKey: ['user-search', debouncedSearchTerm],
        queryFn: () => searchUsers(debouncedSearchTerm, user!.id),
        enabled: !!debouncedSearchTerm && !!user,
    });
    
    const conversationMutation = useMutation({
        mutationFn: async (recipient: Profile) => {
            if (!user) throw new Error("User not authenticated");
            if (user.id === recipient.id) throw new Error("O'zingiz bilan suhbat yarata olmaysiz.");

            // Check for existing conversation without a service
            const { data: existing, error: findError } = await supabase
                .from('conversations')
                .select('*')
                .or(`(participant_one_id.eq.${user.id},participant_two_id.eq.${recipient.id}),(participant_one_id.eq.${recipient.id},participant_two_id.eq.${user.id})`)
                .is('service_id', null)
                .maybeSingle();

            if (findError) throw findError;

            if (existing) {
                return { ...existing, recipient };
            }

            // Create new conversation
            const { data: newConversation, error: createError } = await supabase
                .from('conversations')
                .insert({
                    participant_one_id: user.id,
                    participant_two_id: recipient.id,
                    service_id: null,
                })
                .select()
                .single();
            
            if (createError) throw createError;
            if (!newConversation) throw new Error("Suhbat yaratib bo'lmadi.");

            return { ...newConversation, recipient };
        },
        onSuccess: (data: ConversationWithRecipient) => {
            queryClient.invalidateQueries({ queryKey: ['conversations', user?.id] });
            onConversationCreated(data);
            setIsOpen(false);
            setSearchTerm('');
        },
        onError: (error: any) => {
             toast({
                variant: "destructive",
                title: "Xatolik",
                description: error.message || "Suhbatni boshlashda xatolik yuz berdi.",
            });
        }
    });

    const handleUserSelect = (selectedUser: Profile) => {
        conversationMutation.mutate(selectedUser);
    }

    return (
        <Dialog open={isOpen} onOpenChange={(open) => {
            if (!open) {
                setSearchTerm('');
                setDebouncedSearchTerm('');
            }
            setIsOpen(open);
        }}>
            <DialogTrigger asChild>
                <Button>
                    <Plus className="mr-2 h-4 w-4" /> Yangi suhbat
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Yangi suhbat</DialogTitle>
                </DialogHeader>
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder="Foydalanuvchi nomi bo'yicha qidirish..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                        disabled={conversationMutation.isPending}
                    />
                </div>
                <div className="mt-4 space-y-2 h-60 overflow-y-auto">
                    {isSearching && <div className="flex items-center justify-center p-4"><Loader2 className="h-6 w-6 animate-spin" /></div>}
                    
                    {conversationMutation.isPending && (
                         <div className="flex items-center justify-center p-4">
                            <Loader2 className="h-6 w-6 animate-spin" />
                            <p className="ml-2">Suhbat yaratilmoqda...</p>
                        </div>
                    )}

                    {!isSearching && users?.length === 0 && debouncedSearchTerm && !conversationMutation.isPending && (
                        <p className="text-center text-sm text-muted-foreground p-4">Foydalanuvchi topilmadi.</p>
                    )}
                    
                    {!isSearching && users && !conversationMutation.isPending && users.map(u => (
                        <button 
                            key={u.id} 
                            onClick={() => handleUserSelect(u)}
                            className="w-full flex items-center gap-3 p-2 rounded-md hover:bg-muted disabled:opacity-50 text-left"
                            disabled={conversationMutation.isPending}
                        >
                            <Avatar>
                                <AvatarImage src={u.avatar_url || undefined} alt={u.full_name || 'Avatar'}/>
                                <AvatarFallback>{u.full_name?.charAt(0).toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div className="flex flex-col">
                                <span className="font-medium">{u.full_name}</span>
                                <span className="text-sm text-muted-foreground">@{u.username}</span>
                            </div>
                        </button>
                    ))}
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default NewChatDialog;
