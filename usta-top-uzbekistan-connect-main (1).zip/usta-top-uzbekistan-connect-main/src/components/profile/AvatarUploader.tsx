
import React, { useState } from 'react';
import { useAuth, Profile } from '../providers/AuthProvider';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Camera, Loader2 } from 'lucide-react';

interface AvatarUploaderProps {
    profile: Profile;
}

const AvatarUploader: React.FC<AvatarUploaderProps> = ({ profile }) => {
    const { user, refetchProfile } = useAuth();
    const { toast } = useToast();
    const [isUploading, setIsUploading] = useState(false);

    const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
        if (!user || !event.target.files || event.target.files.length === 0) {
            return;
        }

        const file = event.target.files[0];
        const fileExt = file.name.split('.').pop();
        const filePath = `${user.id}/avatar.${fileExt}`;

        try {
            setIsUploading(true);

            const { error: uploadError } = await supabase.storage
                .from('avatars')
                .upload(filePath, file, { upsert: true });

            if (uploadError) {
                throw uploadError;
            }
            
            const { data: urlData } = supabase.storage
                .from('avatars')
                .getPublicUrl(filePath);

            if (!urlData.publicUrl) {
                throw new Error("Rasm uchun umumiy URL manzili olib bo'lmadi.");
            }
            
            const avatarUrl = `${urlData.publicUrl}?t=${new Date().getTime()}`;

            const { error: updateError } = await supabase
                .from('profiles')
                .update({ avatar_url: avatarUrl })
                .eq('id', user.id);

            if (updateError) {
                throw updateError;
            }

            refetchProfile();

            toast({
                title: "Muvaffaqiyatli",
                description: "Profilingiz rasmi yangilandi.",
            });

        } catch (error: any) {
            console.error("Error uploading avatar:", error);
            toast({
                variant: 'destructive',
                title: "Xatolik",
                description: error.message || "Rasm yuklashda xatolik yuz berdi.",
            });
        } finally {
            setIsUploading(false);
        }
    };

    return (
        <div className="flex flex-col items-center text-center">
             <div className="relative">
                <Avatar className="h-24 w-24">
                    <AvatarImage src={profile.avatar_url || ''} alt={user?.email || 'avatar'} key={profile.avatar_url} />
                    <AvatarFallback>{user?.email?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <label 
                    htmlFor="avatar-upload" 
                    className="absolute bottom-0 right-0 bg-background p-2 rounded-full cursor-pointer border hover:bg-accent transition-colors"
                    title="Rasmni o'zgartirish"
                >
                    {isUploading ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                        <Camera className="h-5 w-5" />
                    )}
                    <input 
                        id="avatar-upload" 
                        type="file" 
                        className="hidden" 
                        accept="image/png, image/jpeg"
                        onChange={handleAvatarUpload}
                        disabled={isUploading}
                    />
                </label>
            </div>
            <h1 className="text-xl font-bold mt-4">{profile.full_name || user?.email}</h1>
            <p className="text-sm text-muted-foreground capitalize">{profile.role === 'client' ? 'Mijoz' : 'Usta'}</p>
        </div>
    );
}

export default AvatarUploader;
