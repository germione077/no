
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth, Profile } from '../providers/AuthProvider';

interface RoleSwitcherProps {
  profile: Profile;
}

const RoleSwitcher: React.FC<RoleSwitcherProps> = ({ profile }) => {
  const { user, refetchProfile } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = React.useState(false);

  const newRole = profile.role === 'client' ? 'provider' : 'client';

  const handleRoleChange = async () => {
    if (!user) return;
    setLoading(true);
    const { error } = await supabase
      .from('profiles')
      .update({ role: newRole })
      .eq('id', user.id);
    
    setLoading(false);
    if (error) {
      toast({ variant: 'destructive', title: "Xatolik", description: error.message });
    } else {
      toast({ title: "Muvaffaqiyatli", description: `Sizning rolingiz ${newRole} ga o'zgartirildi.` });
      refetchProfile();
    }
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>Rolni o'zgartirish</CardTitle>
        <CardDescription>
          {profile.role === 'client'
            ? "Xizmat ko'rsatuvchi sifatida e'lonlaringizni joylashtirish uchun Usta profiliga o'ting."
            : "Mijoz sifatida xizmatlarni qidirish uchun Mijoz profiliga qayting."}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Button onClick={handleRoleChange} disabled={loading} className="w-full">
          {loading ? "O'zgartirilmoqda..." : ` ${newRole === 'provider' ? 'Usta' : 'Mijoz'} profiliga o'tish`}
        </Button>
      </CardContent>
    </Card>
  );
};

export default RoleSwitcher;
