
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react'; // Example Icon

interface CategoryCardProps {
  title: string;
  description: string;
  icon?: React.ElementType; // Lucide icon component
  link: string;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ title, description, icon: Icon, link }) => {
  return (
    <Link to={link} className="block group">
      <Card className="hover:shadow-lg transition-shadow duration-300 h-full flex flex-col">
        <CardHeader>
          <div className="flex items-center mb-2">
            {Icon && <Icon className="h-8 w-8 mr-3 text-primary" />}
            <CardTitle className="text-xl">{title}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="flex-grow">
          <p className="text-muted-foreground text-sm mb-4">{description}</p>
          <div className="text-primary font-semibold flex items-center group-hover:underline">
            Ko'proq bilish <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

export default CategoryCard;

