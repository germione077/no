
import {
  Home,
  Lamp,
  Car,
  Scissors,
  Spade,
  AirVent,
  Shield,
  Factory,
  Sparkles,
  HeartHandshake,
  Laptop,
} from 'lucide-react';
import { TFunction } from 'i18next';

export interface SubCategory {
  slug: string;
  title: string;
  description: string;
}

export interface Category {
  slug: string;
  title: string;
  description: string;
  icon: React.ElementType;
  subCategories: SubCategory[];
}

export const getAllCategories = (t: TFunction): Category[] => [
  {
    slug: 'home-property-services',
    title: t('categoryHomePropertyTitle', 'Home & Property Services'),
    description: t('categoryHomePropertyDescription', 'All types of repair and construction work for your home and office.'),
    icon: Home,
    subCategories: [
      { slug: 'plumber', title: t('subCategoryPlumberTitle', 'Plumber'), description: t('subCategoryPlumberDescription', 'Installation and repair of water pipes, sewerage, and plumbing fixtures.') },
      { slug: 'electrician', title: t('subCategoryElectricianTitle', 'Electrician'), description: t('subCategoryElectricianDescription', 'Electrical wiring, installation of sockets, switches, and lighting systems.') },
      { slug: 'general-construction-worker', title: t('subCategoryGeneralConstructionWorkerTitle', 'General construction worker'), description: t('subCategoryGeneralConstructionWorkerDescription', 'General construction and renovation works.') },
      { slug: 'bricklayer-mason', title: t('subCategoryBricklayerMasonTitle', 'Bricklayer / Mason'), description: t('subCategoryBricklayerMasonDescription', 'Bricklaying for walls, fireplaces, and other structures.') },
      { slug: 'tile-installer', title: t('subCategoryTileInstallerTitle', 'Tile installer'), description: t('subCategoryTileInstallerDescription', 'Installation of ceramic, porcelain, and natural stone tiles.') },
      { slug: 'drywall-installer', title: t('subCategoryDrywallInstallerTitle', 'Drywall installer'), description: t('subCategoryDrywallInstallerDescription', 'Installation of drywall for walls and ceilings.') },
      { slug: 'painter-decorator', title: t('subCategoryPainterDecoratorTitle', 'Painter / Decorator'), description: t('subCategoryPainterDecoratorDescription', 'Interior and exterior painting, wallpapering, and decorating.') },
      { slug: 'furniture-maker', title: t('subCategoryFurnitureMakerTitle', 'Furniture maker'), description: t('subCategoryFurnitureMakerDescription', 'Custom design and creation of wooden furniture.') },
      { slug: 'window-installer', title: t('subCategoryWindowInstallerTitle', 'Window installer'), description: t('subCategoryWindowInstallerDescription', 'Installation and replacement of windows and window frames.') },
      { slug: 'roofer', title: t('subCategoryRooferTitle', 'Roofer'), description: t('subCategoryRooferDescription', 'Installation, repair, and maintenance of roofs.') },
      { slug: 'general-handyman', title: t('subCategoryGeneralHandymanTitle', 'General handyman'), description: t('subCategoryGeneralHandymanDescription', 'Various small repairs and maintenance tasks around the house.') },
      { slug: 'appliance-repair-technician', title: t('subCategoryApplianceRepairTechnicianTitle', 'Appliance repair technician'), description: t('subCategoryApplianceRepairTechnicianDescription', 'Repair of washing machines, refrigerators, ovens, etc.') },
    ],
  },
  {
    slug: 'furniture-interiors',
    title: t('categoryFurnitureInteriorsTitle', 'Furniture & Interiors'),
    description: t('categoryFurnitureInteriorsDescription', 'Services for furniture repair, assembly, and interior decoration.'),
    icon: Lamp,
    subCategories: [
      { slug: 'furniture-repair-technician', title: t('subCategoryFurnitureRepairTechnicianTitle', 'Furniture repair technician'), description: t('subCategoryFurnitureRepairTechnicianDescription', 'Restoration and repair of old or damaged furniture.') },
      { slug: 'upholsterer', title: t('subCategoryUpholstererTitle', 'Upholsterer'), description: t('subCategoryUpholstererDescription', 'Re-upholstering sofas, chairs, and other furniture.') },
      { slug: 'furniture-assembler', title: t('subCategoryFurnitureAssemblerTitle', 'Furniture assembler'), description: t('subCategoryFurnitureAssemblerDescription', 'Assembly of flat-pack and new furniture.') },
      { slug: 'curtain-installer', title: t('subCategoryCurtainInstallerTitle', 'Curtain installer'), description: t('subCategoryCurtainInstallerDescription', 'Installation of curtains, blinds, and curtain rods.') },
      { slug: 'carpet-installer', title: t('subCategoryCarpetInstallerTitle', 'Carpet installer'), description: t('subCategoryCarpetInstallerDescription', 'Professional installation of carpets.') },
    ],
  },
  {
    slug: 'automotive-transport',
    title: t('categoryAutomotiveTransportTitle', 'Automotive & Transport'),
    description: t('categoryAutomotiveTransportDescription', 'Repair and maintenance services for your vehicle.'),
    icon: Car,
    subCategories: [
      { slug: 'auto-mechanic', title: t('subCategoryAutoMechanicTitle', 'Auto mechanic'), description: t('subCategoryAutoMechanicDescription', 'Engine diagnostics, oil change, and general car repair.') },
      { slug: 'auto-electrician', title: t('subCategoryAutoElectricianTitle', 'Auto electrician'), description: t('subCategoryAutoElectricianDescription', 'Repair of automotive electrical systems.') },
      { slug: 'car-washer', title: t('subCategoryCarWasherTitle', 'Car washer'), description: t('subCategoryCarWasherDescription', 'Exterior and interior car cleaning services.') },
      { slug: 'car-body-repair-technician', title: t('subCategoryCarBodyRepairTechnicianTitle', 'Car body repair technician'), description: t('subCategoryCarBodyRepairTechnicianDescription', 'Repair of dents, scratches, and collision damage.') },
      { slug: 'tire-repair-specialist', title: t('subCategoryTireRepairSpecialistTitle', 'Tire repair specialist'), description: t('subCategoryTireRepairSpecialistDescription', 'Tire fitting, balancing, and puncture repair.') },
      { slug: 'brake-technician', title: t('subCategoryBrakeTechnicianTitle', 'Brake technician'), description: t('subCategoryBrakeTechnicianDescription', 'Repair and maintenance of car brake systems.') },
    ],
  },
  {
    slug: 'personal-fashion-services',
    title: t('categoryPersonalFashionTitle', 'Personal & Fashion Services'),
    description: t('categoryPersonalFashionDescription', 'Tailoring, clothing repair, and custom-made apparel.'),
    icon: Scissors,
    subCategories: [
      { slug: 'tailor', title: t('subCategoryTailorTitle', 'Tailor'), description: t('subCategoryTailorDescription', 'Custom tailoring for men\'s clothing.') },
      { slug: 'seamstress', title: t('subCategorySeamstressTitle', 'Seamstress'), description: t('subCategorySeamstressDescription', 'Custom sewing and alterations for women\'s clothing.') },
      { slug: 'costume-maker', title: t('subCategoryCostumeMakerTitle', 'Costume maker'), description: t('subCategoryCostumeMakerDescription', 'Creation of costumes for theater, parties, and events.') },
      { slug: 'shoe-repair-specialist', title: t('subCategoryShoeRepairSpecialistTitle', 'Shoe repair specialist'), description: t('subCategoryShoeRepairSpecialistDescription', 'Repair of all types of footwear.') },
      { slug: 'leather-craftsman', title: t('subCategoryLeatherCraftsmanTitle', 'Leather craftsman'), description: t('subCategoryLeatherCraftsmanDescription', 'Creation and repair of leather goods.') },
    ],
  },
  {
    slug: 'gardening-landscaping',
    title: t('categoryGardeningLandscapingTitle', 'Gardening & Landscaping'),
    description: t('categoryGardeningLandscapingDescription', 'Create and maintain your beautiful garden and outdoor space.'),
    icon: Spade,
    subCategories: [
      { slug: 'landscape-designer', title: t('subCategoryLandscapeDesignerTitle', 'Landscape designer'), description: t('subCategoryLandscapeDesignerDescription', 'Design of gardens, parks, and other outdoor spaces.') },
      { slug: 'gardener', title: t('subCategoryGardenerTitle', 'Gardener'), description: t('subCategoryGardenerDescription', 'Planting, weeding, and general garden maintenance.') },
      { slug: 'tree-surgeon', title: t('subCategoryTreeSurgeonTitle', 'Tree surgeon'), description: t('subCategoryTreeSurgeonDescription', 'Pruning, felling, and care of trees.') },
      { slug: 'lawn-care-technician', title: t('subCategoryLawnCareTechnicianTitle', 'Lawn care technician'), description: t('subCategoryLawnCareTechnicianDescription', 'Mowing, fertilizing, and treating lawns.') },
      { slug: 'irrigation-system-installer', title: t('subCategoryIrrigationSystemInstallerTitle', 'Irrigation system installer'), description: t('subCategoryIrrigationSystemInstallerDescription', 'Installation and repair of sprinkler and drip systems.') },
      { slug: 'fence-installer', title: t('subCategoryFenceInstallerTitle', 'Fence installer'), description: t('subCategoryFenceInstallerDescription', 'Installation of wooden, metal, and vinyl fences.') },
    ],
  },
  {
    slug: 'climate-control-systems',
    title: t('categoryClimateControlTitle', 'Climate Control Systems'),
    description: t('categoryClimateControlDescription', 'Installation and repair of heating and air conditioning systems.'),
    icon: AirVent,
    subCategories: [
      { slug: 'air-conditioning-technician', title: t('subCategoryAirConditioningTechnicianTitle', 'Air conditioning technician'), description: t('subCategoryAirConditioningTechnicianDescription', 'Installation, repair, and maintenance of AC units.') },
      { slug: 'heating-system-installer', title: t('subCategoryHeatingSystemInstallerTitle', 'Heating system installer'), description: t('subCategoryHeatingSystemInstallerDescription', 'Installation of radiators, underfloor heating, etc.') },
      { slug: 'gas-installer', title: t('subCategoryGasInstallerTitle', 'Gas installer'), description: t('subCategoryGasInstallerDescription', 'Installation and maintenance of gas pipes and appliances.') },
      { slug: 'boiler-repairman', title: t('subCategoryBoilerRepairmanTitle', 'Boiler repairman'), description: t('subCategoryBoilerRepairmanDescription', 'Repair and servicing of gas and electric boilers.') },
    ],
  },
  {
    slug: 'smart-home-security',
    title: t('categorySmartHomeSecurityTitle', 'Smart Home & Security'),
    description: t('categorySmartHomeSecurityDescription', 'Installation of security and smart home systems.'),
    icon: Shield,
    subCategories: [
      { slug: 'cctv-installer', title: t('subCategoryCctvInstallerTitle', 'CCTV installer'), description: t('subCategoryCctvInstallerDescription', 'Installation of video surveillance cameras.') },
      { slug: 'smart-home-technician', title: t('subCategorySmartHomeTechnicianTitle', 'Smart home technician'), description: t('subCategorySmartHomeTechnicianDescription', 'Setup of smart lighting, thermostats, and other devices.') },
      { slug: 'door-phone-installer', title: t('subCategoryDoorPhoneInstallerTitle', 'Door phone installer'), description: t('subCategoryDoorPhoneInstallerDescription', 'Installation of intercom and door phone systems.') },
      { slug: 'internet-setup-technician', title: t('subCategoryInternetSetupTechnicianTitle', 'Internet setup technician'), description: t('subCategoryInternetSetupTechnicianDescription', 'Setting up home and office networks.') },
    ],
  },
  {
    slug: 'industrial-specialist-services',
    title: t('categoryIndustrialSpecialistTitle', 'Industrial & Specialist Services'),
    description: t('categoryIndustrialSpecialistDescription', 'Specialized industrial and technical services.'),
    icon: Factory,
    subCategories: [
      { slug: 'welder', title: t('subCategoryWelderTitle', 'Welder'), description: t('subCategoryWelderDescription', 'Welding services for various metals.') },
      { slug: 'blacksmith', title: t('subCategoryBlacksmithTitle', 'Blacksmith'), description: t('subCategoryBlacksmithDescription', 'Forging and creating custom metalwork.') },
      { slug: 'metal-fabricator', title: t('subCategoryMetalFabricatorTitle', 'Metal fabricator'), description: t('subCategoryMetalFabricatorDescription', 'Creation of metal structures and parts.') },
      { slug: 'generator-technician', title: t('subCategoryGeneratorTechnicianTitle', 'Generator technician'), description: t('subCategoryGeneratorTechnicianDescription', 'Repair and maintenance of power generators.') },
    ],
  },
  {
    slug: 'cleaning-maintenance',
    title: t('categoryCleaningMaintenanceTitle', 'Cleaning & Maintenance'),
    description: t('categoryCleaningMaintenanceDescription', 'Professional cleaning services for any space.'),
    icon: Sparkles,
    subCategories: [
      { slug: 'house-cleaner', title: t('subCategoryHouseCleanerTitle', 'House cleaner'), description: t('subCategoryHouseCleanerDescription', 'Regular and deep cleaning for homes and apartments.') },
      { slug: 'office-cleaner', title: t('subCategoryOfficeCleanerTitle', 'Office cleaner'), description: t('subCategoryOfficeCleanerDescription', 'Cleaning services for office spaces.') },
      { slug: 'window-cleaner', title: t('subCategoryWindowCleanerTitle', 'Window cleaner'), description: t('subCategoryWindowCleanerDescription', 'Professional window cleaning for homes and buildings.') },
      { slug: 'post-construction-cleaner', title: t('subCategoryPostConstructionCleanerTitle', 'Post-construction cleaner'), description: t('subCategoryPostConstructionCleanerDescription', 'Cleaning after renovation and construction work.') },
    ],
  },
  {
    slug: 'beauty-personal-care',
    title: t('categoryBeautyPersonalCareTitle', 'Beauty & Personal Care'),
    description: t('categoryBeautyPersonalCareDescription', 'Services for your beauty, health, and well-being.'),
    icon: HeartHandshake,
    subCategories: [
      { slug: 'hairdresser', title: t('subCategoryHairdresserTitle', 'Hairdresser'), description: t('subCategoryHairdresserDescription', 'Haircuts, styling, and coloring for women.') },
      { slug: 'barber', title: t('subCategoryBarberTitle', 'Barber'), description: t('subCategoryBarberDescription', 'Men\'s haircuts and beard trimming.') },
      { slug: 'manicurist', title: t('subCategoryManicuristTitle', 'Manicurist'), description: t('subCategoryManicuristDescription', 'Manicure and nail art services.') },
      { slug: 'pedicurist', title: t('subCategoryPedicuristTitle', 'Pedicurist'), description: t('subCategoryPedicuristDescription', 'Pedicure and foot care services.') },
      { slug: 'makeup-artist', title: t('subCategoryMakeupArtistTitle', 'Makeup artist'), description: t('subCategoryMakeupArtistDescription', 'Professional makeup for events and photoshoots.') },
      { slug: 'massage-therapist', title: t('subCategoryMassageTherapistTitle', 'Massage therapist'), description: t('subCategoryMassageTherapistDescription', 'Therapeutic and relaxation massage.') },
      { slug: 'waxing-technician', title: t('subCategoryWaxingTechnicianTitle', 'Waxing technician'), description: t('subCategoryWaxingTechnicianDescription', 'Hair removal services.') },
      { slug: 'cosmetologist', title: t('subCategoryCosmetologistTitle', 'Cosmetologist'), description: t('subCategoryCosmetologistDescription', 'Facial treatments and skincare consultations.') },
    ],
  },
  {
    slug: 'computer-telephone-repair',
    title: t('categoryComputerTelephoneRepairTitle', 'Computer & Telephone Repair'),
    description: t('categoryComputerTelephoneRepairDescription', 'Repair services for your digital devices.'),
    icon: Laptop,
    subCategories: [
      { slug: 'pc-technician', title: t('subCategoryPcTechnicianTitle', 'PC technician'), description: t('subCategoryPcTechnicianDescription', 'Repair and maintenance of desktop computers.') },
      { slug: 'laptop-repair-specialist', title: t('subCategoryLaptopRepairSpecialistTitle', 'Laptop repair specialist'), description: t('subCategoryLaptopRepairSpecialistDescription', 'Repair of all brands of laptops.') },
      { slug: 'data-recovery-specialist', title: t('subCategoryDataRecoverySpecialistTitle', 'Data recovery specialist'), description: t('subCategoryDataRecoverySpecialistDescription', 'Recovery of lost data from hard drives and other media.') },
      { slug: 'mobile-phone-technician', title: t('subCategoryMobilePhoneTechnicianTitle', 'Mobile phone technician'), description: t('subCategoryMobilePhoneTechnicianDescription', 'Repair of smartphones and mobile phones.') },
      { slug: 'screen-replacement-specialist', title: t('subCategoryScreenReplacementSpecialistTitle', 'Screen replacement specialist'), description: t('subCategoryScreenReplacementSpecialistDescription', 'Replacement of broken screens on phones and tablets.') },
      { slug: 'tablet-repair-specialist', title: t('subCategoryTabletRepairSpecialistTitle', 'Tablet repair specialist'), description: t('subCategoryTabletRepairSpecialistDescription', 'Repair of iPads, Galaxy Tabs, and other tablets.') },
    ],
  },
];
