
import React from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import MainLayout from "./components/layout/MainLayout";
import CategoriesPage from "./pages/CategoriesPage";
import CategoryDetailPage from "./pages/CategoryDetailPage";
import SpecialistProfilePage from "./pages/SpecialistProfilePage";
import BlogPage from "./pages/BlogPage";
import RegisterPage from "./pages/RegisterPage";
import LoginPage from './pages/LoginPage';
import ProfilePage from "./pages/ProfilePage";
import CompleteProfilePage from './pages/CompleteProfilePage';
import ServiceFormPage from './pages/ServiceFormPage';
import ServiceDetailPage from './pages/ServiceDetailPage';
import { useTranslation } from 'react-i18next'; 
import { AuthProvider } from './components/providers/AuthProvider';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';

const queryClient = new QueryClient();

const TranslatedPlaceholder: React.FC<{ translationKey: string; defaultText: string }> = ({ translationKey, defaultText }) => {
  const { t } = useTranslation();
  return <div className="container mx-auto p-4">{t(translationKey, defaultText)}</div>;
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BrowserRouter>
          <AuthProvider>
            <Toaster />
            <SonnerToaster />
            <MainLayout>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/categories" element={<CategoriesPage />} />
                <Route path="/categories/:categoryName" element={<CategoryDetailPage />} />
                <Route path="/service/:serviceId" element={<ServiceDetailPage />} />
                <Route path="/specialist/:specialistId" element={<SpecialistProfilePage />} />
                <Route path="/blog" element={<BlogPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/register" element={<RegisterPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/profile/services/new" element={<ServiceFormPage />} />
                <Route path="/profile/services/:serviceId/edit" element={<ServiceFormPage />} />
                <Route path="/complete-profile" element={<CompleteProfilePage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/faq" element={<TranslatedPlaceholder translationKey="faqPagePlaceholder" defaultText="FAQ (tez kunda)" />} />
                <Route path="/terms" element={<TranslatedPlaceholder translationKey="termsPagePlaceholder" defaultText="Foydalanish shartlari (tez kunda)" />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </MainLayout>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
