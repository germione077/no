
import { Tables } from '@/integrations/supabase/types';

export type ServicePost = Tables<'services'> & {
  profiles: {
    full_name: string | null;
    avatar_url: string | null;
  } | null;
  comments: { count: number }[];
  user_favorites: { count: number }[];
  service_likes: { count: number }[];
};
