
import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/components/providers/AuthProvider';
import { useNavigate } from 'react-router-dom';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

const formSchema = z.object({
  full_name: z.string().min(2, { message: "Ism kamida 2 belgidan iborat bo'lishi kerak." }),
  username: z.string()
    .min(3, { message: "Foydalanuvchi nomi kamida 3 belgidan iborat bo'lishi kerak." })
    .max(20, { message: "Foydalanuvchi nomi 20 belgidan oshmasligi kerak." })
    .regex(/^[a-z0-9_]+$/, { message: "Foydalanuvchi nomi faqat kichik harflar, raqamlar va pastki chiziqdan iborat bo'lishi mumkin." }),
  role: z.enum(['client', 'provider'], {
    required_error: "Rolni tanlashingiz kerak.",
  }),
});

const CompleteProfilePage = () => {
  const { user, profile, refetchProfile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      full_name: profile?.full_name || user?.user_metadata?.full_name || '',
      username: profile?.username || '',
      role: profile?.role || undefined,
    },
  });
  
  React.useEffect(() => {
    if (profile) {
      form.reset({
        full_name: profile.full_name || user?.user_metadata?.full_name || '',
        username: profile.username || '',
        role: profile.role || undefined,
      });
    }
  }, [profile, user, form]);

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    if (!user) return;
    
    // Check if username is unique
    const { data: existingUser, error: checkError } = await supabase
        .from('profiles')
        .select('id')
        .eq('username', values.username)
        .neq('id', user.id)
        .maybeSingle();

    if (checkError) {
        toast({ variant: 'destructive', title: "Xatolik", description: "Foydalanuvchi nomini tekshirishda xatolik." });
        return;
    }

    if (existingUser) {
        form.setError('username', {
            type: 'manual',
            message: 'Bu foydalanuvchi nomi band.',
        });
        return;
    }

    const { error } = await supabase
      .from('profiles')
      .update({
        full_name: values.full_name,
        username: values.username,
        role: values.role,
        profile_complete: true,
        updated_at: new Date().toISOString(),
      })
      .eq('id', user.id);

    if (error) {
      toast({ variant: 'destructive', title: "Xatolik", description: error.message });
    } else {
      toast({ title: "Muvaffaqiyatli", description: "Profilingiz muvaffaqiyatli yangilandi." });
      await refetchProfile();
      if (values.role === 'provider') {
        navigate('/profile');
      } else {
        navigate('/');
      }
    }
  };

  if (!user || !profile) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
          <p>Yuklanmoqda...</p>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen py-12 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Profilni to'ldirish</CardTitle>
          <CardDescription className="text-center">
            Davom etish uchun ma'lumotlaringizni kiriting.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="full_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>To'liq ism</FormLabel>
                    <FormControl>
                      <Input placeholder="Ismingizni kiriting" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Foydalanuvchi nomi</FormLabel>
                    <FormControl>
                      <Input placeholder="noyob_foydalanuvchi_nomi" {...field} />
                    </FormControl>
                    <FormDescription>
                      Bu sizning qidiruv va suhbatlar uchun ishlatiladigan noyob nomingiz bo'ladi.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Siz kimsiz?</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="client" />
                          </FormControl>
                          <FormLabel className="font-normal">
                            Men mijozman
                          </FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="provider" />
                          </FormControl>
                          <FormLabel className="font-normal">
                            Men ustaman
                          </FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? "Saqlanmoqda..." : "Saqlash"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default CompleteProfilePage;
