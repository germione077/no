
import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Tables } from '@/integrations/supabase/types';
import { getAllCategories, Category } from '@/config/categories';
import { useTranslation } from 'react-i18next';
import { getMockServiceById } from '@/data/mock-services';
import { useAuth } from '@/components/providers/AuthProvider';
import { useToast } from '@/components/ui/use-toast';
import { ConversationWithRecipient } from '@/components/profile/Messages';
import { type ReviewWithProfile } from '@/components/reviews/ReviewItem';
import ServiceHeader from '@/components/service-detail/ServiceHeader';
import ServiceContent from '@/components/service-detail/ServiceContent';
import ProviderCard from '@/components/service-detail/ProviderCard';
import FeedbackSection from '@/components/service-detail/FeedbackSection';
import ChatDialog from '@/components/service-detail/ChatDialog';

export type ServiceWithProfile = Tables<'services'> & {
    profiles: Pick<Tables<'profiles'>, 'id' | 'full_name' | 'avatar_url'> | null;
    comments: { count: number }[];
    user_favorites: { count: number }[];
    service_likes: { count: number }[];
    service_reviews: { count: number }[];
};

const fetchServiceById = async (serviceId: string) => {
    const { data, error } = await supabase
        .from('services')
        .select('*, profiles:profiles!services_user_id_fkey(id, full_name, avatar_url), comments(count), user_favorites(count), service_likes(count), service_reviews(count)')
        .eq('id', serviceId)
        .single();
    
    if (error) throw new Error(error.message);
    return data as ServiceWithProfile;
}

const ServiceDetailPage = () => {
    const { serviceId } = useParams<{ serviceId: string }>();
    const { t } = useTranslation();
    const { user } = useAuth();
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const navigate = useNavigate();
    const categories = getAllCategories(t);
    const isMock = serviceId?.startsWith('mock-');

    const [reviews, setReviews] = React.useState<ReviewWithProfile[]>([]);
    const [isChatOpen, setIsChatOpen] = React.useState(false);
    const [activeChat, setActiveChat] = React.useState<ConversationWithRecipient | null>(null);

    const [isMockFavorited, setIsMockFavorited] = React.useState(false);
    const [isMockLiked, setIsMockLiked] = React.useState(false);

    const { data: service, isLoading, error } = useQuery<ServiceWithProfile>({
        queryKey: ['service-detail', serviceId],
        queryFn: () => {
            if (isMock && serviceId) {
                const mockServiceData = getMockServiceById(serviceId);
                if (mockServiceData) {
                    const serviceForDetailPage: ServiceWithProfile = {
                        ...mockServiceData,
                        profiles: mockServiceData.profiles ? {
                            id: mockServiceData.user_id,
                            full_name: mockServiceData.profiles.full_name,
                            avatar_url: mockServiceData.profiles.avatar_url,
                        } : null,
                        service_reviews: 'service_reviews' in mockServiceData ? (mockServiceData as any).service_reviews : [{ count: 0 }],
                    };
                    return Promise.resolve(serviceForDetailPage);
                }
                return Promise.reject(new Error("Mock service not found"));
            }
            return fetchServiceById(serviceId!);
        },
        enabled: !!serviceId,
    });

    const { data: userFavorites } = useQuery({
        queryKey: ['user-favorites', user?.id],
        queryFn: async () => {
          if (!user || isMock) return [];
          const { data, error } = await supabase
            .from('user_favorites')
            .select('service_id')
            .eq('user_id', user.id);
          if (error) throw error;
          return data.map(f => f.service_id);
        },
        enabled: !!user && !isMock,
    });

    const { data: userLikes } = useQuery({
        queryKey: ['user-likes', user?.id, serviceId],
        queryFn: async () => {
          if (!user || isMock || !serviceId) return [];
          const { data, error } = await supabase
            .from('service_likes')
            .select('service_id')
            .eq('user_id', user.id)
            .eq('service_id', serviceId);
          if (error) throw error;
          return data.map(f => f.service_id);
        },
        enabled: !!user && !isMock && !!serviceId,
    });
    
    const isFavorited = isMock ? isMockFavorited : userFavorites?.includes(service?.id || '') ?? false;
    const isLiked = isMock ? isMockLiked : userLikes?.includes(service?.id || '') ?? false;

    const favoriteMutation = useMutation({
        mutationFn: async (isCurrentlyFavorited: boolean) => {
            if (!user) throw new Error("User not logged in");
            if (isMock) throw new Error("Cannot favorite a mock service");

            if (isCurrentlyFavorited) {
                const { error } = await supabase
                    .from('user_favorites')
                    .delete()
                    .match({ user_id: user.id, service_id: service!.id });
                if (error) throw error;
            } else {
                const { error } = await supabase
                    .from('user_favorites')
                    .insert({ user_id: user.id, service_id: service!.id });
                if (error) throw error;
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['user-favorites', user?.id] });
            queryClient.invalidateQueries({ queryKey: ['service-detail', serviceId] });
            queryClient.invalidateQueries({ queryKey: ['services-feed'] });
        },
        onError: (error: any) => {
             toast({
                variant: "destructive",
                title: "Xatolik",
                description: error.message || "Amalni bajarishda kutilmagan xatolik yuz berdi.",
            });
        }
    });

    const likeMutation = useMutation({
        mutationFn: async (isCurrentlyLiked: boolean) => {
            if (!user) throw new Error("User not logged in");
            if (isMock) throw new Error("Cannot like a mock service");

            if (isCurrentlyLiked) {
                const { error } = await supabase
                    .from('service_likes')
                    .delete()
                    .match({ user_id: user.id, service_id: service!.id });
                if (error) throw error;
            } else {
                const { error } = await supabase
                    .from('service_likes')
                    .insert({ user_id: user.id, service_id: service!.id });
                if (error) throw error;
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['user-likes', user?.id, serviceId] });
            queryClient.invalidateQueries({ queryKey: ['service-detail', serviceId] });
            queryClient.invalidateQueries({ queryKey: ['services-feed'] });
        },
        onError: (error: any) => {
             toast({
                variant: "destructive",
                title: "Xatolik",
                description: error.message || "Amalni bajarishda kutilmagan xatolik yuz berdi.",
            });
        }
    });

    const conversationMutation = useMutation({
        mutationFn: async ({ providerId, serviceId, recipientProfile }: { providerId: string, serviceId: string, recipientProfile: NonNullable<ServiceWithProfile['profiles']> }) => {
            if (!user) throw new Error("User not authenticated");
            if (user.id === providerId) throw new Error("Cannot start a conversation with yourself");

            const { data: existing, error: findError } = await supabase
                .from('conversations')
                .select('*')
                .eq('service_id', serviceId)
                .or(`(participant_one_id.eq.${user.id},participant_two_id.eq.${providerId}),(participant_one_id.eq.${providerId},participant_two_id.eq.${user.id})`)
                .maybeSingle();

            if (findError) throw findError;

            if (existing) {
                return { ...existing, recipient: recipientProfile };
            }

            const { data: newConversation, error: createError } = await supabase
                .from('conversations')
                .insert({
                    participant_one_id: user.id,
                    participant_two_id: providerId,
                    service_id: serviceId,
                })
                .select()
                .single();
            
            if (createError) throw createError;
            if (!newConversation) throw new Error("Failed to create conversation.");

            return { ...newConversation, recipient: recipientProfile };
        },
        onSuccess: (data: ConversationWithRecipient) => {
            setActiveChat(data);
            setIsChatOpen(true);
            queryClient.invalidateQueries({ queryKey: ['conversations', user?.id] });
        },
        onError: (error: any) => {
             toast({
                variant: "destructive",
                title: "Xatolik",
                description: error.message || "Suhbatni boshlashda xatolik yuz berdi.",
            });
        }
    });

    const handleFavorite = () => {
        if (isMock) {
            setIsMockFavorited(prev => !prev);
            return;
        }
        if (!user) {
            toast({
                title: "Kirish shart",
                description: "Xizmatni sevimlilarga qo'shish uchun tizimga kiring.",
                action: <Button onClick={() => navigate('/login')}>Kirish</Button>
            })
            return;
        }
        favoriteMutation.mutate(isFavorited);
    };

    const handleLike = () => {
        if (isMock) {
            setIsMockLiked(prev => !prev);
            return;
        }
        if (!user) {
            toast({
                title: "Kirish shart",
                description: "Layk bosish uchun tizimga kiring.",
                action: <Button onClick={() => navigate('/login')}>Kirish</Button>
            })
            return;
        }
        likeMutation.mutate(isLiked);
    };

    const handleContactMaster = () => {
        if (isMock) {
            toast({
                title: "Namuna xizmati",
                description: "Namuna uchun yaratilgan xizmatlar bilan suhbat qurib bo'lmaydi.",
            });
            return;
        }

        if (!user) {
            toast({
                title: "Kirish shart",
                description: "Usta bilan bog'lanish uchun tizimga kiring.",
                action: <Button onClick={() => navigate('/login')}>Kirish</Button>
            });
            return;
        }

        if (service && service.profiles && service.user_id) {
            if (user.id === service.user_id) {
                 toast({
                    title: "O'zingiz bilan bog'lanish",
                    description: "O'zingizning xizmatingiz bo'yicha suhbat yarata olmaysiz.",
                });
                return;
            }
            conversationMutation.mutate({
                providerId: service.user_id,
                serviceId: service.id,
                recipientProfile: service.profiles,
            });
        }
    };

    if (isLoading) {
        return (
            <div className="container mx-auto py-8 max-w-4xl">
                <div className="space-y-6">
                    <Skeleton className="h-12 w-3/4 mb-4" />
                    <Skeleton className="h-8 w-1/2 mb-6" />
                    <Skeleton className="h-96 w-full mb-6" />
                    <Skeleton className="h-24 w-full" />
                </div>
            </div>
        );
    }
    
    if (error || !service) {
        return (
          <div className="container mx-auto py-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Xizmat topilmadi</h2>
            <p>Siz qidirayotgan xizmat mavjud emas yoki o'chirilgan.</p>
            <Button asChild className="mt-4">
              <Link to="/">Bosh sahifaga qaytish</Link>
            </Button>
          </div>
        )
    }

    const category = categories.find(c => c.slug === service.category_slug);
    
    const favoriteCount = isMock 
        ? (isFavorited ? (service.user_favorites[0]?.count || 0) + 1 : (service.user_favorites[0]?.count || 0)) 
        : (service.user_favorites[0]?.count || 0);
    const likeCount = isMock
        ? (isLiked ? (service.service_likes[0]?.count || 0) + 1 : (service.service_likes[0]?.count || 0))
        : (service.service_likes[0]?.count || 0);
    const reviewCount = reviews.length > 0 ? reviews.length : (service?.service_reviews?.[0]?.count || 0);
    const averageRating = reviews.length > 0
        ? reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length
        : 0;
    
    const isServiceOwner = user?.id === service.user_id;

    return (
        <div className="container mx-auto py-8 max-w-5xl">
            <ChatDialog 
                isOpen={isChatOpen}
                onOpenChange={setIsChatOpen}
                serviceTitle={service.title}
                conversation={activeChat}
                conversationMutation={conversationMutation}
            />

            <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
                <div className="md:col-span-2">
                    <ServiceHeader 
                        service={service}
                        category={category}
                        reviewCount={reviewCount}
                        averageRating={averageRating}
                        likeCount={likeCount}
                        favoriteCount={favoriteCount}
                    />
                    <ServiceContent
                        service={service}
                        isLiked={isLiked}
                        isFavorited={isFavorited}
                        isMock={!!isMock}
                        handleLike={handleLike}
                        handleFavorite={handleFavorite}
                        likeMutation={likeMutation}
                        favoriteMutation={favoriteMutation}
                    />
                    <FeedbackSection 
                        service={service}
                        reviewCount={reviewCount}
                        averageRating={averageRating}
                        isMock={!!isMock}
                        setReviews={setReviews}
                    />
                </div>

                <div className="md:col-span-1">
                    <ProviderCard
                        providerProfile={service.profiles}
                        isServiceOwner={isServiceOwner}
                        handleContactMaster={handleContactMaster}
                        conversationMutation={conversationMutation}
                    />
                </div>
            </div>
        </div>
    );
};

export default ServiceDetailPage;
