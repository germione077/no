
import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useTranslation } from 'react-i18next';
import { Link, useNavigate } from 'react-router-dom';
import { Chrome } from 'lucide-react'; // Using Chrome icon as a stand-in for Google, will use a proper Google icon if available or just text
import { useAuth } from '@/components/providers/AuthProvider';

// Let's assume 'Google' icon is available as per previous checks or use a generic one.
// If not, find a suitable alternative or use text.
// For this example, I'll use Chrome icon as placeholder for visual, ideally it would be Google icon.
// A better approach if 'Google' icon specifically exists in lucide-react:
// import { Google } from 'lucide-react';

const RegisterPage = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { session } = useAuth();
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    if (session) {
      navigate('/');
    }
  }, [session, navigate]);

  const formSchema = z.object({
    email: z.string().email({ message: t('invalidEmail') }),
    password: z.string().min(6, { message: t('passwordTooShort', { minLength: 6 }) }),
    confirmPassword: z.string().min(6, { message: t('passwordTooShort', { minLength: 6 }) }),
  }).refine(data => data.password === data.confirmPassword, {
    message: t('passwordsDoNotMatch'),
    path: ['confirmPassword'],
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: '',
      password: '',
      confirmPassword: '',
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    const { error } = await supabase.auth.signUp({
      email: values.email,
      password: values.password,
      options: {
        emailRedirectTo: `${window.location.origin}/login`,
      },
    });

    if (error) {
      toast({
        variant: 'destructive',
        title: t('registrationErrorTitle'),
        description: error.message === 'User already registered' ? t('registrationErrorUserExists') : t('registrationErrorGeneral'),
      });
    } else {
      toast({
        title: t('registrationSuccessTitle'),
        description: t('registrationSuccessMessage'),
      });
      form.reset();
      setIsSubmitted(true);
    }
  };

  const handleGoogleSignIn = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}` // Optional: Supabase usually handles this via dashboard config
      }
    });
    if (error) {
      toast({
        variant: 'destructive',
        title: t('registrationErrorTitle'),
        description: error.message || t('registrationErrorGeneral'),
      });
    }
    // No explicit navigation here, Supabase redirects to Google then back to your app.
    // The onAuthStateChange listener should handle the session update.
  };

  if (session) {
    return (
        <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
            <p>Bosh sahifaga o'tilmoqda...</p>
        </div>
    );
  }

  if (isSubmitted) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)] py-12 px-4 sm:px-6 lg:px-8">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center">{t('registrationSuccessTitle')}</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <p>{t('registrationSuccessMessage')}</p>
            <p className="mt-4">
              <Link to="/login" className="font-medium text-primary hover:underline">
                {t('loginLinkText')}
              </Link>
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-10rem)] py-12 px-4 sm:px-6 lg:px-8">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">{t('registerPageTitle')}</CardTitle>
          <CardDescription className="text-center">
            {t('alreadyHaveAccount')}{' '}
            <Link to="/login" className="font-medium text-primary hover:underline">
              {t('loginLinkText')}
            </Link>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Button variant="outline" className="w-full" onClick={handleGoogleSignIn}>
              {/* If Google icon is available: <Google className="mr-2 h-4 w-4" /> */}
              <Chrome className="mr-2 h-4 w-4" /> {/* Placeholder icon */}
              {t('continueWithGoogle', 'Google orqali davom etish')}
            </Button>

            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">
                  {t('orContinueWithEmail', 'Yoki email orqali')}
                </span>
              </div>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('emailLabel')}</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder={t('emailPlaceholder')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('passwordLabel')}</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder={t('passwordPlaceholder')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('confirmPasswordLabel')}</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder={t('confirmPasswordPlaceholder')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? (t('registerButton') + "...") : t('registerButton')}
                </Button>
              </form>
            </Form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RegisterPage;
