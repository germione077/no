import React from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, Star, UserCircle, MapPin, DollarSign, Briefcase, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { categoryDetailsMap } from './CategoryDetailPage';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";

interface WorkItem {
  id: string;
  imageUrl: string;
  title?: string;
  description?: string;
}

interface Specialist {
  id: string;
  name: string;
  experience: string;
  rating: number;
  services: string[];
  imageUrl?: string;
  phone?: string;
  address?: string;
  rates?: string;
  portfolio?: WorkItem[];
  categorySlug?: string; // Qaysi kategoriyaga tegishliligini bilish uchun
}

const SpecialistProfilePage = () => {
  const { specialistId } = useParams<{ specialistId: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const specialistFromState = location.state?.specialist as Specialist | undefined;
  const [selectedWork, setSelectedWork] = React.useState<WorkItem | null>(null);
  
  let specialist: Specialist | undefined = specialistFromState;
  if (!specialist) {
    for (const categoryKey in categoryDetailsMap) {
      const category = categoryDetailsMap[categoryKey];
      const foundSpecialist = category.specialists?.find(s => s.id === specialistId);
      if (foundSpecialist) {
        specialist = { ...foundSpecialist, categorySlug: categoryKey };
        break;
      }
    }
  }

  if (specialist && !specialist.categorySlug && specialistId) {
    for (const categoryKey in categoryDetailsMap) {
      const category = categoryDetailsMap[categoryKey];
      const foundInMap = category.specialists?.find(s => s.id === specialistId);
      if (foundInMap) {
        specialist.categorySlug = categoryKey;
        break;
      }
    }
  }

  if (!specialist) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">Mutaxassis topilmadi</h1>
        <p className="mb-4">Bunday mutaxassis mavjud emas yoki noto'g'ri manzil.</p>
        <Button variant="outline" onClick={() => navigate(-1)}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Orqaga qaytish
        </Button>
      </div>
    );
  }

  const handleGoBack = () => {
    if (specialist?.categorySlug) {
      navigate(`/categories/${specialist.categorySlug}`);
    } else {
      navigate(-1);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Button variant="outline" className="mb-6" onClick={handleGoBack}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Orqaga qaytish
      </Button>

      <Card className="mb-8">
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6 p-6">
          <Avatar className="w-24 h-24 sm:w-32 sm:h-32 border-2 border-primary">
            <AvatarImage src={specialist.imageUrl} alt={specialist.name} className="object-cover" />
            <AvatarFallback>
              <UserCircle className="w-full h-full text-muted-foreground" />
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <CardTitle className="text-2xl sm:text-3xl font-bold">{specialist.name}</CardTitle>
            <div className="flex items-center mt-1 text-muted-foreground">
              <Briefcase className="w-4 h-4 mr-2 shrink-0" />
              <span>Tajriba: {specialist.experience}</span>
            </div>
            <div className="flex items-center mt-1">
              <Star className="w-5 h-5 text-yellow-400 fill-yellow-400 mr-1" />
              <span className="text-lg font-semibold">{specialist.rating}/5.0</span>
            </div>
             {specialist.phone && (
              <Button asChild variant="default" className="mt-4 w-full sm:w-auto">
                <a href={`tel:${specialist.phone}`}>
                  <Phone className="mr-2 h-4 w-4" /> Bog'lanish
                </a>
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div>
            <h3 className="font-semibold text-lg mb-2">Asosiy xizmatlar:</h3>
            <ul className="list-disc list-inside text-muted-foreground space-y-1 mb-4">
              {specialist.services.map((service, index) => (
                <li key={index}>{service}</li>
              ))}
            </ul>
          </div>
          {specialist.address && (
            <div className="flex items-start text-muted-foreground mb-2">
              <MapPin className="w-5 h-5 mr-3 shrink-0 mt-1" />
              <span>{specialist.address}</span>
            </div>
          )}
          {specialist.rates && (
            <div className="flex items-center text-muted-foreground">
              <DollarSign className="w-5 h-5 mr-3 shrink-0" />
              <span>Narxlar: {specialist.rates}</span>
            </div>
          )}
        </CardContent>
      </Card>

      <h2 className="text-2xl font-semibold mb-6">Portfolio (Qilgan ishlar):</h2>
      {specialist.portfolio && specialist.portfolio.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 sm:gap-4">
          {specialist.portfolio.map((item) => (
            <Card 
              key={item.id} 
              className="overflow-hidden group aspect-square cursor-pointer"
              onClick={() => setSelectedWork(item)}
            >
              <img 
                src={item.imageUrl} 
                alt={item.title || 'Portfolio ishi'} 
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </Card>
          ))}
        </div>
      ) : (
        <div className="bg-secondary/50 p-8 rounded-lg text-center">
          <p className="text-xl text-muted-foreground">Hozircha ushbu mutaxassisning portfolio ishlari mavjud emas.</p>
        </div>
      )}
       {/* Agar portfolio juda ko'p bo'lsa, karusel ishlatish mumkin */}
      {specialist.portfolio && specialist.portfolio.length > 5 && (
        <div className="mt-12">
            <h3 className="text-xl font-semibold mb-4">Ishlar karuseli</h3>
            <Carousel
              opts={{
                align: "start",
                loop: true,
              }}
              className="w-full max-w-3xl mx-auto"
            >
              <CarouselContent>
                {specialist.portfolio.map((item, index) => (
                  <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                    <div className="p-1 cursor-pointer" onClick={() => setSelectedWork(item)}>
                      <Card className="overflow-hidden">
                        <CardContent className="flex aspect-square items-center justify-center p-0">
                           <img 
                            src={item.imageUrl} 
                            alt={item.title || `Portfolio ishi ${index + 1}`}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                        </CardContent>
                         {item.title && (
                          <div className="p-2 text-center bg-muted/50">
                            <p className="font-semibold text-sm truncate">{item.title}</p>
                          </div>
                        )}
                      </Card>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
        </div>
      )}
      {selectedWork && (
        <Dialog open={!!selectedWork} onOpenChange={(isOpen) => { if (!isOpen) setSelectedWork(null); }}>
          <DialogContent className="max-w-3xl w-full p-0">
            <div className="flex flex-col">
              <div className="w-full max-h-[80vh] overflow-hidden flex items-center justify-center bg-black rounded-t-lg">
                <img src={selectedWork.imageUrl} alt={selectedWork.title || 'Portfolio work'} className="w-auto h-auto max-w-full max-h-full object-contain"/>
              </div>
              {(selectedWork.title || selectedWork.description) && (
                <div className="p-6">
                  {selectedWork.title && <DialogTitle className="text-2xl font-bold mb-2">{selectedWork.title}</DialogTitle>}
                  {selectedWork.description && <p className="text-muted-foreground">{selectedWork.description}</p>}
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default SpecialistProfilePage;
