import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Star, UserCircle, MapPin, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { getAllCategories } from '@/config/categories';
import { useTranslation } from 'react-i18next';

// This is temporary mock data. In the future, this should be replaced
// with a dynamic fetch from the database based on the category slug.
export interface WorkItem {
  id: string;
  imageUrl: string;
  title?: string;
  description?: string;
}

export interface Specialist {
  id: string;
  name: string;
  experience: string;
  rating: number;
  services: string[];
  imageUrl?: string;
  phone?: string;
  address?: string;
  rates?: string;
  portfolio?: WorkItem[]; // Portfolio qo'shildi
  categorySlug?: string; // Qaysi kategoriyaga tegishliligini bilish uchun (SpecialistProfilePage uchun)
}

interface CategoryDetail {
  name: string;
  description: string;
  specialists?: Specialist[];
}

// NOTE: This hardcoded map is now based on sub-category slugs from `src/config/categories.ts`.
// This should be removed and data should be fetched from Supabase in the future.
export const categoryDetailsMap: Record<string, CategoryDetail> = {
  // === Home & Property Services ===
  'plumber': {
    name: "Santexniklar",
    description: "Suv quvurlari, kanalizatsiya tizimlari, kranlar, unitazlar va boshqa santexnika jihozlarini professional ta'mirlash, o'rnatish va sozlash xizmatlari.",
    specialists: [
      { 
        id: "san1", 
        name: "Ali Valiyev", 
        experience: "5 yil", 
        rating: 4.5, 
        services: ["Kran o'rnatish", "Unitaz ta'miri", "Quvur yotqizish"], 
        imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998901234567", 
        address: "Toshkent sh, Yunusobod t.", 
        rates: "50,000 so'mdan",
        categorySlug: "plumber",
        portfolio: [
          {id: "work_san1_1", imageUrl: "https://images.unsplash.com/photo-1600585152220-014099594354?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cGx1bWJpbmd8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=300&q=60", title: "Zamonaviy kran o'rnatildi"},
          {id: "work_san1_2", imageUrl: "https://images.unsplash.com/photo-1580692493409-392275a00e32?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8cGlwZXN8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=300&q=60", description: "Eski quvurlar yangisiga almashtirildi"},
        ]
      },
      { id: "san2", name: "Hasan Normurodov", experience: "8 yil", rating: 4.8, services: ["Dush kabina o'rnatish", "Suv isitgich ta'miri", "Kanalizatsiya tozalash"], imageUrl: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998912345678", address: "Toshkent sh, Chilonzor t.", rates: "Kelishiladi", categorySlug: "plumber" },
    ]
  },
  'electrician': {
    name: "Elektriklar",
    description: "Elektr simlarini tortish, rozetka va kalitlarni o'rnatish, elektr shitlarini yig'ish, yoritish tizimlarini sozlash va elektr nosozliklarini tezkor bartaraf etish.",
    specialists: [
      { id: "el1", name: "Salim Qosimov", experience: "7 yil", rating: 4.9, services: ["Sim tortish", "Rozetka o'rnatish", "Lyustra ilish"], imageUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998945678901", address: "Toshkent sh, Shayxontohur t.", rates: "60,000 so'mdan", categorySlug: "electrician" },
      { id: "el2", name: "Nodir Ergashev", experience: "10 yil", rating: 4.7, services: ["Elektr shit yig'ish", "Avtomat almashtirish", "Nosozlikni topish"], imageUrl: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998956789012", address: "Toshkent sh, Yashnobod t.", rates: "Chaqiruv 30,000 so'm", categorySlug: "electrician" },
    ]
  },
  'general-construction-worker': {
    name: "Umumiy qurilish ishchilari",
    description: "Umumiy qurilish va ta'mirlash ishlari bo'yicha mutaxassislar.",
    specialists: [
      { id: "gcw1", name: "Botir Stroy", experience: "12 yil", rating: 4.6, services: ["Beton quyish", "Devor qurish", "Tom yopish"], imageUrl: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998909123456", address: "Toshkent va Toshkent viloyati", rates: "Kelishiladi", categorySlug: "general-construction-worker" },
    ]
  },
  'bricklayer-mason': {
    name: "G'isht teruvchilar va toshchilar",
    description: "Devorlar, kaminlar va boshqa inshootlar uchun professional g'isht terish xizmatlari.",
    specialists: [
      { 
        id: "bm1", 
        name: "G'ofur G'ishtchi", 
        experience: "15 yil", 
        rating: 4.8, 
        services: ["Pishgan g'isht terish", "Blok terish", "Dekorativ tosh terish"], 
        imageUrl: "https://images.unsplash.com/photo-1558980394-a398a6a5b7e2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998901234567", 
        address: "Toshkent sh, Sergeli t.", 
        rates: "1 kv.m 50,000 so'mdan",
        categorySlug: "bricklayer-mason",
        portfolio: [
          {id: "work_bm1_1", imageUrl: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8YnJpY2slMjBob3VzZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=300&q=60", title: "Yangi hovli uchun devor"},
        ]
      },
    ]
  },
  'tile-installer': {
    name: "Kafel teruvchilar",
    description: "Hammom, oshxona va pollarga kafel, kafel va tabiiy toshlarni professional tarzda terish.",
     specialists: [
      { 
        id: "ti1", 
        name: "Akmal Kafelchi", 
        experience: "9 yil", 
        rating: 4.9, 
        services: ["Kafel terish", "Metlax terish", "Mozaika terish"], 
        imageUrl: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998931234567", 
        address: "Samarqand sh.", 
        rates: "1 kv.m 60,000 so'mdan",
        categorySlug: "tile-installer",
      },
    ]
  },
  'drywall-installer': {
    name: "Gipsokartonchilar",
    description: "Devor va shiftlar uchun gipsokarton o'rnatish, silliqlash va bo'yoqqa tayyorlash.",
    specialists: [
      { 
        id: "di1", 
        name: "Erkin Gipsokartonchi", 
        experience: "6 yil", 
        rating: 4.7, 
        services: ["Devorga gipsokarton", "Shiftga gipsokarton", "Figurali shiftlar"], 
        imageUrl: "https://images.unsplash.com/photo-1607502752187-73a7a4b8f522?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998911234567", 
        address: "Buxoro sh.", 
        rates: "1 kv.m 35,000 so'mdan",
        categorySlug: "drywall-installer",
      },
    ]
  },
  'painter-decorator': {
    name: "Bo'yoqchilar va pardozchilar",
    description: "Ichki va tashqi bo'yash, oboy yopishtirish va dekorativ pardozlash ishlari.",
    specialists: [
      { 
        id: "pd1", 
        name: "Zafar Bo'yoqchi", 
        experience: "10 yil", 
        rating: 4.8, 
        services: ["Devor bo'yash", "Oboy yopishtirish", "Fasad bo'yash"], 
        imageUrl: "https://images.unsplash.com/photo-1596495577886-d927f85412be?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998941234567", 
        address: "Toshkent sh. bo'ylab", 
        rates: "1 kv.m 15,000 so'mdan",
        categorySlug: "painter-decorator",
      },
    ]
  },
  'furniture-maker': {
    name: "Mebelchilar",
    description: "Buyurtma asosida yog'och mebellar yasash, dizayn qilish va yaratish.",
    specialists: [
      { 
        id: "fm1", 
        name: "Olim Mebelchi", 
        experience: "20 yil", 
        rating: 5.0, 
        services: ["Oshxona mebeli", "Yotoqxona mebeli", "Ofis mebeli"], 
        imageUrl: "https://images.unsplash.com/photo-1600577916048-823a901d54e5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998901112233", 
        address: "Qo'qon sh.", 
        rates: "Kelishiladi",
        categorySlug: "furniture-maker",
      },
    ]
  },
  'general-handyman': {
    name: "Umumiy ta'mirlash ustalari",
    description: "Kvartira, uy va ofislarni to'liq yoki qisman ta'mirlash, bo'yoqchilik, suvoqchilik, gipsokarton ishlari, pol yotqizish va boshqa pardozlash xizmatlari.",
    specialists: [
      { id: "rem1", name: "Rustam Jo'rayev", experience: "10 yil", rating: 4.7, services: ["Bo'yoqchilik", "Kafel yotqizish", "Gipsokarton"], imageUrl: "https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998971231231", address: "Toshkent sh. bo'ylab", rates: "15,000 so'm/kv.m dan (bo'yoq)", categorySlug: "general-handyman" },
      { id: "rem2", name: "Anvar Sodiqov", experience: "6 yil", rating: 4.5, services: ["Oboy yopishtirish", "Laminat yotqizish", "Eshik o'rnatish"], imageUrl: "https://images.unsplash.com/photo-1483058712412-4245e9b90334?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998903213213", address: "Toshkent viloyati", rates: "Kelishiladi", categorySlug: "general-handyman" },
    ]
  },
  'appliance-repair-technician': {
    name: "Maishiy texnika ta'mirchilari",
    description: "Kir yuvish mashinalari, muzlatgichlar, pechlar va boshqa maishiy texnikalarni ta'mirlash.",
    specialists: [
      { 
        id: "art1", 
        name: "Sardor Usta", 
        experience: "8 yil", 
        rating: 4.9, 
        services: ["Kir yuvish mashinasi ta'miri", "Muzlatgich ta'miri", "Konditsioner ta'miri"], 
        imageUrl: "https://images.unsplash.com/photo-1614741118884-69a37a54a013?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998998765432", 
        address: "Toshkent sh. bo'ylab chaqiruv", 
        rates: "Diagnostika 50,000 so'm",
        categorySlug: "appliance-repair-technician",
      },
    ]
  },

  // === Furniture & Interiors ===
  'furniture-repair-technician': {
    name: "Mebel ta'mirchilari",
    description: "Eski yoki shikastlangan mebellarni qayta tiklash va ta'mirlash xizmatlari.",
    specialists: [
      { 
        id: "frt1", 
        name: "Qodir Restavrator", 
        experience: "15 yil", 
        rating: 4.9, 
        services: ["Antikvar mebel restavratsiyasi", "Yog'och mebel ta'miri", "Laklash va bo'yash"], 
        imageUrl: "https://images.unsplash.com/photo-1567016376408-0226e4d0c1e3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998902345678", 
        address: "Toshkent sh, Chilonzor", 
        rates: "Kelishiladi",
        categorySlug: "furniture-repair-technician",
      },
    ]
  },
  'furniture-assembler': {
    name: "Mebel yig'uvchilar",
    description: "Yangi va qadoqlangan mebellarni professional tarzda yig'ish xizmatlari.",
    specialists: [
      { 
        id: "fa1", 
        name: "Jasur Yig'uvchi", 
        experience: "4 yil", 
        rating: 4.7, 
        services: ["IKEA mebeli yig'ish", "Oshxona mebeli yig'ish", "Shkaf yig'ish"], 
        imageUrl: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998971112233", 
        address: "Toshkent sh. bo'ylab", 
        rates: "Kelishiladi",
        categorySlug: "furniture-assembler",
      },
    ]
  },

  // === Automotive & Transport ===
  'auto-mechanic': {
    name: "Avto mexaniklar",
    description: "Dvigatel diagnostikasi, moy almashtirish va umumiy avtomobil ta'miri xizmatlari.",
    specialists: [
      { id: "avto1", name: "Farhod aka", experience: "15 yil (Motorist)", rating: 4.9, services: ["Motor diagnostikasi", "Motor kapital ta'miri", "Moy almashtirish"], imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998909876543", address: "Toshkent sh, Farhod bozori yonida", rates: "Diagnostika 50,000 so'm", categorySlug: "auto-mechanic" },
      { id: "avto2", name: "Sherzod Usta", experience: "8 yil (Xadavoychi)", rating: 4.6, services: ["Xadavoy qismini tekshirish", "Amortizator almashtirish", "Razval sxojdenie"], imageUrl: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998918765432", address: "Toshkent sh, Sergeli mashina bozori", rates: "Kelishiladi", categorySlug: "auto-mechanic" }
    ]
  },
  
  // === Personal & Fashion Services ===
  'tailor': {
    name: "Chevarlar (Erkaklar kiyimlari)",
    description: "Erkaklar uchun klassik va zamonaviy kiyimlarni individual o'lchamlar bo'yicha tikish va ta'mirlash.",
    specialists: [
        { id: "tik1", name: "Abbos Chevar", experience: "18 yil", rating: 4.9, services: ["Kostyum-shim tikish", "Palto tikish", "Milliy choponlar"], imageUrl: "https://images.unsplash.com/photo-1558108433-282auntech-940713?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998901112233", address: "Toshkent sh, Uchtepa t., O'rikzor bozori", rates: "Kostyum 1,500,000 so'mdan", categorySlug: "tailor" },
    ]
  },
  'seamstress': {
    name: "Tikuvchilar (Ayollar kiyimlari)",
    description: "Ayollar uchun har qanday turdagi liboslarni (kundalik, bayramona, milliy) individual o'lchamlar bo'yicha tikish, ta'mirlash va bichish.",
    specialists: [
        { id: "tik2", name: "Gulchehra Ahmedova", experience: "12 yil", rating: 4.9, services: ["Milliy liboslar", "Kelinko'ylak", "Ta'mirlash"], imageUrl: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998901112233", address: "Toshkent sh, Uchtepa t., O'rikzor bozori", rates: "Ko'ylak 200,000 so'mdan", categorySlug: "seamstress" },
        { id: "tik3", name: "Madina Ismoilova", experience: "6 yil", rating: 4.6, services: ["Bolalar kiyimlari", "Forma tikish"], imageUrl: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998932223344", address: "Toshkent sh, Sergeli t.", rates: "Kelishiladi", categorySlug: "seamstress" },
    ]
  },

  // === Cleaning & Maintenance ===
  'house-cleaner': {
    name: "Uy tozalash xizmati",
    description: "Uylar, kvartiralar va ofislarni umumiy tozalash, ta'mirdan keyingi tozalash, deraza yuvish va gilamlarni kimyoviy tozalash kabi professional xizmatlar.",
    specialists: [
        { id: "uyt1", name: "Zamira Holmatova", experience: "4 yil", rating: 4.7, services: ["Umumiy tozalash", "Ta'mirdan keyingi tozalash", "Deraza yuvish"], imageUrl: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998973334455", address: "Toshkent sh, Mirobod t.", rates: "200,000 so'm (2 xonali kv.)", categorySlug: "house-cleaner" },
        { id: "uyt2", name: "Cleaning Pro Team", experience: "5 yil", rating: 4.8, services: ["Ofis tozalash", "Gilam yuvish", "Mebel tozalash"], imageUrl: "https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", phone: "+998935556677", address: "Toshkent sh. bo'ylab", rates: "Kelishiladi", categorySlug: "house-cleaner" }
    ]
  },
  
  // === Beauty & Personal Care ===
  'hairdresser': {
    name: "Ayollar sartaroshlari",
    description: "Professional soch kesish, turmaklash, bo'yash va boshqa go'zallik xizmatlari.",
    specialists: [
      { 
        id: "bar2", 
        name: "Laylo Stilist", 
        experience: "7 yil", 
        rating: 4.7, 
        services: ["Ayollar sochi", "Soch bo'yash", "Turmaklar"], 
        imageUrl: "https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998932348765", 
        address: "Toshkent sh, Mirzo Ulug'bek", 
        rates: "Soch kesish 50,000 so'mdan",
        categorySlug: "hairdresser",
        portfolio: [
          {id: "work_bar2_1", imageUrl: "https://images.unsplash.com/photo-1522337360788-8f13de7c1543?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d29tZW5zJTIwaGFpcmN1dHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=300&q=60", title: "Kare soch turmagi"},
          {id: "work_bar2_2", imageUrl: "https://images.unsplash.com/photo-1607005000986-8ebd5ab6a27a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8aGFpciUyMGNvbG9yaW5nfGVufDB8fDB8fHww&auto=format&fit=crop&w=300&q=60", description: "Balayaj usulida soch bo'yash"},
        ]
      },
    ]
  },
  'barber': {
    name: "Erkaklar sartaroshlari (Barberlar)",
    description: "Professional soch olish, soqol olish va zamonaviy erkaklar soch turmaklari.",
    specialists: [
      { 
        id: "bar1", 
        name: "Sobir Usta", 
        experience: "10 yil", 
        rating: 4.9, 
        services: ["Erkaklar sochi", "Soqol olish", "Bolalar sochi"], 
        imageUrl: "https://images.unsplash.com/photo-1567894340340-a733c3679038?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998901239876", 
        address: "Toshkent sh, Chorsu", 
        rates: "Soch olish 30,000 so'm",
        categorySlug: "barber",
        portfolio: [
          {id: "work_bar1_1", imageUrl: "https://images.unsplash.com/photo-1621605815971-e1771f3c8621?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8bWVucyUyMGhhaXJjdXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=300&q=60", title: "Klassik erkaklar sochi"},
        ]
      },
      { 
        id: "bar3", 
        name: "Akbar Barber", 
        experience: "5 yil", 
        rating: 4.8, 
        services: ["Zamonaviy soch turmaklari", "Fade", "Soqol dizayni"], 
        imageUrl: "https://images.unsplash.com/photo-1622287089100-3f70d642e2e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998973457654", 
        address: "Toshkent sh, Next savdo markazi", 
        rates: "40,000 so'mdan",
        categorySlug: "barber",
        portfolio: [
          {id: "work_bar3_1", imageUrl: "https://images.unsplash.com/photo-1632345031435-872b968155d6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZmFkZSUyMGhhaXJjdXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=300&q=60", title: "Fade soch turmagi"},
        ]
      },
    ]
  },
  'manicurist': {
    name: "Manikyur ustalari",
    description: "Professional manikyur, tirnoqlarni parvarishlash va dizayn xizmatlari.",
    specialists: [
      { 
        id: "man1", 
        name: "Nigora Nails", 
        experience: "5 yil", 
        rating: 4.9, 
        services: ["Klassik manikyur", "Gelli lak", "Tirnoq dizayni"], 
        imageUrl: "https://images.unsplash.com/photo-1604654894610-df644b491b7b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998909876543", 
        address: "Toshkent sh, 'Malika' saloni", 
        rates: "Manikyur 80,000 so'mdan",
        categorySlug: "manicurist",
      },
    ]
  },

  // === Computer & Telephone Repair ===
  'pc-technician': {
    name: "Kompyuter ustalari",
    description: "Stol kompyuterlarini ta'mirlash, sozlash va texnik xizmat ko'rsatish.",
    specialists: [
      { 
        id: "pc1", 
        name: "Valijon Kompyuterchi", 
        experience: "10 yil", 
        rating: 4.8, 
        services: ["Kompyuter yig'ish", "Windows o'rnatish", "Virusdan tozalash"], 
        imageUrl: "https://images.unsplash.com/photo-1575024357670-2b5164f47061?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998971234567", 
        address: "Toshkent sh, 'Malika' texnobozori", 
        rates: "Diagnostika bepul",
        categorySlug: "pc-technician",
      },
    ]
  },
  'mobile-phone-technician': {
    name: "Telefon ustalari",
    description: "Smartfon va mobil telefonlarni ta'mirlash, ekran almashtirish va dasturiy ta'minotni yangilash.",
    specialists: [
      { 
        id: "mpt1", 
        name: "Akmal Mobil", 
        experience: "7 yil", 
        rating: 4.7, 
        services: ["Ekran almashtirish", "Batareya almashtirish", "Suvdan keyin ta'mirlash"], 
        imageUrl: "https://images.unsplash.com/photo-1605578332152-a395a128b98e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80", 
        phone: "+998937654321", 
        address: "Samarqand sh, 'Registon' maydoni yaqinida", 
        rates: "Kelishiladi",
        categorySlug: "mobile-phone-technician",
      },
    ]
  },
  // Add other categories here...
  // Leaving some empty to show the "not found" message
};

const CategoryDetailPage = () => {
  const { categoryName } = useParams<{ categoryName: string }>();
  const { t } = useTranslation();
  const categories = getAllCategories(t);
  
  const subCategory = categories.flatMap(c => c.subCategories).find(s => s.slug === categoryName);
  const categoryDetails = categoryName ? categoryDetailsMap[categoryName] : null;

  if (!subCategory) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">Kategoriya topilmadi</h1>
        <p className="mb-4">Bunday kategoriya mavjud emas yoki noto'g'ri manzil.</p>
        <Button asChild variant="outline">
          <Link to="/categories">
            <ArrowLeft className="mr-2 h-4 w-4" /> Barcha kategoriyalarga qaytish
          </Link>
        </Button>
      </div>
    );
  }

  // Use subCategory for title/description, but mock specialists from categoryDetails
  const specialists = categoryDetails?.specialists;

  return (
    <div className="container mx-auto px-4 py-8">
      
      <Button asChild variant="outline" className="mb-6">
        <Link to="/categories">
          <ArrowLeft className="mr-2 h-4 w-4" /> Barcha kategoriyalarga qaytish
        </Link>
      </Button>
      <h1 className="text-3xl md:text-4xl font-bold mb-2">{subCategory.title}</h1>
      <p className="text-lg text-muted-foreground mb-8">{subCategory.description}</p>
      
      <h2 className="text-2xl font-semibold mb-6">Ushbu kategoriyadagi ustalar:</h2>
      {specialists && specialists.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {specialists.map((specialist) => (
            <Card key={specialist.id} className="flex flex-col">
              <CardHeader>
                <div className="flex items-start space-x-4">
                  {specialist.imageUrl ? (
                    <img 
                      src={specialist.imageUrl} 
                      alt={specialist.name} 
                      className="w-20 h-20 rounded-lg object-cover" 
                    />
                  ) : (
                    <UserCircle className="w-20 h-20 text-muted-foreground" />
                  )}
                  <div className="flex-1">
                    <CardTitle className="text-xl">{specialist.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">Tajriba: {specialist.experience}</p>
                    <div className="flex items-center mt-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400 mr-1" />
                      <span className="text-sm font-semibold">{specialist.rating}/5.0</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="font-medium text-sm mb-1">Asosiy xizmatlar:</p>
                <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1 mb-3">
                  {specialist.services.slice(0, 3).map((service, index) => (
                    <li key={index}>{service}</li>
                  ))}
                  {specialist.services.length > 3 && <li className="text-xs">va boshqalar...</li>}
                </ul>
                {specialist.address && (
                  <div className="flex items-center text-sm text-muted-foreground mb-1">
                    <MapPin className="w-4 h-4 mr-2 shrink-0" />
                    <span>{specialist.address}</span>
                  </div>
                )}
                {specialist.rates && (
                  <div className="flex items-center text-sm text-muted-foreground">
                    <DollarSign className="w-4 h-4 mr-2 shrink-0" />
                    <span>{specialist.rates}</span>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                 <Button asChild variant="default" className="w-full">
                  <Link to={`/specialist/${specialist.id}`} state={{ specialist: { ...specialist, categorySlug: categoryName } }}>
                    Profilni ko'rish
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        
        <div className="bg-secondary/50 p-8 rounded-lg text-center">
          <p className="text-xl text-muted-foreground">Hozircha ushbu kategoriyada ustalar mavjud emas.</p>
          <p className="text-sm mt-2">Tez kunda yangi mutaxassislar qo'shiladi!</p>
        </div>
      )}
    </div>
  );
};

export default CategoryDetailPage;
