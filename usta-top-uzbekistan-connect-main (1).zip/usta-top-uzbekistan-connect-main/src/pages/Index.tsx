
import React from 'react';
import HeroSection from '@/components/home/HeroSection';
import HowItWorksSection from '@/components/home/HowItWorksSection';
import FeaturedCategoriesSection from '@/components/home/FeaturedCategoriesSection';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import EverydayTasksSection from '@/components/home/EverydayTasksSection';
import WhyChooseUsSection from '@/components/home/WhyChooseUsSection';
import CtaSection from '@/components/home/CtaSection';

const Index = () => {
  return (
    <>
      <HeroSection />
      <HowItWorksSection />
      <FeaturedCategoriesSection />
      <TestimonialsSection />
      <EverydayTasksSection />
      <WhyChooseUsSection />
      <CtaSection />
    </>
  );
};

export default Index;
