
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from '@/components/providers/AuthProvider';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import NewPostsFeed from '@/components/blog/NewPostsFeed';
import FavoritesFeed from '@/components/blog/FavoritesFeed';
import MyPostsFeed from '@/components/blog/MyPostsFeed';
import { Heart, Newspaper, User } from 'lucide-react';

const BlogPage = () => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="bg-muted/40 h-full">
      <Tabs defaultValue="new" className="md:flex h-full">
        <TabsList className="grid w-full grid-cols-3 border-b bg-background md:flex md:w-64 shrink-0 md:flex-col md:items-start md:border-b-0 md:border-r md:p-4">
          <TabsTrigger value="new" className="w-full justify-start p-3 rounded-none md:rounded-sm">
            <Newspaper className="mr-2 h-4 w-4" />
            <span>{t('new', 'Yangi')}</span>
          </TabsTrigger>
          <TabsTrigger value="favorites" className="w-full justify-start p-3 rounded-none md:rounded-sm">
            <Heart className="mr-2 h-4 w-4" />
            <span>{t('favorites', 'Sevimlilar')}</span>
          </TabsTrigger>
          <TabsTrigger value="my-posts" className="w-full justify-start p-3 rounded-none md:rounded-sm">
            <User className="mr-2 h-4 w-4" />
            <span>{t('myPosts', 'Mening postlarim')}</span>
          </TabsTrigger>
        </TabsList>
        <div className="p-4 md:p-8 flex-1 overflow-y-auto">
          <TabsContent value="new" className="mt-0">
            <NewPostsFeed />
          </TabsContent>
          <TabsContent value="favorites" className="mt-0">
            {user ? <FavoritesFeed /> : (
              <div className="text-center py-16">
                <p className="text-lg text-muted-foreground mb-4">{t('loginToViewFavorites', 'Sevimlilarni ko\'rish uchun tizimga kiring.')}</p>
                <Button onClick={() => navigate('/login')}>{t('login', 'Kirish')}</Button>
              </div>
            )}
          </TabsContent>
          <TabsContent value="my-posts" className="mt-0">
            {user ? <MyPostsFeed /> : (
              <div className="text-center py-16">
                <p className="text-lg text-muted-foreground mb-4">{t('loginToViewMyPosts', 'O\'z e\'lonlaringizni ko\'rish uchun tizimga kiring.')}</p>
                 <Button onClick={() => navigate('/login')}>{t('login', 'Kirish')}</Button>
              </div>
            )}
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

export default BlogPage;
