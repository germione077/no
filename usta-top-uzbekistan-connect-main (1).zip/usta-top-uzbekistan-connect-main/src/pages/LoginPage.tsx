
import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { useTranslation } from 'react-i18next';
import { Link, useNavigate } from 'react-router-dom';
import { Chrome } from 'lucide-react';
import { useAuth } from '@/components/providers/AuthProvider';

const LoginPage = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { session } = useAuth();

  useEffect(() => {
    if (session) {
      navigate('/');
    }
  }, [session, navigate]);

  const formSchema = z.object({
    email: z.string().email({ message: t('invalidEmail', 'Noto‘g‘ri email format') }),
    password: z.string().min(1, { message: t('passwordRequired', 'Parol kiritilishi shart') }),
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    const { error } = await supabase.auth.signInWithPassword({
      email: values.email,
      password: values.password,
    });

    if (error) {
      toast({
        variant: 'destructive',
        title: t('loginErrorTitle', 'Kirishda xatolik'),
        description: t('loginErrorInvalidCredentials', 'Email yoki parol noto‘g‘ri'),
      });
    } else {
      toast({
        title: t('loginSuccessTitle', 'Muvaffaqiyatli kirish'),
        description: t('loginSuccessMessage', 'Bosh sahifaga yo‘naltirilmoqdasiz...'),
      });
      navigate('/');
    }
  };

  const handleGoogleSignIn = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}`
      }
    });
    if (error) {
      toast({
        variant: 'destructive',
        title: t('loginErrorTitle', 'Kirishda xatolik'),
        description: error.message || t('loginErrorGeneral', 'Umumiy xatolik yuz berdi'),
      });
    }
  };

  if (session) {
    return (
        <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
            <p>Bosh sahifaga o'tilmoqda...</p>
        </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-10rem)] py-12 px-4 sm:px-6 lg:px-8">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">{t('loginPageTitle', 'Kirish')}</CardTitle>
          <CardDescription className="text-center">
            {t('dontHaveAccount', "Hisobingiz yo'qmi?")}{' '}
            <Link to="/register" className="font-medium text-primary hover:underline">
              {t('registerLinkText', "Ro'yxatdan o'tish")}
            </Link>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Button variant="outline" className="w-full" onClick={handleGoogleSignIn}>
              <Chrome className="mr-2 h-4 w-4" />
              {t('continueWithGoogle', 'Google orqali davom etish')}
            </Button>

            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">
                  {t('orContinueWithEmail', 'Yoki email orqali')}
                </span>
              </div>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('emailLabel', 'Email')}</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder={t('emailPlaceholder', 'siz@email.com')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('passwordLabel', 'Parol')}</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder={t('passwordPlaceholder', 'Parolingiz')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={form.formState.isSubmitting}>
                  {form.formState.isSubmitting ? t('loginButtonLoading', 'Kirilmoqda...') : t('loginButton', 'Kirish')}
                </Button>
              </form>
            </Form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoginPage;
