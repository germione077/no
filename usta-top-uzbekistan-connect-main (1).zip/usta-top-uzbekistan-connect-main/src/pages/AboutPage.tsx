
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Target, BookOpen, HeartHandshake, ShieldCheck, Star, Zap } from 'lucide-react';

const AboutPage = () => {
  const { t } = useTranslation();

  const values = [
    {
      icon: ShieldCheck,
      titleKey: 'aboutValueTrustTitle',
      titleDefault: 'Trust and Safety',
      textKey: 'aboutValueTrustText',
      textDefault: 'Every specialist on our platform is verified to ensure you hire with confidence. Your safety and trust are our top priorities.',
    },
    {
      icon: Star,
      titleKey: 'aboutValueQualityTitle',
      titleDefault: 'Commitment to Quality',
      textKey: 'aboutValueQualityText',
      textDefault: 'We are committed to high standards. We facilitate honest reviews and ratings to help you choose the best professional for your needs.',
    },
    {
      icon: Zap,
      titleKey: 'aboutValueConvenienceTitle',
      titleDefault: 'Convenience',
      textKey: 'aboutValueConvenienceText',
      textDefault: 'Our platform is designed to be user-friendly, allowing you to find, contact, and hire specialists in just a few clicks, anytime and anywhere.',
    },
  ];

  return (
    <div className="bg-background text-foreground">
      <div className="container mx-auto px-4 py-12 md:py-20">
        <header className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-primary">
            {t('aboutPageTitle', 'About HunarMarket.uz')}
          </h1>
          <p className="mt-4 text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            {t('aboutPageSubtitle', 'Your trusted partner in finding skilled professionals.')}
          </p>
        </header>

        <main className="space-y-16">
          <section className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <h2 className="text-3xl font-bold mb-4 flex items-center">
                <Target className="w-8 h-8 mr-3 text-primary" />
                {t('aboutOurMissionTitle', 'Our Mission')}
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                {t('aboutOurMissionText', 'Our mission is to bridge the gap between skilled artisans and individuals needing their services throughout Uzbekistan. We aim to create a transparent, reliable, and convenient platform where finding professional help is simple and secure, empowering both craftsmen to grow their businesses and clients to solve their everyday problems with confidence.')}
              </p>
            </div>
            <div className="order-1 md:order-2 flex justify-center">
              <img
                src="/lovable-uploads/277ca993-e00f-42ed-8fc6-3f328e0d83b1.png"
                alt="Craftsmen working together"
                className="rounded-lg shadow-lg w-full max-w-md"
              />
            </div>
          </section>

          <section className="grid md:grid-cols-2 gap-12 items-center">
            <div className="flex justify-center">
               <img
                src="/lovable-uploads/d3bbc6f9-7a8d-4b84-bab3-ae4622fc8dab.png"
                alt="Old tools representing the start of the journey"
                className="rounded-lg shadow-lg w-full max-w-md"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-4 flex items-center">
                <BookOpen className="w-8 h-8 mr-3 text-primary" />
                {t('aboutOurStoryTitle', 'Our Story')}
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                {t('aboutOurStoryText', 'HunarMarket.uz was born from a simple idea: finding a reliable plumber or electrician shouldn\'t be a matter of luck. Frustrated by the challenge of locating trustworthy professionals, our founders envisioned a single platform to gather Uzbekistan\'s best masters. Launched in 2024, we\'ve been dedicated to building a community founded on skill, trust, and customer satisfaction.')}
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-3xl font-bold text-center mb-4 flex items-center justify-center">
              <HeartHandshake className="w-8 h-8 mr-3 text-primary" />
              {t('aboutOurValuesTitle', 'Our Values')}
            </h2>
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <div key={index} className="text-center p-6 border rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex justify-center mb-4">
                    <div className="bg-primary/10 text-primary p-4 rounded-full">
                      <value.icon className="h-10 w-10" />
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{t(value.titleKey, value.titleDefault)}</h3>
                  <p className="text-muted-foreground text-sm">{t(value.textKey, value.textDefault)}</p>
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
};

export default AboutPage;
