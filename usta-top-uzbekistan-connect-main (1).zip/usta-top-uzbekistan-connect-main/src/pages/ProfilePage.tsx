
import React, { useEffect } from 'react';
import { useAuth } from '@/components/providers/AuthProvider';
import { useNavigate } from 'react-router-dom';
import ProfileCard from '@/components/profile/ProfileCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Messages from '@/components/profile/Messages';
import { useTranslation } from 'react-i18next';

const ProfilePage = () => {
  const { session, profile, loading } = useAuth();
  const navigate = useNavigate();
  const { t } = useTranslation();

  useEffect(() => {
    if (!loading && !session) {
      navigate('/login');
    }
  }, [session, loading, navigate]);

  if (loading || !profile) {
    return (
        <div className="flex justify-center p-4 md:p-8">
            <div className="bg-card rounded-xl shadow-lg p-6 md:p-8 flex flex-col md:flex-row w-full max-w-6xl gap-8 animate-pulse">
                {/* Left Column Skeleton */}
                <div className="flex-shrink-0 md:w-64 space-y-6 flex flex-col items-center md:items-stretch">
                    <div className="flex flex-col items-center">
                        <Skeleton className="h-24 w-24 rounded-full mb-4" />
                        <Skeleton className="h-6 w-32 mb-2" />
                        <Skeleton className="h-4 w-20" />
                    </div>
                    <div className="space-y-2 pt-6">
                        <Skeleton className="h-10 w-full" />
                        <Skeleton className="h-10 w-full" />
                        <Skeleton className="h-10 w-full" />
                    </div>
                </div>

                {/* Right Column Skeleton */}
                <div className="flex-grow space-y-6">
                    <Skeleton className="h-8 w-48 mb-6" />
                    <div className="space-y-4">
                        <Skeleton className="h-10 w-full" />
                        <Skeleton className="h-10 w-full" />
                        <div className="grid grid-cols-2 gap-4">
                            <Skeleton className="h-10 w-full" />
                            <Skeleton className="h-10 w-full" />
                        </div>
                    </div>
                    <div className="space-y-4 pt-6">
                        <Skeleton className="h-24 w-full" />
                    </div>
                    <div className="flex justify-end gap-4 pt-6">
                        <Skeleton className="h-10 w-32" />
                        <Skeleton className="h-10 w-32" />
                    </div>
                </div>
            </div>
        </div>
    );
  }

  return (
    <div className="flex justify-center p-4 md:p-8">
        <div className="w-full max-w-6xl">
            <Tabs defaultValue="profile" className="w-full">
                <TabsList className="grid w-full grid-cols-2 md:max-w-[400px] mb-6">
                    <TabsTrigger value="profile">{t('profileTabProfile')}</TabsTrigger>
                    <TabsTrigger value="messages">{t('profileTabMessages')}</TabsTrigger>
                </TabsList>
                <TabsContent value="profile">
                    <ProfileCard profile={profile} />
                </TabsContent>
                <TabsContent value="messages">
                    <Messages />
                </TabsContent>
            </Tabs>
        </div>
    </div>
  );
};

export default ProfilePage;
