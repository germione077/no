
import React from 'react';
import { getAllCategories } from '@/config/categories';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const SubCategoryCard: React.FC<{ title: string; description: string; slug: string }> = ({ title, slug }) => {
  return (
    <Link to={`/categories/${slug}`} className="block group">
      <Card className="hover:shadow-md transition-shadow duration-200 h-full">
        <CardContent className="p-4">
          <CardTitle className="text-base font-semibold">{title}</CardTitle>
          <div className="text-primary text-sm font-medium flex items-center group-hover:underline mt-2">
            Mutaxassislarni ko'rish <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};

const CategoriesPage = () => {
  const { t } = useTranslation();
  const categories = getAllCategories(t);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-4">
        {t('categoriesPageTitle')}
      </h1>
      <p className="text-muted-foreground text-center mb-12 max-w-xl mx-auto">
        {t('categoriesPageSubtitle')}
      </p>
      <div className="space-y-12">
        {categories.map((category) => (
          <div key={category.slug} id={category.slug}>
            <div className="flex items-center mb-2">
              <category.icon className="h-8 w-8 mr-4 text-primary" />
              <div>
                <h2 className="text-2xl md:text-3xl font-bold">{category.title}</h2>
                <p className="text-muted-foreground">{category.description}</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mt-6">
              {category.subCategories.map((sub) => (
                <SubCategoryCard
                  key={sub.slug}
                  title={sub.title}
                  description={sub.description}
                  slug={sub.slug}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoriesPage;
