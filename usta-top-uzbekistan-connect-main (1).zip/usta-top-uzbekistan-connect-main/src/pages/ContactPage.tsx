
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Mail, Phone, MapPin } from 'lucide-react';

const ContactPage = () => {
  const { t } = useTranslation();
  const { toast } = useToast();

  const contactFormSchema = React.useMemo(() => z.object({
    name: z.string().min(2, { message: t('contactFormNameMinError', 'Name must be at least 2 characters.') }),
    email: z.string().email({ message: t('contactFormEmailError', 'Please enter a valid email address.') }),
    subject: z.string().min(5, { message: t('contactFormSubjectMinError', 'Subject must be at least 5 characters.') }),
    message: z.string().min(10, { message: t('contactFormMessageMinError', 'Message must be at least 10 characters.') }),
  }), [t]);

  type ContactFormValues = z.infer<typeof contactFormSchema>;

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      email: '',
      subject: '',
      message: '',
    },
  });

  const onSubmit = (data: ContactFormValues) => {
    console.log(data); // In a real app, you would send this to a server
    toast({
      title: t('contactFormSuccessTitle', "Success!"),
      description: t('contactFormSuccessMessage', "Your message has been sent. We will get back to you soon."),
    });
    form.reset();
  };

  return (
    <div className="container mx-auto px-4 py-12 md:py-20">
      <header className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-primary">
          {t('contactPageTitle', 'Contact Us')}
        </h1>
        <p className="mt-4 text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
          {t('contactPageSubtitle', 'Have questions? We are here to help!')}
        </p>
      </header>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        <div className="space-y-8">
          <h2 className="text-3xl font-bold">{t('contactInfoTitle', "Contact Information")}</h2>
          <div className="space-y-4">
            <div className="flex items-center">
              <Mail className="w-6 h-6 mr-4 text-primary" />
              <div>
                <h3 className="font-semibold">{t('emailLabel')}</h3>
                <a href="mailto:support@hunarmarket.uz" className="text-muted-foreground hover:text-primary">
                  support@hunarmarket.uz
                </a>
              </div>
            </div>
            <div className="flex items-center">
              <Phone className="w-6 h-6 mr-4 text-primary" />
              <div>
                <h3 className="font-semibold">{t('profileFormPhoneNumberLabel')}</h3>
                <a href="tel:+998712000000" className="text-muted-foreground hover:text-primary">
                  +998 71 200 00 00
                </a>
              </div>
            </div>
            <div className="flex items-center">
              <MapPin className="w-6 h-6 mr-4 text-primary" />
              <div>
                <h3 className="font-semibold">{t('addressLabel', 'Address')}</h3>
                <p className="text-muted-foreground">
                  {t('addressText', 'Mustaqillik Avenue, Tashkent, Uzbekistan')}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('contactFormNameLabel', 'Your Name')}</FormLabel>
                    <FormControl>
                      <Input placeholder={t('contactFormNamePlaceholder', 'Enter your name')} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('emailLabel')}</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder={t('emailPlaceholder')} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('contactFormSubjectLabel', 'Subject')}</FormLabel>
                    <FormControl>
                      <Input placeholder={t('contactFormSubjectPlaceholder', 'Message subject')} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="message"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('contactFormMessageLabel', 'Message')}</FormLabel>
                    <FormControl>
                      <Textarea placeholder={t('contactFormMessagePlaceholder', 'Write your message here...')} rows={6} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full" disabled={form.formState.isSubmitting}>
                {form.formState.isSubmitting ? t('sending', 'Sending...') : t('contactFormSubmitButton', 'Send Message')}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
