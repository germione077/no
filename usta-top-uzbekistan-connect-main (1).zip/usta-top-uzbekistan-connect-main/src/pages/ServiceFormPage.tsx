
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import ServiceForm from '@/components/profile/ServiceForm';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/components/providers/AuthProvider';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

const fetchServiceById = async (serviceId: string) => {
    const { data, error } = await supabase
        .from('services')
        .select('*')
        .eq('id', serviceId)
        .single();
    
    if (error) {
        throw new Error(error.message);
    }
    return data;
}

const ServiceFormPage = () => {
    const { serviceId } = useParams<{ serviceId: string }>();
    const { profile, loading: authLoading } = useAuth();
    const isEditMode = !!serviceId;

    const { data: service, isLoading: serviceLoading } = useQuery({
        queryKey: ['service', serviceId],
        queryFn: () => fetchServiceById(serviceId!),
        enabled: isEditMode,
    });

    const isLoading = authLoading || (isEditMode && serviceLoading);

    if (isLoading) {
        return (
            <div className="container mx-auto py-8 max-w-4xl">
                <Skeleton className="h-8 w-1/4 mb-8" />
                <div className="space-y-6">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-24 w-full" />
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-10 w-full" />
                </div>
            </div>
        );
    }
    
    if (profile?.role !== 'provider') {
        return (
          <div className="container mx-auto py-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Ruxsat yo'q</h2>
            <p>Faqat "Usta" rolidagi foydalanuvchilar xizmat qo'sha oladi.</p>
            <Button asChild className="mt-4">
              <Link to="/profile">Profilga qaytish</Link>
            </Button>
          </div>
        )
    }

    return (
        <div className="container mx-auto py-8 max-w-4xl">
            <Button variant="ghost" asChild className="mb-4">
                <Link to="/profile">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Profilga qaytish
                </Link>
            </Button>
            <h1 className="text-3xl font-bold mb-6">{isEditMode ? "Xizmatni Tahrirlash" : "Yangi Xizmat Qo'shish"}</h1>
            <ServiceForm serviceToEdit={service} />
        </div>
    );
};

export default ServiceFormPage;
