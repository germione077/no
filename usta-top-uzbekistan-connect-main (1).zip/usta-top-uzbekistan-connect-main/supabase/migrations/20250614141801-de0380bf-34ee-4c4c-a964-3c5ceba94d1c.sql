
-- "avatars" nomli public bucket yaratish
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true);

-- Avatars bucket uchun RLS (Row Level Security) qoidalarini o'rnatish

-- 1. Barcha foydalanuvchilarga bucketdagi rasmlarni ko'rishga ruxsat berish
CREATE POLICY "Public read access for avatars"
ON storage.objects FOR SELECT
USING ( bucket_id = 'avatars' );

-- 2. Tizimga kirgan foydalanuvchilarga o'zlarining papkasiga rasm yuklashga ruxsat berish
-- Rasm yo'li (path) "user_id/avatar.png" ko'rinishida bo'ladi
CREATE POLICY "Users can insert their own avatars"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK ( bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1] );

-- 3. Foydalanuvchilarga o'zlarining rasmlarini yangilashga ruxsat berish
CREATE POLICY "Users can update their own avatars"
ON storage.objects FOR UPDATE
TO authenticated
USING ( bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1] );

-- 4. Foydalanuvchilarga o'zlarining rasmlarini o'chirishga ruxsat berish
CREATE POLICY "Users can delete their own avatars"
ON storage.objects FOR DELETE
TO authenticated
USING ( bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1] );
