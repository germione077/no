
-- Foydalanuvchilar sevimlilarini saqlash uchun jadval yaratish
CREATE TABLE public.user_favorites (
  user_id UUID NOT NULL,
  service_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT user_favorites_pkey PRIMARY KEY (user_id, service_id),
  CONSTRAINT user_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE,
  CONSTRAINT user_favorites_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE
);

-- Jadval uchun Row Level Security (RLS) ni yoqish
ALTER TABLE public.user_favorites ENABLE ROW LEVEL SECURITY;

-- Foydalanuvchilarga faqat o'z sevimlilarini ko'rishga ruxsat beruvchi polisa
CREATE POLICY "Users can view their own favorites"
ON public.user_favorites FOR SELECT
USING (auth.uid() = user_id);

-- Foydalanuvchilarga faqat o'zlari uchun sevimlilarga qo'shishga ruxsat beruvchi polisa
CREATE POLICY "Users can insert their own favorites"
ON public.user_favorites FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Foydalanuvchilarga faqat o'z sevimlilarini o'chirishga ruxsat beruvchi polisa
CREATE POLICY "Users can delete their own favorites"
ON public.user_favorites FOR DELETE
USING (auth.uid() = user_id);

