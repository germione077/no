
-- Xizmatlar uchun layklarni saqlash uchun yangi jadval yaratish
CREATE TABLE public.service_likes (
    service_id UUID NOT NULL REFERENCES public.services(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (service_id, user_id)
);

-- Yangi jadval uchun qator darajasidagi xavfsizlikni (RLS) yoqish
ALTER TABLE public.service_likes ENABLE ROW LEVEL SECURITY;

-- Barcha layklarni ko'rishga ruxsat berish (bu ochiq ma'lumot)
CREATE POLICY "Layklarni ommaviy o'qishga ruxsat"
ON public.service_likes
FOR SELECT
USING (true);

-- Autentifikatsiyadan o'tgan foydalanuvchilarga o'z layklarini qo'shishga ruxsat berish
CREATE POLICY "Foydalanuvchilar o'z layklarini qo'shishi mumkin"
ON public.service_likes
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Autentifikatsiyadan o'tgan foydalanuvchilarga o'z layklarini o'chirishga ruxsat berish (laykni qaytarib olish)
CREATE POLICY "Foydalanuvchilar o'z layklarini o'chirishi mumkin"
ON public.service_likes
FOR DELETE
USING (auth.uid() = user_id);
