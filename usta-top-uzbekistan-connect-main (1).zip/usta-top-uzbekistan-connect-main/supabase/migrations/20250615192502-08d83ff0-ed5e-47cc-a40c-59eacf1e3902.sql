
-- This migration fixes a security warning by explicitly setting the search_path for the function.
-- This prevents potential security vulnerabilities where a function could be tricked into executing
-- malicious code from another schema.
CREATE OR REPLACE FUNCTION public.update_conversation_last_message_at()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE public.conversations
    SET last_message_at = NOW()
    WHERE id = NEW.conversation_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = '';
