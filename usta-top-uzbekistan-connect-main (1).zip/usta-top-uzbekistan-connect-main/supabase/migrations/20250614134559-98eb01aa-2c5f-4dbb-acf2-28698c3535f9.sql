
-- Add a column to track if a user's profile setup is complete.
-- This helps in redirecting new users to a setup page.
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS profile_complete BOOLEAN NOT NULL DEFAULT FALSE;
