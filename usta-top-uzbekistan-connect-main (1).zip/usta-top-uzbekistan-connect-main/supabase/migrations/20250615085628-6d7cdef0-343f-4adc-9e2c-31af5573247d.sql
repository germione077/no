
-- Create a table for service reviews and ratings
CREATE TABLE public.service_reviews (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    service_id UUID NOT NULL REFERENCES public.services(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    rating SMALLINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    content TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT one_review_per_user_per_service UNIQUE (user_id, service_id)
);

-- Enable Row Level Security
ALTER TABLE public.service_reviews ENABLE ROW LEVEL SECURITY;

-- Policy: Allow public read access to all reviews
CREATE POLICY "Public can read all reviews"
ON public.service_reviews
FOR SELECT
USING (true);

-- Policy: Allow authenticated users to insert a review for a service they don't own
CREATE POLICY "Users can insert their own reviews"
ON public.service_reviews
FOR INSERT
WITH CHECK (
    auth.uid() = user_id AND
    NOT EXISTS (SELECT 1 FROM public.services s WHERE s.id = service_id AND s.user_id = auth.uid())
);

-- Policy: Allow users to update their own reviews
CREATE POLICY "Users can update their own reviews"
ON public.service_reviews
FOR UPDATE
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Policy: Allow users to delete their own reviews
CREATE POLICY "Users can delete their own reviews"
ON public.service_reviews
FOR DELETE
USING (auth.uid() = user_id);
