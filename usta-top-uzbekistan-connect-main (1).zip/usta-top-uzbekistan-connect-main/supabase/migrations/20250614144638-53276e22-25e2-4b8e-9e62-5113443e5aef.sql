
-- Create a table for service listings
CREATE TABLE public.services (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  price numeric,
  price_unit text, -- e.g., "so'm", "so'm/soatiga", "so'm/kv.m"
  category_slug text,
  location_city text,
  location_district text,
  image_urls text[], -- Array to store multiple image URLs
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Enable RLS for the services table
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

-- Policy: Allow everyone to view all services.
CREATE POLICY "Services are viewable by everyone."
  ON public.services FOR SELECT
  USING (true);

-- Policy: Allow providers to create their own services.
CREATE POLICY "Providers can create their own services."
  ON public.services FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'provider'
  );

-- Policy: Allow providers to update their own services.
CREATE POLICY "Providers can update their own services."
  ON public.services FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policy: Allow providers to delete their own services.
CREATE POLICY "Providers can delete their own services."
  ON public.services FOR DELETE
  USING (auth.uid() = user_id);

-- Create a storage bucket for service images
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('service-images', 'service-images', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/webp']);

-- RLS Policies for the new storage bucket

-- Policy: Allow public read access to service images.
CREATE POLICY "Service images are publicly accessible."
  ON storage.objects FOR SELECT
  USING (bucket_id = 'service-images');

-- Policy: Allow authenticated providers to upload images into a folder named with their user_id.
CREATE POLICY "Providers can upload service images."
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'service-images' AND
    auth.uid() IS NOT NULL AND
    (SELECT role FROM public.profiles WHERE id = auth.uid()) = 'provider' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

-- Policy: Allow providers to update their own images.
CREATE POLICY "Providers can update their own service images."
    ON storage.objects FOR UPDATE
    USING (
        bucket_id = 'service-images' AND
        auth.uid() = (storage.foldername(name))[1]::uuid
    );

-- Policy: Allow providers to delete their own images.
CREATE POLICY "Providers can delete their own service images."
    ON storage.objects FOR DELETE
    USING (
        bucket_id = 'service-images' AND
        auth.uid() = (storage.foldername(name))[1]::uuid
    );

