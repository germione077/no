
-- Add username column to profiles table
ALTER TABLE public.profiles
ADD COLUMN username TEXT;

-- Add a unique constraint to the username column
ALTER TABLE public.profiles
ADD CONSTRAINT profiles_username_key UNIQUE (username);

-- Add a check constraint to validate the username format
ALTER TABLE public.profiles
ADD CONSTRAINT username_validation CHECK (
  username IS NULL OR (
    username = lower(username) AND
    username ~ '^[a-z0-9_]{3,20}$'
  )
);

-- Add a comment to the new column
COMMENT ON COLUMN public.profiles.username IS 'User-chosen unique identifier, used for searching and mentions.';
