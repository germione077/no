
-- This migration fixes the "Default privileges for new objects in public schema are not empty" warning.
-- It revokes the default CREATE privilege on the public schema from the PUBLIC role,
-- which is a recommended security practice to prevent unauthorized object creation.
REVOKE CREATE ON SCHEMA public FROM PUBLIC;

-- These commands ensure that any new tables, functions, or sequences created in the public schema
-- will not have any privileges granted to the PUBLIC role by default. Access will need to
-- be granted explicitly.
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON FUNCTIONS FROM PUBLIC;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON SEQUENCES FROM PUBLIC;
